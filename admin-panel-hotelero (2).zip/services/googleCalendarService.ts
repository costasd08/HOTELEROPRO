import { GOOGLE_API_KEY, GOOGLE_CLIENT_ID, GOOGLE_CALENDAR_SCOPE } from '../constants';
import { CalendarEventDetails } from '../types';

declare global {
  interface Window {
    gapi: any; // Standard Google API client definition
  }
}

let gapiInstance: any = null;
let authInstance: any = null;
let isGapiScriptLoaded = false;
let isGapiInitialized = false;

const DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];

const loadGapiScript = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (isGapiScriptLoaded && window.gapi) {
      gapiInstance = window.gapi;
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://apis.google.com/js/api.js';
    script.async = true;
    script.defer = true;
    script.onload = () => {
      isGapiScriptLoaded = true;
      gapiInstance = window.gapi;
      if (gapiInstance) {
        resolve();
      } else {
        reject(new Error("Failed to load Google API script."));
      }
    };
    script.onerror = () => reject(new Error('Google API script could not be loaded.'));
    document.body.appendChild(script);
  });
};


export const initClient = async (updateSigninStatus: (isSignedIn: boolean) => void): Promise<void> => {
  if (!GOOGLE_API_KEY || !GOOGLE_CLIENT_ID) {
    console.error("Google API Key or Client ID is missing. Please configure them in your environment variables.");
    updateSigninStatus(false);
    throw new Error("Google API Key or Client ID missing.");
  }

  if (!isGapiScriptLoaded) {
    try {
      await loadGapiScript();
    } catch (error) {
      console.error("Error loading GAPI script:", error);
      updateSigninStatus(false);
      throw error; // Propagate error
    }
  }
  
  if (!gapiInstance || !gapiInstance.load) {
     console.error("gapiInstance or gapi.load is not available.");
     updateSigninStatus(false);
     throw new Error("GAPI not loaded correctly.");
  }

  return new Promise((resolve, reject) => {
    gapiInstance.load('client:auth2', () => {
      gapiInstance.client.init({
        apiKey: GOOGLE_API_KEY,
        clientId: GOOGLE_CLIENT_ID,
        discoveryDocs: DISCOVERY_DOCS,
        scope: GOOGLE_CALENDAR_SCOPE,
      }).then(() => {
        authInstance = gapiInstance.auth2.getAuthInstance();
        isGapiInitialized = true;
        // Listen for sign-in state changes.
        authInstance.isSignedIn.listen(updateSigninStatus);
        // Handle the initial sign-in state.
        updateSigninStatus(authInstance.isSignedIn.get());
        resolve();
      }).catch((error: any) => {
        console.error('Error initializing Google API client:', error);
        updateSigninStatus(false);
        reject(error);
      });
    });
  });
};

export const signIn = async (): Promise<void> => {
  if (!isGapiInitialized || !authInstance) {
    console.error('Google API client not initialized. Cannot sign in.');
    throw new Error('Client not initialized');
  }
  try {
    await authInstance.signIn();
  } catch (error) {
    console.error('Error during sign in:', error);
    throw error;
  }
};

export const signOut = async (): Promise<void> => {
  if (!isGapiInitialized || !authInstance) {
    console.error('Google API client not initialized. Cannot sign out.');
    return; // Or throw error
  }
  try {
    await authInstance.signOut();
  } catch (error) {
    console.error('Error during sign out:', error);
    // Potentially handle or re-throw
  }
};

export const createCalendarEvent = async (calendarId: string, event: CalendarEventDetails): Promise<any> => {
  if (!isGapiInitialized || !authInstance || !authInstance.isSignedIn.get()) {
    console.error('User not signed in or Google API client not initialized. Cannot create event.');
    throw new Error('User not signed in or client not initialized');
  }
  if (!gapiInstance.client.calendar) {
    console.error('Google Calendar API client library not loaded.');
    throw new Error('Calendar API not loaded');
  }

  try {
    const response = await gapiInstance.client.calendar.events.insert({
      calendarId: calendarId,
      resource: event,
    });
    return response.result;
  } catch (error) {
    console.error('Error creating Google Calendar event:', error);
    throw error;
  }
};

export const getIsGapiInitialized = (): boolean => isGapiInitialized;
export const getIsSignedIn = (): boolean => {
    if (!isGapiInitialized || !authInstance) return false;
    return authInstance.isSignedIn.get();
};
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SmartNoteRequest, ApplicationDataContext } from '../types'; // Added ApplicationDataContext

const getApiKey = (): string | undefined => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("Gemini API_KEY environment variable not found. Please set it up for smart features to work.");
  }
  return apiKey;
};

const apiKey = getApiKey();
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
} else {
  console.warn("Gemini AI client not initialized due to missing API_KEY.");
}

export const getAiInstance = () => ai; // Exporting ai instance for modal to check availability

export const generateSmartCustomerNotes = async (request: SmartNoteRequest): Promise<string> => {
  if (!ai) {
      return "Error: El servicio de IA no está configurado. Verifique la clave API (API_KEY).";
  }
  
  const model = 'gemini-2.5-flash-preview-04-17';

  const bookingHistorySummary = request.bookingHistory.length > 0 
    ? request.bookingHistory.map(b => 
        `- Reserva en propiedad ID ${b.propertyId} del ${b.checkInDate} al ${b.checkOutDate} (${b.numberOfGuests} huéspedes). Costo: $${b.totalPrice}. Notas de reserva: ${b.notes || 'ninguna'}.`
      ).join('\n')
    : "Sin historial de reservas.";

  const prompt = `
    Eres un asistente de hotel experto en análisis de clientes y mejora de la experiencia.
    Basado en el siguiente historial de reservas y preferencias de un cliente, genera notas concisas y accionables, y posibles sugerencias para mejorar su próxima estadía.

    ID del Cliente: ${request.customerId}

    Historial de Reservas:
    ${bookingHistorySummary}

    Preferencias/Notas existentes del cliente: ${request.customerPreferences || "Ninguna."}

    Por favor, estructura tu respuesta de la siguiente manera:

    **Resumen de Preferencias Clave:**
    (Lista de 2-3 puntos principales observados sobre las preferencias del cliente. Si no hay suficientes datos, indícalo.)
    - [Preferencia 1]
    - [Preferencia 2]

    **Sugerencias Personalizadas para Próxima Estadía:**
    (Lista de 2-3 sugerencias concretas y personalizadas. Considera tipo de habitación, actividades, ofertas especiales, etc.)
    - [Sugerencia 1]
    - [Sugerencia 2]

    **Alertas o Puntos de Atención Especial:**
    (Identifica cualquier punto crítico que requiera atención, como quejas pasadas, solicitudes recurrentes no cumplidas, o información importante para el personal.)
    - [Alerta 1, si aplica. Si no hay alertas, indica "Ninguna."]

    Sé breve, específico y orientado a la acción. El objetivo es ayudar al personal del hotel a ofrecer un servicio excepcional.
    Si la información es muy limitada para un análisis significativo, indícalo claramente en cada sección.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error('Error calling Gemini API for smart notes:', error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
             return `Error: Clave API de Gemini no válida. Por favor, verifique la configuración.`;
        }
        return `Error al contactar el servicio de IA para notas inteligentes: ${error.message}`;
    }
    return 'Error desconocido al contactar el servicio de IA para notas inteligentes.';
  }
};

export const generateFeedbackSummary = async (feedbackText: string): Promise<string> => {
  if (!ai) {
    return "Error: El servicio de IA no está configurado. Verifique la clave API (API_KEY).";
  }

  const model = 'gemini-2.5-flash-preview-04-17';
  const prompt = `
    Eres un asistente de hotel experto en análisis de feedback de huéspedes.
    Analiza el siguiente comentario/queja/sugerencia de un huésped y proporciona un resumen conciso y accionable.

    Texto del Feedback:
    "${feedbackText}"

    Por favor, estructura tu respuesta de la siguiente manera:

    **Puntos Principales del Feedback:**
    (Lista 2-4 puntos clave extraídos del texto.)
    - [Punto clave 1]
    - [Punto clave 2]

    **Sentimiento General:**
    (Describe brevemente el sentimiento predominante: Positivo, Negativo, Neutral, Mixto. Añade una breve justificación.)
    - Sentimiento: [Positivo/Negativo/Neutral/Mixto] porque [justificación].

    **Áreas de Mejora o Fortalezas Identificadas (si aplica):**
    (Si es una queja o sugerencia, qué se podría mejorar. Si es un elogio, qué se destacó.)
    - [Área/Fortaleza 1]
    - [Área/Fortaleza 2]
    
    **Sugerencia de Siguiente Paso (si aplica):**
    (¿Se requiere alguna acción inmediata? ¿A qué departamento se debería informar?)
    - [Sugerencia de acción o "No se requiere acción adicional."]

    Sé objetivo, breve y enfocado en la utilidad para el personal del hotel.
    Si el feedback es muy corto o ambiguo, indícalo.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    return response.text;
  } catch (error)
     {
    console.error('Error calling Gemini API for feedback summary:', error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
             return `Error: Clave API de Gemini no válida. Por favor, verifique la configuración.`;
        }
        return `Error al contactar el servicio de IA para resumen de feedback: ${error.message}`;
    }
    return 'Error desconocido al contactar el servicio de IA para resumen de feedback.';
  }
};

export const generateAssistantResponse = async (userQuery: string, context: ApplicationDataContext, conversationHistory: { role: string, parts: { text: string }[] }[] ): Promise<string> => {
  if (!ai) {
    return "Error: El servicio de IA no está configurado. Verifique la clave API (API_KEY).";
  }
  const model = 'gemini-2.5-flash-preview-04-17';

  // Create a more structured summary of the data context
  // This needs to be carefully managed to avoid exceeding token limits
  const dataSummary = `
    CONTEXTO DE DATOS DE LA APLICACIÓN HOTELERA (RESUMEN):
    - Total de Reservas: ${context.reservations.length}. (Ej: ${JSON.stringify(context.reservations.slice(0, 1))})
    - Total de Clientes: ${context.customers.length}. (Ej: ${JSON.stringify(context.customers.slice(0, 1))})
    - Total de Propiedades: ${context.properties.length}. (Ej: ${JSON.stringify(context.properties.slice(0, 1))})
    - Total de Asientos Contables: ${context.accountingEntries.length}. (Ej: ${JSON.stringify(context.accountingEntries.slice(0, 1))})
    - Total de Empleados: ${context.employees.length}. (Ej: ${JSON.stringify(context.employees.slice(0,1))})
    - Total de Órdenes de Restaurante: ${context.orders.length}. (Ej: ${JSON.stringify(context.orders.slice(0,1))})
    - Total de Platillos del Menú: ${context.menuItems.length}. (Ej: ${JSON.stringify(context.menuItems.slice(0,1))})
    - Total de Artículos de Inventario: ${context.inventoryItems.length}. (Ej: ${JSON.stringify(context.inventoryItems.slice(0,1))})
    - Total de Feedbacks de Huéspedes: ${context.guestFeedback.length}. (Ej: ${JSON.stringify(context.guestFeedback.slice(0,1))})
    - Nombre de la App/Hotel: ${context.appSettings.appName}
    Considera que las fechas están en formato ISO (YYYY-MM-DD). Hoy es ${new Date().toLocaleDateString('es-ES')}.
  `;

  const systemInstruction = `Eres un asistente de IA amigable y servicial para la aplicación de gestión hotelera llamada "${context.appSettings.appName}". 
  Tu propósito es ayudar al usuario a entender y obtener información de los datos de la aplicación.
  Utiliza el CONTEXTO DE DATOS DE LA APLICACIÓN HOTELERA proporcionado para responder a las preguntas.
  Proporciona respuestas concisas y, si se te pide un reporte, intenta resumir la información de forma clara.
  Si la pregunta es ambigua o no puedes responderla con el resumen de datos provisto, indica que necesitas más detalles o que la información no está disponible en el resumen actual.
  No inventes información. No realices cálculos complejos a menos que sean sumas o conteos simples basados en los totales proporcionados.
  Puedes responder en español.`;

  // Construct the prompt with history and current query
  const contents = [
    ...conversationHistory,
    { role: "user", parts: [{ text: `${dataSummary}\n\nPREGUNTA DEL USUARIO: ${userQuery}` }] }
  ];
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: contents,
      generationConfig: {
        // temperature: 0.7, // Adjust for creativity vs. factuality
      },
      systemInstruction: {
        role: "system", // Though new API prefers systemInstruction in config for some models
        parts: [{ text: systemInstruction }]
      },
      // For newer models, system instruction is better placed in config if supported
      // config: { systemInstruction: systemInstruction }
    });
    return response.text;
  } catch (error) {
    console.error('Error calling Gemini API for assistant response:', error);
    if (error instanceof Error) {
      if (error.message.includes('API key not valid')) {
        return `Error: La clave API de Gemini no es válida. Por favor, verifique la configuración.`;
      }
      return `Error al contactar el servicio de IA: ${error.message}`;
    }
    return 'Error desconocido al contactar el servicio de IA.';
  }
};

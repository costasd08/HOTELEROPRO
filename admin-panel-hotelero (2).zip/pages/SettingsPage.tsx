
import React, { useState, useEffect, useCallback } from 'react';
import { AppSettings } from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Card from '../../components/common/Card';
import TextInput from '../../components/common/TextInput';
import TextareaInput from '../../components/common/TextareaInput'; 
import { APP_NAME, APP_SETTINGS_KEY } from '../../constants';

const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>({
    appName: APP_NAME, 
    logoUrl: '', 
    hotelEmail: '',
    responsiblePerson: '',
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
    defaultCheckInTime: '14:00', 
    defaultCheckOutTime: '12:00', 
    reservationPolicies: '',
    cancellationPolicies: '',
    generalObservations: '',
    otherPolicies: '',
    weatherWidgetEnabled: false, 
    weatherWidgetHref: 'https://forecast7.com/es/19d43n99d13/mexico-city/',
    weatherWidgetDataLabel: 'CIUDAD DE MÉXICO',
    googleCalendarConnected: false, 
    googleCalendarId: 'primary',    
    defaultKitchenOverheadRate: 0.10, 
    defaultAdminSalesOverheadRate: 0.15,
    aiAssistantEnabled: false, // Default for AI Assistant
  });
  const [isSaved, setIsSaved] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);

  useEffect(() => {
    try {
      const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
      if (storedSettings) {
        const parsedSettings = JSON.parse(storedSettings) as AppSettings;
        setSettings(prev => ({ 
            ...prev, 
            ...parsedSettings,
            weatherWidgetEnabled: parsedSettings.weatherWidgetEnabled !== undefined ? parsedSettings.weatherWidgetEnabled : prev.weatherWidgetEnabled,
            weatherWidgetHref: parsedSettings.weatherWidgetHref || prev.weatherWidgetHref,
            weatherWidgetDataLabel: parsedSettings.weatherWidgetDataLabel || prev.weatherWidgetDataLabel,
            googleCalendarConnected: parsedSettings.googleCalendarConnected !== undefined ? parsedSettings.googleCalendarConnected : prev.googleCalendarConnected, 
            googleCalendarId: parsedSettings.googleCalendarId || prev.googleCalendarId, 
            defaultKitchenOverheadRate: parsedSettings.defaultKitchenOverheadRate !== undefined ? parsedSettings.defaultKitchenOverheadRate : prev.defaultKitchenOverheadRate,
            defaultAdminSalesOverheadRate: parsedSettings.defaultAdminSalesOverheadRate !== undefined ? parsedSettings.defaultAdminSalesOverheadRate : prev.defaultAdminSalesOverheadRate,
            aiAssistantEnabled: parsedSettings.aiAssistantEnabled !== undefined ? parsedSettings.aiAssistantEnabled : prev.aiAssistantEnabled, // Load AI assistant setting
        })); 
        if (parsedSettings.logoUrl) {
            setLogoPreview(parsedSettings.logoUrl);
        }
      }
    } catch (error) {
      console.error("Error loading settings from localStorage:", error);
    }
  }, []);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setSettings(prev => ({ ...prev, [name]: checked }));
    } else if (name === 'defaultKitchenOverheadRate' || name === 'defaultAdminSalesOverheadRate') {
        setSettings(prev => ({ ...prev, [name]: parseFloat(value) / 100 })); // Store as decimal
    }
     else {
        setSettings(prev => ({ ...prev, [name]: value }));
    }
    setIsSaved(false);
  };
  
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setSettings(prev => ({ ...prev, logoUrl: base64String }));
        setLogoPreview(base64String);
        setIsSaved(false);
      };
      reader.readAsDataURL(file);
    } else {
      setSettings(prev => ({...prev, logoUrl: ''}));
      setLogoPreview(null);
    }
  };

  const handleSaveSettings = () => {
    try {
      localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(settings));
      setIsSaved(true);
      window.dispatchEvent(new Event('storage')); 
      alert('Configuración guardada.');
    } catch (error) {
      console.error("Error saving settings to localStorage:", error);
      alert('Error al guardar la configuración.');
    }
  };


  return (
    <div>
      <PageTitle title="Configuración de la Aplicación" />

      <Card title="Información General del Hotel/Aplicación">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(); }} className="space-y-6">
          <TextInput
            label="Nombre de la Aplicación/Hotel*"
            name="appName"
            value={settings.appName}
            onChange={handleChange}
            required
          />
          <div>
            <label htmlFor="logoUploadInput" className="block text-sm font-medium text-muted-foreground mb-1">
              Logo de la Aplicación/Hotel (Opcional)
            </label>
            <div className="mt-1 flex items-center space-x-3">
                <label htmlFor="logoUploadInput" className="inline-flex items-center px-4 py-2 bg-primary/10 text-primary text-sm font-medium rounded-md cursor-pointer hover:bg-primary/20 transition-colors">
                    <Icon name="upload" className="w-4 h-4 mr-2"/>
                    Seleccionar Logo
                </label>
                <input
                    id="logoUploadInput"
                    name="logoUrl"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoChange}
                    className="hidden"
                />
                {logoPreview && (
                    <Icon name="check" className="w-5 h-5 text-success"/>
                )}
            </div>

            {logoPreview && (
             <div className="mt-3 p-2 border border-border-color rounded-md inline-block bg-background">
                <img src={logoPreview} alt="Previsualización del logo" className="max-h-24 max-w-xs object-contain rounded"/>
             </div>
           )}
          </div>
          
          <TextInput
            label="Teléfono Principal del Hotel"
            name="phone"
            type="tel"
            value={settings.phone || ''}
            onChange={handleChange}
          />
          <TextInput
            label="Correo Electrónico Principal del Hotel"
            name="hotelEmail"
            type="email"
            value={settings.hotelEmail}
            onChange={handleChange}
          />
          <TextInput
            label="Persona Responsable (Opcional)"
            name="responsiblePerson"
            value={settings.responsiblePerson}
            onChange={handleChange}
          />
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TextInput
                label="Hora de Check-in Generalizada"
                name="defaultCheckInTime"
                type="time"
                value={settings.defaultCheckInTime || ''}
                onChange={handleChange}
            />
            <TextInput
                label="Hora de Check-out Generalizada"
                name="defaultCheckOutTime"
                type="time"
                value={settings.defaultCheckOutTime || ''}
                onChange={handleChange}
            />
          </div>

          <div className="flex justify-end items-center space-x-3 pt-4">
            {isSaved && <p className="text-sm text-success mr-auto">¡Configuración guardada exitosamente!</p>}
            <Button type="submit" leftIcon={<Icon name="check" className="w-5 h-5"/>}>
              Guardar Configuración General
            </Button>
          </div>
        </form>
      </Card>
      
      <Card title="Personalización de Reportes y Políticas" className="mt-6">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(); }} className="space-y-6">
            <TextareaInput
                label="Texto de Encabezado Personalizado para Reportes"
                name="reportCustomHeaderText"
                value={settings.reportCustomHeaderText || ''}
                onChange={handleChange}
                rows={2}
                placeholder="Ej: Todos los montos en MXN. Reporte confidencial."
            />
            <TextareaInput
                label="Texto de Pie de Página Personalizado para Reportes"
                name="reportCustomFooterText"
                value={settings.reportCustomFooterText || ''}
                onChange={handleChange}
                rows={2}
                placeholder="Ej: Gracias por su preferencia. Vuelva pronto."
            />
            <TextareaInput
                label="Políticas de Reservación (para Recibos)"
                name="reservationPolicies"
                value={settings.reservationPolicies || ''}
                onChange={handleChange}
                rows={3}
                placeholder="Detalle aquí las políticas generales de reservación..."
            />
            <TextareaInput
                label="Políticas de Cancelación (para Recibos)"
                name="cancellationPolicies"
                value={settings.cancellationPolicies || ''}
                onChange={handleChange}
                rows={3}
                placeholder="Detalle aquí las políticas de cancelación..."
            />
            <TextareaInput
                label="Observaciones Generales (para Recibos)"
                name="generalObservations"
                value={settings.generalObservations || ''}
                onChange={handleChange}
                rows={3}
                placeholder="Información adicional o notas importantes para los clientes..."
            />
            <TextareaInput
                label="Otras Políticas Adicionales (para Recibos)"
                name="otherPolicies"
                value={settings.otherPolicies || ''}
                onChange={handleChange}
                rows={3}
                placeholder="Cualquier otra política o condición relevante..."
            />
            <div className="flex justify-end items-center space-x-3 pt-4">
                {isSaved && <p className="text-sm text-success mr-auto">¡Configuración guardada exitosamente!</p>}
                <Button type="submit" leftIcon={<Icon name="check" className="w-5 h-5"/>}>
                Guardar Configuración de Reportes y Políticas
                </Button>
            </div>
        </form>
      </Card>
      
      <Card title="Configuración de Costos del Restaurante (Tasas por Defecto)" className="mt-6">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(); }} className="space-y-6">
            <TextInput
                label="Tasa de Gastos Generales de Cocina por Defecto (%)"
                name="defaultKitchenOverheadRate"
                type="number"
                value={(settings.defaultKitchenOverheadRate !== undefined ? settings.defaultKitchenOverheadRate * 100 : 10).toString()}
                onChange={(e) => {
                    const percentageValue = parseFloat(e.target.value);
                    setSettings(prev => ({ ...prev, defaultKitchenOverheadRate: isNaN(percentageValue) ? undefined : percentageValue / 100 }));
                    setIsSaved(false);
                }}
                min="0"
                max="100"
                step="0.1"
                helperText="Ej: 10 para 10%. Se aplica a (Costo Ingredientes + Mano Obra Directa)."
            />
            <TextInput
                label="Tasa de Gastos Admin. y Ventas por Defecto (%)"
                name="defaultAdminSalesOverheadRate"
                type="number"
                value={(settings.defaultAdminSalesOverheadRate !== undefined ? settings.defaultAdminSalesOverheadRate * 100 : 15).toString()}
                onChange={(e) => {
                    const percentageValue = parseFloat(e.target.value);
                    setSettings(prev => ({ ...prev, defaultAdminSalesOverheadRate: isNaN(percentageValue) ? undefined : percentageValue / 100 }));
                    setIsSaved(false);
                }}
                min="0"
                max="100"
                step="0.1"
                helperText="Ej: 15 para 15%. Se aplica al Costo Total de Producción."
            />
            <div className="flex justify-end items-center space-x-3 pt-4">
                {isSaved && <p className="text-sm text-success mr-auto">¡Configuración guardada exitosamente!</p>}
                <Button type="submit" leftIcon={<Icon name="check" className="w-5 h-5"/>}>
                    Guardar Tasas de Costos
                </Button>
            </div>
        </form>
      </Card>


      <Card title="Configuración del Widget del Clima" className="mt-6">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(); }} className="space-y-6">
            <div className="flex items-center">
                <input
                    id="weatherWidgetEnabled"
                    name="weatherWidgetEnabled"
                    type="checkbox"
                    checked={settings.weatherWidgetEnabled || false}
                    onChange={handleChange}
                    className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                />
                <label htmlFor="weatherWidgetEnabled" className="ml-2 block text-sm text-muted-foreground">
                    Activar Widget del Clima en el encabezado
                </label>
            </div>

            {settings.weatherWidgetEnabled && (
                <>
                    <TextInput
                        label="URL del Widget (href de weatherwidget.io)"
                        name="weatherWidgetHref"
                        value={settings.weatherWidgetHref || ''}
                        onChange={handleChange}
                        placeholder="Ej: https://forecast7.com/es/19d43n99d13/mexico-city/"
                    />
                    <TextInput
                        label="Etiqueta Principal (data-label_1 de weatherwidget.io)"
                        name="weatherWidgetDataLabel"
                        value={settings.weatherWidgetDataLabel || ''}
                        onChange={handleChange}
                        placeholder="Ej: CIUDAD DE MÉXICO"
                    />
                    <div className="text-xs text-muted-foreground p-2 bg-background rounded-md">
                        <p><strong>Instrucciones:</strong></p>
                        <ol className="list-decimal list-inside pl-2">
                            <li>Visite <a href="https://weatherwidget.io/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">weatherwidget.io</a>.</li>
                            <li>Personalice el widget para su ciudad y copie el código HTML proporcionado.</li>
                            <li>Del código HTML, extraiga el valor del atributo <strong><code>href</code></strong> de la etiqueta <code>&lt;a&gt;</code> y péguelo en "URL del Widget".</li>
                            <li>Extraiga el valor del atributo <strong><code>data-label_1</code></strong> y péguelo en "Etiqueta Principal".</li>
                        </ol>
                    </div>
                </>
            )}
            <div className="flex justify-end items-center space-x-3 pt-4">
                {isSaved && <p className="text-sm text-success mr-auto">¡Configuración guardada exitosamente!</p>}
                <Button type="submit" leftIcon={<Icon name="check" className="w-5 h-5"/>}>
                    Guardar Configuración del Clima
                </Button>
            </div>
        </form>
      </Card>

      <Card title="Configuración del Asistente AI" className="mt-6">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveSettings(); }} className="space-y-4">
            <div className="flex items-center">
                <input
                    id="aiAssistantEnabled"
                    name="aiAssistantEnabled"
                    type="checkbox"
                    checked={settings.aiAssistantEnabled || false}
                    onChange={handleChange}
                    className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                />
                <label htmlFor="aiAssistantEnabled" className="ml-2 block text-sm text-muted-foreground">
                    Activar Asistente AI en la aplicación
                </label>
            </div>
            <p className="text-xs text-muted-foreground p-2 bg-background rounded-md">
                Nota: Para que el asistente funcione, la clave API de Gemini (<code>API_KEY</code>) debe estar configurada correctamente como una variable de entorno en el sistema donde se ejecuta esta aplicación. Esta interfaz no permite modificar dicha clave.
            </p>
            <div className="flex justify-end items-center space-x-3 pt-4">
                {isSaved && <p className="text-sm text-success mr-auto">¡Configuración guardada exitosamente!</p>}
                <Button type="submit" leftIcon={<Icon name="check" className="w-5 h-5"/>}>
                    Guardar Configuración del Asistente
                </Button>
            </div>
        </form>
      </Card>

    </div>
  );
};

export default SettingsPage;
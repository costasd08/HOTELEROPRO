import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Employee, EmployeeTransaction, EmployeeTransactionType, AccountingEntry, AccountingEntryType, AccountingExpenseCategory, AccountingIncomeCategory, AppSettings } from '../types';
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import Table, { TableColumn } from '../components/common/Table'; // Import TableColumn
import EmployeeForm from '../components/employees/EmployeeForm';
import EmployeeTransactionForm from '../components/employees/EmployeeTransactionForm';
import Card from '../components/common/Card';
import KPICard from '../components/dashboard/KPICard';
import useMockData from '../hooks/useMockData';
import { MOCK_EMPLOYEES_DATA_KEY, MOCK_EMPLOYEE_TRANSACTIONS_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY, EMPLOYEE_TRANSACTION_TYPE_OPTIONS, APP_SETTINGS_KEY, APP_NAME } from '../constants';
import TextInput from '../components/common/TextInput';


const initialEmployees: Employee[] = [
    { id: 'emp1', fullName: 'Carlos Santana', position: 'Gerente', hireDate: '2023-01-15', baseSalary: 3500, contactInfo: '555-0011', bankAccount: '123-456-789', isActive: true, createdAt: new Date().toISOString() },
    { id: 'emp2', fullName: 'Laura Méndez', position: 'Recepcionista', hireDate: '2023-06-01', baseSalary: 1800, contactInfo: 'laura.m@example.com', isActive: true, createdAt: new Date().toISOString() },
];

const initialTransactions: EmployeeTransaction[] = [
    { id: 'etrans1', employeeId: 'emp1', date: '2024-06-30', type: EmployeeTransactionType.SALARY, description: 'Salario Junio 2024', amount: 3500, createdAt: new Date().toISOString() },
    { id: 'etrans2', employeeId: 'emp2', date: '2024-07-01', type: EmployeeTransactionType.ADVANCE, description: 'Adelanto Salario Julio', amount: 300, createdAt: new Date().toISOString() },
    { id: 'etrans3', employeeId: 'emp1', date: '2024-07-05', type: EmployeeTransactionType.LOAN_GIVEN, description: 'Préstamo personal', amount: 500, createdAt: new Date().toISOString() },
];

const initialAccountingEntries: AccountingEntry[] = []; // Assuming accounting entries for staff are new

const EmployeesPage: React.FC = () => {
  const [employees, setEmployees] = useMockData<Employee>(MOCK_EMPLOYEES_DATA_KEY, initialEmployees);
  const [transactions, setTransactions] = useMockData<EmployeeTransaction>(MOCK_EMPLOYEE_TRANSACTIONS_DATA_KEY, initialTransactions);
  const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAccountingEntries);

  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);
  
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedEmployeeForDetail, setSelectedEmployeeForDetail] = useState<Employee | null>(null);

  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<EmployeeTransaction | null>(null);
  const [currentEmployeeForTransaction, setCurrentEmployeeForTransaction] = useState<Employee | null>(null);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [appSettings, setAppSettings] = useState<Partial<AppSettings>>({ appName: APP_NAME });

  useEffect(() => {
    const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
    if (storedSettings) {
      setAppSettings(JSON.parse(storedSettings));
    }
  }, []);

  // --- Employee CRUD ---
  const handleOpenEmployeeModal = (employee: Employee | null = null) => {
    setCurrentEmployee(employee);
    setIsEmployeeModalOpen(true);
  };
  const handleCloseEmployeeModal = () => {
    setIsEmployeeModalOpen(false);
    setCurrentEmployee(null);
  };
  const handleSaveEmployee = (data: Omit<Employee, 'id' | 'createdAt'> & { id?: string }) => {
    if (data.id) {
      setEmployees(prev => prev.map(e => e.id === data.id ? { ...e, ...data } : e));
    } else {
      setEmployees(prev => [...prev, { ...data, id: `emp-${Date.now()}`, createdAt: new Date().toISOString() }]);
    }
    handleCloseEmployeeModal();
  };
  const handleDeleteEmployee = (id: string) => {
    if (window.confirm('¿Eliminar empleado? Esto no eliminará sus transacciones financieras pero podría dejar registros huérfanos.')) {
      setEmployees(prev => prev.filter(e => e.id !== id));
      // Optionally, mark associated transactions or handle them
    }
  };

  // --- Employee Detail Modal ---
  const handleOpenDetailModal = (employee: Employee) => {
    setSelectedEmployeeForDetail(employee);
    setIsDetailModalOpen(true);
  };
  const handleCloseDetailModal = () => {
    setIsDetailModalOpen(false);
    setSelectedEmployeeForDetail(null);
  };

  // --- Employee Transaction CRUD ---
  const handleOpenTransactionModal = (transaction: EmployeeTransaction | null = null, employee: Employee) => {
    setCurrentTransaction(transaction);
    setCurrentEmployeeForTransaction(employee);
    setIsTransactionModalOpen(true);
  };
  const handleCloseTransactionModal = () => {
    setIsTransactionModalOpen(false);
    setCurrentTransaction(null);
    setCurrentEmployeeForTransaction(null);
  };

  const handleSaveTransaction = (data: Omit<EmployeeTransaction, 'id' | 'createdAt' | 'employeeId' | 'accountingEntryId'> & { id?: string }) => {
    if (!currentEmployeeForTransaction) return;

    let savedTransaction: EmployeeTransaction;
    if (data.id) { // Editing existing
      savedTransaction = { ...currentTransaction!, ...data, employeeId: currentEmployeeForTransaction.id };
      setTransactions(prev => prev.map(t => t.id === data.id ? savedTransaction : t));
    } else { // Creating new
      savedTransaction = { ...data, id: `etrans-${Date.now()}`, employeeId: currentEmployeeForTransaction.id, createdAt: new Date().toISOString() };
      setTransactions(prev => [...prev, savedTransaction]);
    }

    // Create/Update corresponding Accounting Entry
    let accEntryType: AccountingEntryType;
    let accCategory: AccountingExpenseCategory | AccountingIncomeCategory;
    let accDescription = `${savedTransaction.type} - ${currentEmployeeForTransaction.fullName} - ${savedTransaction.description}`;

    switch (savedTransaction.type) {
      case EmployeeTransactionType.SALARY:
      case EmployeeTransactionType.BONUS:
      case EmployeeTransactionType.ADVANCE:
        accEntryType = AccountingEntryType.EXPENSE;
        accCategory = AccountingExpenseCategory.STAFF;
        break;
      case EmployeeTransactionType.LOAN_GIVEN:
        accEntryType = AccountingEntryType.EXPENSE;
        accCategory = AccountingExpenseCategory.LOANS_TO_STAFF;
        break;
      case EmployeeTransactionType.LOAN_REPAYMENT:
        accEntryType = AccountingEntryType.INCOME;
        accCategory = AccountingIncomeCategory.LOAN_REPAYMENT_STAFF;
        break;
      case EmployeeTransactionType.DEDUCTION:
        accEntryType = AccountingEntryType.INCOME;
        accCategory = AccountingIncomeCategory.DEDUCTIONS_STAFF; // Or could reduce salary expense directly
        break;
      default: // OTHER
        // For 'OTHER', it's ambiguous. Let's default to expense, or require user input in a more complex system.
        // For now, let's assume 'OTHER' might be an expense.
        accEntryType = AccountingEntryType.EXPENSE;
        accCategory = AccountingExpenseCategory.STAFF; // Or a generic "Other Staff Expense"
        accDescription = `Otro Movimiento (${savedTransaction.description}) - ${currentEmployeeForTransaction.fullName}`;
    }

    const accountingData: Omit<AccountingEntry, 'id' | 'createdAt'> = {
        date: savedTransaction.date,
        type: accEntryType,
        category: accCategory,
        description: accDescription,
        amount: savedTransaction.amount,
        employeeTransactionId: savedTransaction.id,
    };
    
    // Check if an accounting entry already exists for this transaction
    const existingAccountingEntry = accountingEntries.find(ae => ae.employeeTransactionId === savedTransaction.id);

    if (existingAccountingEntry) {
        // Update existing accounting entry
        const updatedAccEntry = { ...existingAccountingEntry, ...accountingData };
        setAccountingEntries(prevAcc => prevAcc.map(ae => ae.id === existingAccountingEntry.id ? updatedAccEntry : ae));
        // Update transaction with potentially updated accountingEntryId (though it should be the same)
        if(savedTransaction.accountingEntryId !== existingAccountingEntry.id) {
            savedTransaction.accountingEntryId = existingAccountingEntry.id;
            setTransactions(prevTrans => prevTrans.map(t => t.id === savedTransaction.id ? savedTransaction : t));
        }

    } else {
        // Create new accounting entry
        const newAccEntryId = `acc-${Date.now()}`;
        setAccountingEntries(prevAcc => [...prevAcc, { ...accountingData, id: newAccEntryId, createdAt: new Date().toISOString() }]);
        // Link accountingEntryId to the transaction
        savedTransaction.accountingEntryId = newAccEntryId;
        setTransactions(prevTrans => prevTrans.map(t => t.id === savedTransaction.id ? savedTransaction : t));
    }


    handleCloseTransactionModal();
  };

  const handleDeleteTransaction = (id: string) => {
    if (window.confirm('¿Eliminar esta transacción? También se eliminará el asiento contable asociado.')) {
      const transactionToDelete = transactions.find(t => t.id === id);
      setTransactions(prev => prev.filter(t => t.id !== id));
      if (transactionToDelete?.accountingEntryId) {
        setAccountingEntries(prevAcc => prevAcc.filter(ae => ae.id !== transactionToDelete.accountingEntryId));
      }
    }
  };
  
  const handleShareWhatsAppToEmployee = (employee: Employee) => {
    // Attempt to extract a phone number from contactInfo. This is a simple regex, might need refinement.
    const phoneMatch = employee.contactInfo?.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    const employeePhone = phoneMatch ? phoneMatch[0].replace(/\D/g, '') : employee.contactInfo?.replace(/\D/g, ''); // Fallback to sanitizing whole string

    if (!employeePhone) {
      alert('La información de contacto del empleado no parece ser un número de teléfono válido o no está disponible.');
      return;
    }
    const message = encodeURIComponent(`Hola ${employee.fullName}, mensaje de ${appSettings.appName || 'la administración'}.`);
    const whatsappUrl = `https://wa.me/${employeePhone}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };


  // --- Derived Data ---
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp =>
      emp.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.contactInfo.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [employees, searchTerm]);
  
  const employeeFinancialSummary = useMemo(() => {
    if (!selectedEmployeeForDetail) return { totalPaid: 0, totalLoansGiven: 0, totalLoanRepayments: 0, loanBalance: 0 };
    
    const empTransactions = transactions.filter(t => t.employeeId === selectedEmployeeForDetail.id);
    const totalPaid = empTransactions
      .filter(t => t.type === EmployeeTransactionType.SALARY || t.type === EmployeeTransactionType.BONUS || t.type === EmployeeTransactionType.ADVANCE)
      .reduce((sum, t) => sum + t.amount, 0);
    const totalLoansGiven = empTransactions
      .filter(t => t.type === EmployeeTransactionType.LOAN_GIVEN)
      .reduce((sum, t) => sum + t.amount, 0);
    const totalLoanRepayments = empTransactions
      .filter(t => t.type === EmployeeTransactionType.LOAN_REPAYMENT)
      .reduce((sum, t) => sum + t.amount, 0);
    const loanBalance = totalLoansGiven - totalLoanRepayments;
      
    return { totalPaid, totalLoansGiven, totalLoanRepayments, loanBalance };
  }, [selectedEmployeeForDetail, transactions]);


  const summaryStats = useMemo(() => {
    const activeEmployees = employees.filter(e => e.isActive).length;
    const totalSalariesThisMonth = transactions.filter(t => {
        const transDate = new Date(t.date);
        const today = new Date();
        return t.type === EmployeeTransactionType.SALARY && 
               transDate.getMonth() === today.getMonth() &&
               transDate.getFullYear() === today.getFullYear();
    }).reduce((sum, t) => sum + t.amount, 0);

    return [
      { label: 'Total Empleados', value: employees.length, icon: <Icon name="users" className="w-6 h-6 text-primary" /> },
      { label: 'Empleados Activos', value: activeEmployees, icon: <Icon name="check" className="w-6 h-6 text-success" /> },
      { label: 'Salarios Pagados (Mes)', value: `$${totalSalariesThisMonth.toFixed(2)}`, icon: <Icon name="banknotes" className="w-6 h-6 text-info" /> },
    ];
  }, [employees, transactions]);

  // --- Table Columns ---
  const employeeColumns: TableColumn<Employee>[] = [
    { header: 'Nombre Completo', accessor: 'fullName', className: 'font-semibold' },
    { header: 'Puesto', accessor: 'position' },
    { header: 'Salario Base', accessor: (item: Employee) => `$${item.baseSalary.toFixed(2)}` },
    { header: 'Estado', accessor: (item: Employee) => item.isActive ? 
        <span className="px-2 py-0.5 text-xs font-medium bg-success/20 text-success rounded-full">Activo</span> : 
        <span className="px-2 py-0.5 text-xs font-medium bg-danger/20 text-danger rounded-full">Inactivo</span> 
    },
    {
      header: 'Acciones',
      accessor: (item: Employee) => (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" onClick={() => handleOpenDetailModal(item)} title="Ver Detalles y Movimientos">
            <Icon name="eye" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleOpenEmployeeModal(item)} title="Editar Empleado">
            <Icon name="edit" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleShareWhatsAppToEmployee(item)} title="Contactar por WhatsApp" className="text-green-500 hover:text-green-600">
            <Icon name="whatsapp" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteEmployee(item.id)} className="text-danger hover:text-danger/80" title="Eliminar Empleado">
            <Icon name="trash" className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  const transactionColumns: TableColumn<EmployeeTransaction>[] = [
    { header: 'Fecha', accessor: (item: EmployeeTransaction) => new Date(item.date).toLocaleDateString() },
    { header: 'Tipo', accessor: 'type' },
    { header: 'Descripción', accessor: 'description', className: 'truncate max-w-xs' },
    { header: 'Monto', accessor: (item: EmployeeTransaction) => `$${item.amount.toFixed(2)}`},
    {
      header: 'Acciones',
      accessor: (item: EmployeeTransaction) => selectedEmployeeForDetail && (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" onClick={() => handleOpenTransactionModal(item, selectedEmployeeForDetail)} title="Editar Transacción">
            <Icon name="edit" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteTransaction(item.id)} className="text-danger hover:text-danger/80" title="Eliminar Transacción">
            <Icon name="trash" className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];


  return (
    <div>
      <PageTitle title="Gestión de Personal" actionButton={
        <Button onClick={() => handleOpenEmployeeModal()} leftIcon={<Icon name="plus" className="w-5 h-5"/>}>
          Nuevo Empleado
        </Button>
      }/>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {summaryStats.map(stat => (
            <KPICard key={stat.label} kpi={stat} />
        ))}
      </div>

      <Card className="mb-6">
        <div className="p-4">
          <TextInput
            label="Buscar Empleado (Nombre, Puesto, Contacto)"
            placeholder="Escriba para buscar..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            containerClassName="mb-0"
          />
        </div>
      </Card>
      
      <Table columns={employeeColumns} data={filteredEmployees} />

      {/* Employee Form Modal */}
      {isEmployeeModalOpen && (
        <Modal
          isOpen={isEmployeeModalOpen}
          onClose={handleCloseEmployeeModal}
          title={currentEmployee ? 'Editar Empleado' : 'Registrar Nuevo Empleado'}
          size="lg"
        >
          <EmployeeForm
            initialData={currentEmployee}
            onSave={handleSaveEmployee}
            onCancel={handleCloseEmployeeModal}
          />
        </Modal>
      )}

      {/* Employee Detail & Transactions Modal */}
      {isDetailModalOpen && selectedEmployeeForDetail && (
        <Modal
            isOpen={isDetailModalOpen}
            onClose={handleCloseDetailModal}
            title={`Detalles de ${selectedEmployeeForDetail.fullName}`}
            size="xl"
        >
            <div className="space-y-6">
                <Card title="Información del Empleado">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                        <p><strong>Puesto:</strong> {selectedEmployeeForDetail.position}</p>
                        <p><strong>Fecha Contratación:</strong> {new Date(selectedEmployeeForDetail.hireDate).toLocaleDateString()}</p>
                        <p><strong>Salario Base:</strong> ${selectedEmployeeForDetail.baseSalary.toFixed(2)}</p>
                        <p><strong>Contacto:</strong> {selectedEmployeeForDetail.contactInfo}</p>
                        <p><strong>Cuenta Bancaria:</strong> {selectedEmployeeForDetail.bankAccount || 'N/A'}</p>
                        <p><strong>Estado:</strong> {selectedEmployeeForDetail.isActive ? 'Activo' : 'Inactivo'}</p>
                        {selectedEmployeeForDetail.notes && <p className="md:col-span-2"><strong>Notas:</strong> {selectedEmployeeForDetail.notes}</p>}
                    </div>
                </Card>

                <Card title="Resumen Financiero del Empleado">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                        <div className="p-3 bg-background rounded shadow"><p className="text-muted-foreground">Total Pagado (Salarios, Bonos, Anticipos):</p><p className="font-semibold text-lg">${employeeFinancialSummary.totalPaid.toFixed(2)}</p></div>
                        <div className="p-3 bg-background rounded shadow"><p className="text-muted-foreground">Total Préstamos Otorgados:</p><p className="font-semibold text-lg">${employeeFinancialSummary.totalLoansGiven.toFixed(2)}</p></div>
                        <div className={`p-3 bg-background rounded shadow ${employeeFinancialSummary.loanBalance > 0 ? 'text-danger' : 'text-success'}`}><p className="text-muted-foreground">Saldo Préstamos Pendiente:</p><p className="font-semibold text-lg">${employeeFinancialSummary.loanBalance.toFixed(2)}</p></div>
                    </div>
                </Card>

                <Card title="Movimientos Financieros" titleAction={
                    <Button onClick={() => handleOpenTransactionModal(null, selectedEmployeeForDetail)} size="sm" leftIcon={<Icon name="plus" className="w-4 h-4"/>}>
                        Nuevo Movimiento
                    </Button>
                }>
                    <Table 
                        columns={transactionColumns} 
                        data={transactions.filter(t => t.employeeId === selectedEmployeeForDetail.id).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())}
                        emptyMessage="No hay movimientos financieros para este empleado."
                    />
                </Card>
            </div>
        </Modal>
      )}

      {/* Employee Transaction Form Modal */}
      {isTransactionModalOpen && currentEmployeeForTransaction && (
        <Modal
            isOpen={isTransactionModalOpen}
            onClose={handleCloseTransactionModal}
            title={currentTransaction ? 'Editar Movimiento Financiero' : 'Nuevo Movimiento Financiero'}
            size="md"
        >
            <EmployeeTransactionForm
                initialData={currentTransaction}
                onSave={handleSaveTransaction}
                onCancel={handleCloseTransactionModal}
                employeeName={currentEmployeeForTransaction.fullName}
            />
        </Modal>
      )}

    </div>
  );
};

export default EmployeesPage;

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
    MarketingCampaign, SocialMediaPost, EmailMarketingCampaign, KPIData,
    MarketingCampaignStatus, SocialMediaPlatform, SocialMediaPostStatus, EmailCampaignStatus,
    AccountingEntry, AccountingEntryType, AccountingExpenseCategory, AppSettings
} from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Modal from '../../components/common/Modal';
import Table, { TableColumn } from '../../components/common/Table';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import CampaignForm from '../../components/marketing/CampaignForm';
import SocialPostForm from '../../components/marketing/SocialPostForm';
import EmailCampaignForm from '../../components/marketing/EmailCampaignForm';
import SocialMediaCalendarView from '../../components/marketing/SocialMediaCalendarView';
import useMockData from '../../hooks/useMockData';
import {
    MOCK_MARKETING_CAMPAIGNS_DATA_KEY, MOCK_SOCIAL_MEDIA_POSTS_DATA_KEY, MOCK_EMAIL_CAMPAIGNS_DATA_KEY,
    MOCK_ACCOUNTING_ENTRIES_DATA_KEY, APP_SETTINGS_KEY, APP_NAME,
    MARKETING_CAMPAIGN_STATUS_OPTIONS, SOCIAL_MEDIA_PLATFORM_OPTIONS, SOCIAL_MEDIA_POST_STATUS_OPTIONS, EMAIL_CAMPAIGN_STATUS_OPTIONS
} from '../../constants';

const initialCampaigns: MarketingCampaign[] = [
    { id: 'camp1', name: 'Promoción Verano 2024', description: 'Campaña para atraer turistas en verano.', startDate: '2024-06-01', endDate: '2024-08-31', budget: 5000, status: MarketingCampaignStatus.ACTIVA, channels: ['Redes Sociales', 'Email'], createdAt: new Date().toISOString() },
    { id: 'camp2', name: 'Oferta Fin de Semana Romántico', description: 'Paquetes para parejas.', startDate: '2024-09-01', endDate: '2024-09-30', budget: 2500, status: MarketingCampaignStatus.PLANIFICADA, channels: ['Email', 'Anuncios Locales'], createdAt: new Date().toISOString() },
];
const initialSocialPosts: SocialMediaPost[] = [
    { id: 'post1', campaignId: 'camp1', platform: SocialMediaPlatform.INSTAGRAM, content: '¡Disfruta del sol este verano con nosotros! #VeranoHotel', scheduledDateTime: new Date(Date.now() + 2*24*60*60*1000).toISOString(), status: SocialMediaPostStatus.PROGRAMADO, createdAt: new Date().toISOString() },
    { id: 'post2', platform: SocialMediaPlatform.FACEBOOK, content: 'Foto del atardecer desde nuestra terraza. ¡Reserva ya!', scheduledDateTime: new Date(Date.now() - 1*24*60*60*1000).toISOString(), status: SocialMediaPostStatus.PUBLICADO, likes: 150, comments: 20, createdAt: new Date().toISOString() },
];
const initialEmailCampaigns: EmailMarketingCampaign[] = [
    { id: 'email1', campaignId: 'camp1', name: 'Newsletter Verano - Julio', subject: '☀️ Ofertas de Verano Imperdibles ☀️', targetAudienceDescription: 'Suscriptores Newsletter', contentPreview: 'Descubre nuestros paquetes de verano...', scheduledSendDateTime: new Date(Date.now() + 5*24*60*60*1000).toISOString(), status: EmailCampaignStatus.PROGRAMADA, createdAt: new Date().toISOString() },
];

type ActiveTab = 'campaigns' | 'socialCalendar' | 'socialList' | 'emailCampaigns'; // Added 'socialList'

const MarketingPage: React.FC = () => {
    const [campaigns, setCampaigns] = useMockData<MarketingCampaign>(MOCK_MARKETING_CAMPAIGNS_DATA_KEY, initialCampaigns);
    const [socialPosts, setSocialPosts] = useMockData<SocialMediaPost>(MOCK_SOCIAL_MEDIA_POSTS_DATA_KEY, initialSocialPosts);
    const [emailCampaigns, setEmailCampaigns] = useMockData<EmailMarketingCampaign>(MOCK_EMAIL_CAMPAIGNS_DATA_KEY, initialEmailCampaigns);
    const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, []);

    const [activeTab, setActiveTab] = useState<ActiveTab>('campaigns');
    
    const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
    const [currentCampaign, setCurrentCampaign] = useState<MarketingCampaign | null>(null);

    const [isSocialPostModalOpen, setIsSocialPostModalOpen] = useState(false);
    const [currentSocialPost, setCurrentSocialPost] = useState<SocialMediaPost | null>(null);
    const [prefillSocialPostDate, setPrefillSocialPostDate] = useState<string | undefined>(undefined);


    const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
    const [currentEmailCampaign, setCurrentEmailCampaign] = useState<EmailMarketingCampaign | null>(null);
    
    const [appSettings, setAppSettings] = useState<AppSettings>({
        appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
         defaultKitchenOverheadRate: 0.10, defaultAdminSalesOverheadRate: 0.15,
        defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomFooterText: '',
        reportCustomHeaderText: '', reservationPolicies: '', cancellationPolicies: '',
        generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
        weatherWidgetHref: '', weatherWidgetDataLabel: '',
    });

    useEffect(() => {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            try {
                const parsed = JSON.parse(storedSettings) as AppSettings;
                setAppSettings(prev => ({ ...prev, ...parsed }));
            } catch(e) { console.error("Error parsing app settings in MarketingPage", e); }
        }
    }, []);


    const marketingKPIs = useMemo(() => {
        const activeCampaigns = campaigns.filter(c => c.status === MarketingCampaignStatus.ACTIVA).length;
        const scheduledPosts = socialPosts.filter(p => p.status === SocialMediaPostStatus.PROGRAMADO && new Date(p.scheduledDateTime) > new Date()).length;
        const scheduledEmails = emailCampaigns.filter(e => e.status === EmailCampaignStatus.PROGRAMADA && new Date(e.scheduledSendDateTime) > new Date()).length;
        const totalBudgetActive = campaigns
            .filter(c => c.status === MarketingCampaignStatus.ACTIVA && c.budget)
            .reduce((sum, c) => sum + (c.budget || 0), 0);

        return [
            { label: 'Campañas Activas', value: activeCampaigns, icon: <Icon name="bullhorn" className="w-6 h-6 text-primary" /> },
            { label: 'Publicaciones Sociales Programadas', value: scheduledPosts, icon: <Icon name="calendar" className="w-6 h-6 text-info" /> },
            { label: 'Campañas Email Programadas', value: scheduledEmails, icon: <Icon name="mail" className="w-6 h-6 text-accent" /> },
            { label: 'Presupuesto Total (Camp. Activas)', value: `$${totalBudgetActive.toFixed(2)}`, icon: <Icon name="cash" className="w-6 h-6 text-success" /> },
        ];
    }, [campaigns, socialPosts, emailCampaigns]);

    // Campaign CRUD
    const handleOpenCampaignModal = (campaign: MarketingCampaign | null = null) => {
        setCurrentCampaign(campaign);
        setIsCampaignModalOpen(true);
    };
    const handleSaveCampaign = (data: Omit<MarketingCampaign, 'id' | 'createdAt' | 'updatedAt'> & { id?: string, associatedCost?: number }) => {
        const { associatedCost, ...campaignData } = data;
        let savedCampaign: MarketingCampaign;
        const now = new Date().toISOString();

        if (campaignData.id) {
            savedCampaign = { ...campaigns.find(c=>c.id === campaignData.id)!, ...campaignData, updatedAt: now };
            setCampaigns(prev => prev.map(c => c.id === campaignData.id ? savedCampaign : c));
        } else {
            savedCampaign = { ...campaignData, id: `camp-${Date.now()}`, createdAt: now, updatedAt: now };
            setCampaigns(prev => [...prev, savedCampaign]);
        }
        if (associatedCost && associatedCost > 0 && !campaignData.id) { // Only for new campaigns
            const accountingEntry: AccountingEntry = {
                id: `acc-mkcamp-${Date.now()}`,
                date: savedCampaign.startDate,
                type: AccountingEntryType.EXPENSE,
                category: AccountingExpenseCategory.MARKETING_CAMPAIGN,
                description: `Gasto Campaña Marketing: ${savedCampaign.name}`,
                amount: associatedCost,
                createdAt: now,
                marketingCampaignId: savedCampaign.id,
            };
            setAccountingEntries(prev => [...prev, accountingEntry]);
        }
        setIsCampaignModalOpen(false);
        setCurrentCampaign(null);
    };
    const handleDeleteCampaign = (id: string) => {
        if (window.confirm('¿Eliminar esta campaña de marketing?')) {
            setCampaigns(prev => prev.filter(c => c.id !== id));
        }
    };

    // Social Post CRUD
    const handleOpenSocialPostModal = (post: SocialMediaPost | null = null, date?: string) => {
        setCurrentSocialPost(post);
        setPrefillSocialPostDate(date);
        setIsSocialPostModalOpen(true);
    };
     const handleSaveSocialPost = (data: Omit<SocialMediaPost, 'id'|'createdAt'|'updatedAt'> & {id?: string}) => {
        const now = new Date().toISOString();
        if (data.id) {
            setSocialPosts(prev => prev.map(p => p.id === data.id ? {...p, ...data, updatedAt: now} : p));
        } else {
            setSocialPosts(prev => [...prev, {...data, id: `spost-${Date.now()}`, createdAt: now, updatedAt: now}]);
        }
        setIsSocialPostModalOpen(false);
        setCurrentSocialPost(null);
        setPrefillSocialPostDate(undefined);
    };
    const handleDeleteSocialPost = (id: string) => {
        if (window.confirm('¿Eliminar esta publicación programada?')) {
            setSocialPosts(prev => prev.filter(p => p.id !== id));
        }
    };

    // Email Campaign CRUD
    const handleOpenEmailCampaignModal = (emailCamp: EmailMarketingCampaign | null = null) => {
        setCurrentEmailCampaign(emailCamp);
        setIsEmailModalOpen(true);
    };
    const handleSaveEmailCampaign = (data: Omit<EmailMarketingCampaign, 'id'|'createdAt'|'updatedAt'> & {id?: string}) => {
        const now = new Date().toISOString();
        if (data.id) {
            setEmailCampaigns(prev => prev.map(ec => ec.id === data.id ? {...ec, ...data, updatedAt: now} : ec));
        } else {
            setEmailCampaigns(prev => [...prev, {...data, id: `emailc-${Date.now()}`, createdAt: now, updatedAt: now}]);
        }
        setIsEmailModalOpen(false);
        setCurrentEmailCampaign(null);
    };
    const handleDeleteEmailCampaign = (id: string) => {
         if (window.confirm('¿Eliminar esta campaña de email?')) {
            setEmailCampaigns(prev => prev.filter(ec => ec.id !== id));
        }
    };

    const getSocialPostStatusClass = (status: SocialMediaPostStatus) => {
        switch (status) {
            case SocialMediaPostStatus.PROGRAMADO: return 'bg-info/20 text-info';
            case SocialMediaPostStatus.PUBLICADO: return 'bg-success/20 text-success';
            case SocialMediaPostStatus.BORRADOR: return 'bg-gray-200 text-gray-700';
            case SocialMediaPostStatus.FALLIDO: return 'bg-danger/20 text-danger';
            case SocialMediaPostStatus.ARCHIVADO: return 'bg-muted-foreground/20 text-muted-foreground';
            default: return 'bg-gray-100 text-gray-600';
        }
    };

    const campaignColumns: TableColumn<MarketingCampaign>[] = [
        { header: 'Nombre Campaña', accessor: 'name', className: 'font-semibold' },
        { header: 'Estado', accessor: item => <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${item.status === MarketingCampaignStatus.ACTIVA ? 'bg-success/20 text-success' : item.status === MarketingCampaignStatus.PLANIFICADA ? 'bg-info/20 text-info' : 'bg-muted-foreground/20 text-muted-foreground'}`}>{item.status}</span> },
        { header: 'Fechas', accessor: item => `${new Date(item.startDate).toLocaleDateString()} - ${new Date(item.endDate).toLocaleDateString()}` },
        { header: 'Presupuesto', accessor: item => item.budget ? `$${item.budget.toFixed(2)}` : 'N/A', className: 'text-right' },
        { header: 'Canales', accessor: item => item.channels?.join(', ') || 'N/A' },
        {
            header: 'Acciones',
            accessor: item => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenCampaignModal(item)}><Icon name="edit" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteCampaign(item.id)} className="text-danger"><Icon name="trash" /></Button>
                </div>
            )
        }
    ];
    
    const socialPostTableColumns: TableColumn<SocialMediaPost>[] = [
        { 
            header: 'Campaña', 
            accessor: item => campaigns.find(c => c.id === item.campaignId)?.name || <span className="italic text-muted-foreground">N/A</span>,
            className: 'truncate max-w-xs'
        },
        { header: 'Plataforma', accessor: 'platform' },
        { 
            header: 'Contenido', 
            accessor: item => <span title={item.content}>{item.content.substring(0, 50) + (item.content.length > 50 ? '...' : '')}</span>,
            className: 'truncate max-w-sm'
        },
        { header: 'Fecha Programada', accessor: item => new Date(item.scheduledDateTime).toLocaleString('es-ES', {dateStyle:'short', timeStyle:'short'}) },
        { 
            header: 'Estado', 
            accessor: item => <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getSocialPostStatusClass(item.status)}`}>{item.status}</span> 
        },
        {
            header: 'Acciones',
            accessor: item => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenSocialPostModal(item)} title="Editar"><Icon name="edit" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteSocialPost(item.id)} className="text-danger" title="Eliminar"><Icon name="trash" /></Button>
                </div>
            )
        }
    ];

    const emailCampaignColumns: TableColumn<EmailMarketingCampaign>[] = [
        { header: 'Nombre', accessor: 'name', className: 'font-semibold' },
        { header: 'Asunto', accessor: 'subject', className: 'truncate max-w-xs' },
        { header: 'Público Objetivo', accessor: 'targetAudienceDescription', className: 'truncate max-w-xs' },
        { header: 'Fecha Envío Programada', accessor: item => new Date(item.scheduledSendDateTime).toLocaleString('es-ES', {dateStyle:'short', timeStyle:'short'}) },
        { header: 'Estado', accessor: 'status' },
        {
            header: 'Acciones',
            accessor: item => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenEmailCampaignModal(item)}><Icon name="edit" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteEmailCampaign(item.id)} className="text-danger"><Icon name="trash" /></Button>
                </div>
            )
        }
    ];


    const renderActiveTabContent = () => {
        switch (activeTab) {
            case 'campaigns':
                return (
                    <Card title="Listado de Campañas de Marketing" titleAction={<Button onClick={() => handleOpenCampaignModal()} leftIcon={<Icon name="plus"/>} size="sm">Nueva Campaña</Button>}>
                        <Table columns={campaignColumns} data={campaigns} />
                    </Card>
                );
            case 'socialCalendar':
                return (
                    <Card title="Calendario de Contenido para Redes Sociales" titleAction={<Button onClick={() => handleOpenSocialPostModal(null)} leftIcon={<Icon name="plus"/>} size="sm">Nueva Publicación</Button>}>
                       <SocialMediaCalendarView 
                            posts={socialPosts} 
                            onAddPost={handleOpenSocialPostModal}
                            onEditPost={(post) => handleOpenSocialPostModal(post)}
                            onDeletePost={handleDeleteSocialPost}
                       />
                    </Card>
                );
            case 'socialList': // New case for Social Post List
                return (
                    <Card title="Listado de Publicaciones Sociales" titleAction={<Button onClick={() => handleOpenSocialPostModal(null)} leftIcon={<Icon name="plus"/>} size="sm">Nueva Publicación</Button>}>
                       <Table columns={socialPostTableColumns} data={socialPosts} emptyMessage="No hay publicaciones sociales."/>
                    </Card>
                );
            case 'emailCampaigns':
                 return (
                    <Card title="Campañas de Email Marketing" titleAction={<Button onClick={() => handleOpenEmailCampaignModal()} leftIcon={<Icon name="plus"/>} size="sm">Nueva Campaña Email</Button>}>
                        <Table columns={emailCampaignColumns} data={emailCampaigns} />
                    </Card>
                );
            default:
                return null;
        }
    };
    
    const tabOptions: { id: ActiveTab; label: string; icon: React.ComponentProps<typeof Icon>['name'] }[] = [
        { id: 'campaigns', label: 'Campañas', icon: 'bullhorn' },
        { id: 'socialCalendar', label: 'Calendario Social', icon: 'calendar' },
        { id: 'socialList', label: 'Listado Publicaciones', icon: 'clipboardList' }, // New tab option
        { id: 'emailCampaigns', label: 'Campañas Email', icon: 'mail' },
    ];

    return (
        <div>
            <PageTitle title="Módulo de Marketing" />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {marketingKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
            </div>

            <div className="mb-6">
                <div className="flex border-b border-border-color overflow-x-auto">
                    {tabOptions.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center space-x-2 px-3 sm:px-4 py-2.5 text-sm font-medium focus:outline-none transition-colors duration-150 whitespace-nowrap
                                ${activeTab === tab.id
                                    ? 'border-b-2 border-primary text-primary'
                                    : 'text-muted-foreground hover:text-foreground border-b-2 border-transparent'}`}
                        >
                            <Icon name={tab.icon} className="w-4 h-4"/>
                            <span>{tab.label}</span>
                        </button>
                    ))}
                </div>
            </div>

            {renderActiveTabContent()}

            {isCampaignModalOpen && (
                <Modal isOpen={isCampaignModalOpen} onClose={() => {setIsCampaignModalOpen(false); setCurrentCampaign(null);}} title={currentCampaign ? "Editar Campaña de Marketing" : "Nueva Campaña de Marketing"} size="lg">
                    <CampaignForm
                        initialData={currentCampaign}
                        onSave={handleSaveCampaign}
                        onCancel={() => {setIsCampaignModalOpen(false); setCurrentCampaign(null);}}
                        statusOptions={MARKETING_CAMPAIGN_STATUS_OPTIONS}
                    />
                </Modal>
            )}
            
            {isSocialPostModalOpen && (
                <Modal isOpen={isSocialPostModalOpen} onClose={() => {setIsSocialPostModalOpen(false); setCurrentSocialPost(null);}} title={currentSocialPost ? "Editar Publicación Social" : "Nueva Publicación Social"} size="lg">
                    <SocialPostForm
                        initialData={currentSocialPost}
                        campaigns={campaigns}
                        platformOptions={SOCIAL_MEDIA_PLATFORM_OPTIONS}
                        statusOptions={SOCIAL_MEDIA_POST_STATUS_OPTIONS}
                        onSave={handleSaveSocialPost}
                        onCancel={() => {setIsSocialPostModalOpen(false); setCurrentSocialPost(null); setPrefillSocialPostDate(undefined);}}
                        prefillDate={prefillSocialPostDate}
                    />
                </Modal>
            )}

            {isEmailModalOpen && (
                <Modal isOpen={isEmailModalOpen} onClose={() => {setIsEmailModalOpen(false); setCurrentEmailCampaign(null);}} title={currentEmailCampaign ? "Editar Campaña de Email" : "Nueva Campaña de Email"} size="lg">
                    <EmailCampaignForm
                        initialData={currentEmailCampaign}
                        campaigns={campaigns}
                        statusOptions={EMAIL_CAMPAIGN_STATUS_OPTIONS}
                        onSave={handleSaveEmailCampaign}
                        onCancel={() => {setIsEmailModalOpen(false); setCurrentEmailCampaign(null);}}
                    />
                </Modal>
            )}

        </div>
    );
};

export default MarketingPage;

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { 
    GuestFeedback, FeedbackType, FeedbackSource, FeedbackStatus, 
    Customer, Reservation, Employee, KPIData, AppSettings, EnrichedGuestFeedback
} from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Modal from '../../components/common/Modal';
import Table, { TableColumn } from '../../components/common/Table';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import FeedbackForm from '../../components/feedback/FeedbackForm';
import FeedbackDetailModal from '../../components/feedback/FeedbackDetailModal'; // New Import
import useMockData from '../../hooks/useMockData';
import { 
    MOCK_GUEST_FEEDBACK_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_RESERVATIONS_DATA_KEY, 
    MOCK_EMPLOYEES_DATA_KEY, APP_SETTINGS_KEY, APP_NAME,
    FEEDBACK_TYPE_OPTIONS, FEEDBACK_SOURCE_OPTIONS, FEEDBACK_STATUS_OPTIONS
} from '../../constants';
import SelectInput from '../../components/common/SelectInput';
import TextInput from '../../components/common/TextInput';
import { generateFeedbackSummary } from '../../services/geminiService';

const initialFeedback: GuestFeedback[] = [
    { id: 'fb1', dateReceived: new Date(Date.now() - 2*24*60*60*1000).toISOString().split('T')[0], customerId: 'cust1', reservationId: 'res-cust1-1', type: FeedbackType.ELOGIO, source: FeedbackSource.VERBAL_PERSONAL, details: "El personal de recepción fue extremadamente amable y servicial. La habitación estaba impecable.", status: FeedbackStatus.CERRADO, createdAt: new Date().toISOString(), aiSummary: "Cliente elogió amabilidad y limpieza." },
    { id: 'fb2', dateReceived: new Date(Date.now() - 1*24*60*60*1000).toISOString().split('T')[0], guestNameManual: 'Huésped Anónimo (Hab 102)', type: FeedbackType.QUEJA, source: FeedbackSource.TARJETA_COMENTARIO, details: "El aire acondicionado de la habitación 102 hacía mucho ruido y no enfriaba bien. Tardaron en atender el reporte.", status: FeedbackStatus.EN_REVISION, departmentToInform: "Mantenimiento", createdAt: new Date().toISOString() },
    { id: 'fb3', dateReceived: new Date().toISOString().split('T')[0], customerId: 'cust2', type: FeedbackType.SUGERENCIA, source: FeedbackSource.EMAIL_DIRECTO, details: "Sería genial si ofrecieran más opciones vegetarianas en el menú del restaurante.", status: FeedbackStatus.NUEVO, departmentToInform: "Restaurante", createdAt: new Date().toISOString() },
];

const GuestFeedbackPage: React.FC = () => {
    const [feedbackEntries, setFeedbackEntries] = useMockData<GuestFeedback>(MOCK_GUEST_FEEDBACK_DATA_KEY, initialFeedback);
    const [customers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, []);
    const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, []);
    const [employees] = useMockData<Employee>(MOCK_EMPLOYEES_DATA_KEY, []);
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentFeedback, setCurrentFeedback] = useState<GuestFeedback | null>(null);
    const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
    const [aiSummaryResult, setAiSummaryResult] = useState('');

    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false); // New state for detail modal
    const [selectedFeedbackForDetail, setSelectedFeedbackForDetail] = useState<EnrichedGuestFeedback | null>(null); // New state

    const [filterType, setFilterType] = useState<FeedbackType | 'all'>('all');
    const [filterStatus, setFilterStatus] = useState<FeedbackStatus | 'all'>('all');
    const [filterSource, setFilterSource] = useState<FeedbackSource | 'all'>('all');
    const [searchTerm, setSearchTerm] = useState('');

    const [appSettings, setAppSettings] = useState<AppSettings>({
        appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
        defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomHeaderText: '',
        reportCustomFooterText: '', reservationPolicies: '', cancellationPolicies: '',
        generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
        weatherWidgetHref: '', weatherWidgetDataLabel: '', googleCalendarConnected: false,
        googleCalendarId: '', defaultKitchenOverheadRate: 0.1, defaultAdminSalesOverheadRate: 0.15
    });
     useEffect(() => {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            try {
                setAppSettings(JSON.parse(storedSettings));
            } catch(e) {console.error("Error parsing settings in FeedbackPage", e)}
        }
    }, []);


    const feedbackKPIs = useMemo(() => {
        const totalFeedback = feedbackEntries.length;
        const pendingReview = feedbackEntries.filter(f => f.status === FeedbackStatus.NUEVO || f.status === FeedbackStatus.EN_REVISION).length;
        const resolvedFeedback = feedbackEntries.filter(f => f.status === FeedbackStatus.RESUELTO || f.status === FeedbackStatus.CERRADO).length;
        
        const typeCounts = feedbackEntries.reduce((acc, f) => {
            acc[f.type] = (acc[f.type] || 0) + 1;
            return acc;
        }, {} as Record<FeedbackType, number>);
        const mostCommonType = Object.entries(typeCounts).sort(([,a],[,b]) => b-a)[0];

        return [
            { label: 'Total Feedback Recibido', value: totalFeedback, icon: <Icon name="chatBubbleLeftRight" className="w-6 h-6 text-primary"/> },
            { label: 'Pendientes de Revisión/Acción', value: pendingReview, icon: <Icon name="warning" className="w-6 h-6 text-warning"/> },
            { label: 'Resueltos/Cerrados', value: resolvedFeedback, icon: <Icon name="check" className="w-6 h-6 text-success"/> },
            { label: 'Tipo Más Común', value: mostCommonType ? `${mostCommonType[0]} (${mostCommonType[1]})` : 'N/A', icon: <Icon name="star" className="w-6 h-6 text-info"/> },
        ];
    }, [feedbackEntries]);

    const handleOpenModal = (feedback: GuestFeedback | null = null) => {
        setCurrentFeedback(feedback);
        setAiSummaryResult(''); 
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setCurrentFeedback(null);
    };

    const handleSaveFeedback = (data: Omit<GuestFeedback, 'id' | 'createdAt' | 'updatedAt' | 'aiSummary'> & { id?: string }) => {
        const now = new Date().toISOString();
        if (data.id) {
            const existingFeedback = feedbackEntries.find(f => f.id === data.id);
            setFeedbackEntries(prev => prev.map(f => f.id === data.id ? { ...existingFeedback!, ...data, updatedAt: now } : f));
        } else {
            setFeedbackEntries(prev => [...prev, { ...data, id: `fb-${Date.now()}`, createdAt: now, updatedAt: now, aiSummary: '' }]);
        }
        handleCloseModal();
    };

    const handleDeleteFeedback = (id: string) => {
        if (window.confirm('¿Está seguro de que desea eliminar este registro de feedback?')) {
            setFeedbackEntries(prev => prev.filter(f => f.id !== id));
        }
    };
    
    const handleGenerateAiSummary = useCallback(async (feedback: GuestFeedback | null) => {
        if (!feedback || !feedback.details) return;
        setAiSummaryLoading(true);
        setAiSummaryResult('');
        try {
            const summary = await generateFeedbackSummary(feedback.details);
            setAiSummaryResult(summary);
            // If editing currentFeedback, update its aiSummary for the form to reflect change.
            if (currentFeedback && currentFeedback.id === feedback.id) {
                setCurrentFeedback(prev => prev ? {...prev, aiSummary: summary} : null);
            }
            // Also update in the main list for persistence if the modal is saved later with this new summary
            setFeedbackEntries(prevEntries => prevEntries.map(f => f.id === feedback.id ? {...f, aiSummary: summary} : f));
        } catch (error) {
            console.error("Error generating AI summary for feedback:", error);
            setAiSummaryResult("Error al generar resumen con IA.");
        } finally {
            setAiSummaryLoading(false);
        }
    }, [currentFeedback, setFeedbackEntries]);

    const handleOpenDetailModal = (feedback: GuestFeedback) => {
        const customer = feedback.customerId ? customers.find(c => c.id === feedback.customerId) : undefined;
        const reservation = feedback.reservationId ? reservations.find(r => r.id === feedback.reservationId) : undefined;
        const employeeHandling = feedback.employeeHandlingId ? employees.find(e => e.id === feedback.employeeHandlingId) : undefined;
        
        setSelectedFeedbackForDetail({
            ...feedback,
            customer,
            reservation,
            employeeHandling
        });
        setIsDetailModalOpen(true);
    };

    const handleCloseDetailModal = () => {
        setIsDetailModalOpen(false);
        setSelectedFeedbackForDetail(null);
    };

    const filteredFeedbackEntries = useMemo(() => {
        return feedbackEntries.filter(f => {
            const typeMatch = filterType === 'all' || f.type === filterType;
            const statusMatch = filterStatus === 'all' || f.status === filterStatus;
            const sourceMatch = filterSource === 'all' || f.source === filterSource;
            const searchTermLower = searchTerm.toLowerCase();
            const searchMatch = searchTerm === '' ||
                                f.details.toLowerCase().includes(searchTermLower) ||
                                (f.guestNameManual && f.guestNameManual.toLowerCase().includes(searchTermLower)) ||
                                (f.customerId && customers.find(c=>c.id === f.customerId)?.fullName.toLowerCase().includes(searchTermLower)) ||
                                (f.departmentToInform && f.departmentToInform.toLowerCase().includes(searchTermLower)) ||
                                f.id.toLowerCase().includes(searchTermLower);
            return typeMatch && statusMatch && sourceMatch && searchMatch;
        }).sort((a,b) => new Date(b.dateReceived).getTime() - new Date(a.dateReceived).getTime() || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }, [feedbackEntries, filterType, filterStatus, filterSource, searchTerm, customers]);
    
    const getStatusClass = (status: FeedbackStatus) => {
        switch(status) {
            case FeedbackStatus.NUEVO: return 'bg-blue-100 text-blue-700';
            case FeedbackStatus.EN_REVISION: return 'bg-yellow-100 text-yellow-700';
            case FeedbackStatus.ACCION_REQUERIDA: return 'bg-orange-100 text-orange-700';
            case FeedbackStatus.RESUELTO: return 'bg-green-100 text-green-700';
            case FeedbackStatus.CERRADO: return 'bg-gray-200 text-gray-700';
            default: return 'bg-gray-100 text-gray-600';
        }
    };

    const feedbackColumns: TableColumn<GuestFeedback>[] = [
        { header: 'ID', accessor: (item) => <span className="font-mono text-xs">{item.id.slice(-6)}</span> },
        { header: 'Fecha Recibido', accessor: (item) => new Date(item.dateReceived).toLocaleDateString() },
        { 
            header: 'Huésped/Reserva', 
            accessor: (item) => {
                if (item.customerId) {
                    const customer = customers.find(c => c.id === item.customerId);
                    return customer ? `${customer.fullName} (Cliente)` : `ID Cliente: ${item.customerId}`;
                }
                if (item.reservationId) return `ID Reserva: ${item.reservationId}`;
                return item.guestNameManual || <span className="italic text-muted-foreground">Anónimo</span>;
            },
            className: 'truncate max-w-xs'
        },
        { header: 'Tipo', accessor: 'type' },
        { header: 'Fuente', accessor: 'source' },
        { header: 'Estado', accessor: (item) => <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusClass(item.status)}`}>{item.status}</span>},
        {
            header: 'Acciones',
            accessor: (item) => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenDetailModal(item)} title="Ver Ficha de Feedback">
                        <Icon name="eye" className="w-4 h-4 text-purple-600" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleOpenModal(item)} title="Editar Feedback"><Icon name="edit" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteFeedback(item.id)} className="text-danger" title="Eliminar Feedback"><Icon name="trash" /></Button>
                </div>
            )
        }
    ];
    
    const allTypeOptions = [{value: 'all', label: 'Todos los Tipos'}, ...FEEDBACK_TYPE_OPTIONS];
    const allStatusOptions = [{value: 'all', label: 'Todos los Estados'}, ...FEEDBACK_STATUS_OPTIONS];
    const allSourceOptions = [{value: 'all', label: 'Todas las Fuentes'}, ...FEEDBACK_SOURCE_OPTIONS];


    return (
        <div>
            <PageTitle title="Gestión de Feedback de Huéspedes" actionButton={
                <Button onClick={() => handleOpenModal(null)} leftIcon={<Icon name="plus" />}>
                    Registrar Feedback
                </Button>
            }/>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                {feedbackKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
            </div>
            
            <Card className="mb-6">
                <div className="p-4 space-y-4">
                    <TextInput
                        label="Buscar Feedback (Detalles, Huésped, ID, Depto.)"
                        placeholder="Escriba para buscar..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <SelectInput label="Filtrar por Tipo:" options={allTypeOptions} value={filterType} onChange={e => setFilterType(e.target.value as FeedbackType | 'all')} containerClassName="mb-0"/>
                        <SelectInput label="Filtrar por Estado:" options={allStatusOptions} value={filterStatus} onChange={e => setFilterStatus(e.target.value as FeedbackStatus | 'all')} containerClassName="mb-0"/>
                        <SelectInput label="Filtrar por Fuente:" options={allSourceOptions} value={filterSource} onChange={e => setFilterSource(e.target.value as FeedbackSource | 'all')} containerClassName="mb-0"/>
                    </div>
                </div>
            </Card>

            <Table columns={feedbackColumns} data={filteredFeedbackEntries} emptyMessage="No hay registros de feedback que coincidan con los filtros."/>

            {isModalOpen && (
                <Modal 
                    isOpen={isModalOpen} 
                    onClose={handleCloseModal} 
                    title={currentFeedback ? 'Editar Feedback de Huésped' : 'Registrar Nuevo Feedback'}
                    size="xl"
                >
                    <FeedbackForm
                        initialData={currentFeedback}
                        onSave={handleSaveFeedback}
                        onCancel={handleCloseModal}
                        customers={customers}
                        reservations={reservations}
                        employees={employees}
                        onGenerateAiSummary={() => handleGenerateAiSummary(currentFeedback)}
                        aiSummaryResult={aiSummaryResult}
                        aiSummaryLoading={aiSummaryLoading}
                    />
                </Modal>
            )}
            
            {isDetailModalOpen && selectedFeedbackForDetail && (
                <FeedbackDetailModal
                    isOpen={isDetailModalOpen}
                    onClose={handleCloseDetailModal}
                    feedbackData={selectedFeedbackForDetail}
                    appSettings={appSettings}
                />
            )}

        </div>
    );
};

export default GuestFeedbackPage;

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
    MaintenanceRequest, MaintenanceTaskStatus, MaintenanceUrgency, MaintenanceLocationType,
    KPIData, AccountingEntry, AccountingEntryType, AccountingExpenseCategory, Property, Employee, AppSettings
} from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Modal from '../../components/common/Modal';
import Table, { TableColumn } from '../../components/common/Table';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import MaintenanceRequestForm from '../../components/maintenance/MaintenanceRequestForm';
import MaintenanceRequestReportModal from '../../components/maintenance/MaintenanceRequestReportModal';
import useMockData from '../../hooks/useMockData';
import {
    MOCK_MAINTENANCE_REQUESTS_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY,
    MAINTENANCE_TASK_STATUS_OPTIONS, MAINTENANCE_URGENCY_OPTIONS, MAINTENANCE_LOCATION_TYPE_OPTIONS,
    APP_SETTINGS_KEY, APP_NAME, MOCK_PROPERTIES_DATA_KEY, MOCK_EMPLOYEES_DATA_KEY // Added MOCK_EMPLOYEES_DATA_KEY
} from '../../constants';
import SelectInput from '../../components/common/SelectInput';

// Using MOCK_PROPERTIES_DATA_KEY for properties if actual properties are needed
// const mockPropertiesForForm: Property[] = [ ... ]; // Can be removed if using actual data
// const mockEmployeesForForm: Employee[] = [ ... ]; // Can be removed if using actual data

const initialMaintenanceRequests: MaintenanceRequest[] = [
    { id: 'maint1', reportedDate: new Date(Date.now() - 3*24*60*60*1000).toISOString().split('T')[0], reportedBy: 'Ana Gómez (Limpieza)', locationType: MaintenanceLocationType.PROPIEDAD_HABITACION, propertyId: 'prop1', issueDescription: 'Grifo de baño gotea constantemente.', urgency: MaintenanceUrgency.MEDIA, status: MaintenanceTaskStatus.EN_PROGRESO, assignedToEmployeeId: 'emp1', createdAt: new Date().toISOString(), photoUrls:[] },
    { id: 'maint2', reportedDate: new Date(Date.now() - 1*24*60*60*1000).toISOString().split('T')[0], reportedBy: 'Luis (Recepción)', locationType: MaintenanceLocationType.AREA_COMUN, locationName: 'Lobby Principal', issueDescription: 'Luz principal del lobby parpadea.', urgency: MaintenanceUrgency.ALTA, status: MaintenanceTaskStatus.REPORTADO, createdAt: new Date().toISOString(), photoUrls:[] },
    { id: 'maint3', reportedDate: new Date(Date.now() - 5*24*60*60*1000).toISOString().split('T')[0], reportedBy: 'Chef Carlos', locationType: MaintenanceLocationType.AREA_RESTAURANTE, locationName: 'Cocina', issueDescription: 'Extractor de humo no funciona.', urgency: MaintenanceUrgency.CRITICA, status: MaintenanceTaskStatus.COMPLETADO, assignedToEmployeeId: 'emp1', actualCost: 150, completionDate: new Date(Date.now() - 4*24*60*60*1000).toISOString().split('T')[0], resolutionNotes: 'Motor del extractor reemplazado.', accountingEntryId: 'acc-maint3', createdAt: new Date().toISOString() },
];
const initialMaintenanceAccounting: AccountingEntry[] = [
    {id: 'acc-maint3', date: new Date(Date.now() - 4*24*60*60*1000).toISOString().split('T')[0], type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.MAINTENANCE, description: 'Reparación extractor cocina (Solicitud #maint3)', amount:150, createdAt: new Date().toISOString(), maintenanceRequestId:'maint3'}
];

interface SelectedReportData {
    request: MaintenanceRequest;
    assignedEmployee?: Employee;
    property?: Property;
}

const MaintenancePage: React.FC = () => {
    const [requests, setRequests] = useMockData<MaintenanceRequest>(MOCK_MAINTENANCE_REQUESTS_DATA_KEY, initialMaintenanceRequests);
    const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialMaintenanceAccounting);
    const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, []); // Load actual properties
    const [employees] = useMockData<Employee>(MOCK_EMPLOYEES_DATA_KEY, []); // Load actual employees


    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentRequest, setCurrentRequest] = useState<MaintenanceRequest | null>(null);

    const [filterStatus, setFilterStatus] = useState<MaintenanceTaskStatus | 'all'>('all');
    const [filterUrgency, setFilterUrgency] = useState<MaintenanceUrgency | 'all'>('all');
    const [filterLocationType, setFilterLocationType] = useState<MaintenanceLocationType | 'all'>('all');
    
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [selectedRequestForReportData, setSelectedRequestForReportData] = useState<SelectedReportData | null>(null);
    
    const [appSettings, setAppSettings] = useState<AppSettings>({
        appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
        defaultKitchenOverheadRate: 0.10, defaultAdminSalesOverheadRate: 0.15,
        defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomFooterText: '',
        reportCustomHeaderText: '', reservationPolicies: '', cancellationPolicies: '',
        generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
        weatherWidgetHref: '', weatherWidgetDataLabel: '',
    });

    useEffect(() => {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            try {
                const parsed = JSON.parse(storedSettings) as AppSettings;
                setAppSettings(prev => ({ ...prev, ...parsed }));
            } catch(e) { console.error("Error parsing app settings in MaintenancePage", e); }
        }
    }, []);


    const maintenanceKPIs = useMemo(() => {
        const openRequests = requests.filter(r => r.status !== MaintenanceTaskStatus.COMPLETADO && r.status !== MaintenanceTaskStatus.CANCELADO).length;
        const urgentCriticalOpen = requests.filter(r =>
            (r.urgency === MaintenanceUrgency.ALTA || r.urgency === MaintenanceUrgency.CRITICA) &&
            (r.status !== MaintenanceTaskStatus.COMPLETADO && r.status !== MaintenanceTaskStatus.CANCELADO)
        ).length;
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        const costThisMonth = requests
            .filter(r => r.status === MaintenanceTaskStatus.COMPLETADO && r.actualCost && r.completionDate &&
                new Date(r.completionDate).getMonth() === currentMonth && new Date(r.completionDate).getFullYear() === currentYear)
            .reduce((sum, r) => sum + (r.actualCost || 0), 0);
        const completedThisMonth = requests.filter(r => r.status === MaintenanceTaskStatus.COMPLETADO && r.completionDate &&
                new Date(r.completionDate).getMonth() === currentMonth && new Date(r.completionDate).getFullYear() === currentYear).length;

        return [
            { label: 'Solicitudes Abiertas', value: openRequests, icon: <Icon name="wrenchScrewdriver" className="w-6 h-6 text-primary" /> },
            { label: 'Urgentes/Críticas Pendientes', value: urgentCriticalOpen, icon: <Icon name="warning" className="w-6 h-6 text-danger" /> },
            { label: 'Costo Mantenimiento (Mes)', value: `$${costThisMonth.toFixed(2)}`, icon: <Icon name="cash" className="w-6 h-6 text-info" /> },
            { label: 'Tareas Completadas (Mes)', value: completedThisMonth, icon: <Icon name="check" className="w-6 h-6 text-success" /> },
        ];
    }, [requests]);

    const handleOpenModal = (request: MaintenanceRequest | null = null) => {
        setCurrentRequest(request);
        setIsModalOpen(true);
    };
    const handleCloseModal = () => {
        setIsModalOpen(false);
        setCurrentRequest(null);
    };

    const handleOpenReportModal = (request: MaintenanceRequest) => {
        const employeeDetails = request.assignedToEmployeeId ? employees.find(e => e.id === request.assignedToEmployeeId) : undefined;
        const propertyDetails = request.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION && request.propertyId
            ? properties.find(p => p.id === request.propertyId)
            : undefined;
        setSelectedRequestForReportData({ request, assignedEmployee: employeeDetails, property: propertyDetails });
        setIsReportModalOpen(true);
    };
    const handleCloseReportModal = () => {
        setIsReportModalOpen(false);
        setSelectedRequestForReportData(null);
    };


    const handleSaveMaintenanceRequest = useCallback((data: MaintenanceRequest) => {
        let savedRequest = { ...data };
        const now = new Date().toISOString();

        if (data.id && requests.some(r => r.id === data.id)) { 
            savedRequest = { ...requests.find(r => r.id === data.id)!, ...data, updatedAt: now };
            setRequests(prev => prev.map(r => r.id === data.id ? savedRequest : r));
        } else { 
            savedRequest = { ...data, id: `maint-${Date.now()}`, createdAt: now, updatedAt: now };
            setRequests(prev => [...prev, savedRequest]);
        }

        const existingAccEntry = accountingEntries.find(ae => ae.maintenanceRequestId === savedRequest.id);

        if (savedRequest.status === MaintenanceTaskStatus.COMPLETADO && savedRequest.actualCost && savedRequest.actualCost > 0) {
            const accEntryData: Omit<AccountingEntry, 'id'|'createdAt'> = {
                date: savedRequest.completionDate || now.split('T')[0],
                type: AccountingEntryType.EXPENSE,
                category: AccountingExpenseCategory.MAINTENANCE,
                description: `Mantenimiento: ${savedRequest.issueDescription.substring(0,30)}... (Solicitud #${savedRequest.id.slice(-6)})`,
                amount: savedRequest.actualCost,
                maintenanceRequestId: savedRequest.id,
            };
            if (existingAccEntry) {
                const updatedAccEntry = { ...existingAccEntry, ...accEntryData };
                setAccountingEntries(prev => prev.map(ae => ae.id === existingAccEntry.id ? updatedAccEntry : ae));
                savedRequest.accountingEntryId = existingAccEntry.id;
            } else {
                const newAccEntryId = `acc-maint-${Date.now()}`;
                setAccountingEntries(prev => [...prev, { ...accEntryData, id: newAccEntryId, createdAt: now }]);
                savedRequest.accountingEntryId = newAccEntryId;
            }
            if (savedRequest.id && (!data.id || data.accountingEntryId !== savedRequest.accountingEntryId)) {
                 setRequests(prev => prev.map(r => r.id === savedRequest.id ? savedRequest : r));
            }

        } else { 
            if (existingAccEntry) {
                setAccountingEntries(prev => prev.filter(ae => ae.id !== existingAccEntry.id));
                delete savedRequest.accountingEntryId;
                if(savedRequest.id) {
                    setRequests(prev => prev.map(r => r.id === savedRequest.id ? savedRequest : r));
                }
            }
        }
        
        handleCloseModal();
    }, [requests, setRequests, accountingEntries, setAccountingEntries]);

    const handleDeleteMaintenanceRequest = useCallback((id: string) => {
        if (window.confirm('¿Está seguro de que desea eliminar esta solicitud de mantenimiento?')) {
            const requestToDelete = requests.find(r => r.id === id);
            setRequests(prev => prev.filter(r => r.id !== id));
            if (requestToDelete?.accountingEntryId) {
                setAccountingEntries(prevAcc => prevAcc.filter(ae => ae.id !== requestToDelete!.accountingEntryId));
            }
        }
    }, [requests, setRequests, setAccountingEntries]);

    const filteredRequests = useMemo(() => {
        return requests.filter(req => {
            const statusMatch = filterStatus === 'all' || req.status === filterStatus;
            const urgencyMatch = filterUrgency === 'all' || req.urgency === filterUrgency;
            const locationTypeMatch = filterLocationType === 'all' || req.locationType === filterLocationType;
            return statusMatch && urgencyMatch && locationTypeMatch;
        }).sort((a, b) => new Date(b.reportedDate).getTime() - new Date(a.reportedDate).getTime());
    }, [requests, filterStatus, filterUrgency, filterLocationType]);
    
    const getUrgencyClass = (urgency: MaintenanceUrgency) => {
        switch(urgency) {
            case MaintenanceUrgency.CRITICA: return 'text-red-700 font-bold';
            case MaintenanceUrgency.ALTA: return 'text-danger';
            case MaintenanceUrgency.MEDIA: return 'text-warning';
            case MaintenanceUrgency.BAJA: return 'text-info';
            default: return 'text-muted-foreground';
        }
    };
    const getStatusClass = (status: MaintenanceTaskStatus) => {
        switch(status) {
            case MaintenanceTaskStatus.COMPLETADO: return 'bg-success/20 text-success';
            case MaintenanceTaskStatus.CANCELADO: return 'bg-muted-foreground/20 text-muted-foreground';
            case MaintenanceTaskStatus.EN_PROGRESO: return 'bg-blue-500/20 text-blue-600';
            case MaintenanceTaskStatus.EN_ESPERA: return 'bg-orange-500/20 text-orange-600';
            case MaintenanceTaskStatus.REPORTADO: return 'bg-info/20 text-info';
            default: return 'bg-gray-200/20 text-gray-700';
        }
    };

    const requestColumns: TableColumn<MaintenanceRequest>[] = [
        { header: 'ID', accessor: (item) => <span className="font-mono text-xs">{item.id.slice(-6)}</span>, className: 'w-20'},
        { header: 'Fecha Reporte', accessor: (item) => new Date(item.reportedDate).toLocaleDateString() },
        { header: 'Descripción', accessor: 'issueDescription', className: 'truncate max-w-sm' },
        { 
            header: 'Ubicación', 
            accessor: (item) => item.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION 
                ? properties.find(p=>p.id === item.propertyId)?.name || item.propertyId || 'N/A' 
                : item.locationName || 'N/A',
            className: 'truncate max-w-xs'
        },
        { header: 'Urgencia', accessor: (item) => <span className={getUrgencyClass(item.urgency)}>{item.urgency}</span> },
        { header: 'Estado', accessor: (item) => <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusClass(item.status)}`}>{item.status}</span>},
        { header: 'Asignado A', accessor: (item) => employees.find(e => e.id === item.assignedToEmployeeId)?.fullName.split(' ')[0] || <span className="text-muted-foreground italic">N/A</span> },
        {
            header: 'Acciones',
            accessor: (item) => (
                <div className="flex space-x-1 items-center">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenReportModal(item)} title="Ver Ficha de Reporte">
                        <Icon name="receipt" className="w-4 h-4 text-purple-600" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleOpenModal(item)} title="Editar/Ver Detalles">
                        <Icon name="edit" className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteMaintenanceRequest(item.id)} className="text-danger" title="Eliminar Solicitud">
                        <Icon name="trash" className="w-4 h-4" />
                    </Button>
                </div>
            ),
        },
    ];

    const allStatusOptions = [{value: 'all', label: 'Todos los Estados'}, ...MAINTENANCE_TASK_STATUS_OPTIONS];
    const allUrgencyOptions = [{value: 'all', label: 'Todas las Urgencias'}, ...MAINTENANCE_URGENCY_OPTIONS];
    const allLocationTypeOptions = [{value: 'all', label: 'Todos los Tipos'}, ...MAINTENANCE_LOCATION_TYPE_OPTIONS];


    return (
        <div>
            <PageTitle title="Gestión de Mantenimiento" actionButton={
                <Button onClick={() => handleOpenModal()} leftIcon={<Icon name="plus" />}>
                    Reportar Nueva Falla
                </Button>
            }/>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {maintenanceKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
            </div>

            <Card title="Solicitudes de Mantenimiento" className="mb-6">
                <div className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <SelectInput
                            label="Filtrar por Estado:"
                            options={allStatusOptions}
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value as MaintenanceTaskStatus | 'all')}
                            containerClassName="mb-0"
                        />
                        <SelectInput
                            label="Filtrar por Urgencia:"
                            options={allUrgencyOptions}
                            value={filterUrgency}
                            onChange={(e) => setFilterUrgency(e.target.value as MaintenanceUrgency | 'all')}
                            containerClassName="mb-0"
                        />
                        <SelectInput
                            label="Filtrar por Tipo de Ubicación:"
                            options={allLocationTypeOptions}
                            value={filterLocationType}
                            onChange={(e) => setFilterLocationType(e.target.value as MaintenanceLocationType | 'all')}
                            containerClassName="mb-0"
                        />
                    </div>
                    <Table columns={requestColumns} data={filteredRequests} emptyMessage="No hay solicitudes de mantenimiento que coincidan con los filtros."/>
                </div>
            </Card>

            {isModalOpen && (
                <Modal
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    title={currentRequest ? `Editar Solicitud de Mantenimiento: #${currentRequest.id.slice(-6)}` : 'Reportar Nueva Falla/Incidencia'}
                    size="xl"
                >
                    <MaintenanceRequestForm
                        initialData={currentRequest}
                        onSave={handleSaveMaintenanceRequest}
                        onCancel={handleCloseModal}
                        properties={properties} 
                        employees={employees} 
                    />
                </Modal>
            )}

            {isReportModalOpen && selectedRequestForReportData && (
                <MaintenanceRequestReportModal
                    isOpen={isReportModalOpen}
                    onClose={handleCloseReportModal}
                    requestData={selectedRequestForReportData}
                    appSettings={appSettings}
                />
            )}
        </div>
    );
};

export default MaintenancePage;

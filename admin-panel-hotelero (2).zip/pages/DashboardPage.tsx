
import React, { useMemo, useState, useCallback } from 'react';
import KPICard from '../components/dashboard/KPICard';
import { KPIData, AlertData, Reservation, Property, Customer, AccountingEntry, AccountingEntryType, ReservationStatus, AccountingExpenseCategory, AccountingIncomeCategory, DashboardReportSummary, ReportPeriodType, OrderStatus, RoomCleaningStatus } from '../types';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import PageTitle from '../components/common/PageTitle';
import useMockData from '../hooks/useMockData';
import { MOCK_RESERVATIONS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY } from '../constants';
import { Link, useNavigate } from 'react-router-dom';
import PropertyRevenueChart from '../components/dashboard/PropertyRevenueChart';
import DateInput from '../components/common/DateInput';
import DashboardReportModal from '../components/dashboard/DashboardReportModal';
import SelectInput from '../components/common/SelectInput'; 

const initialReservations: Reservation[] = [
    { id: 'res1', customerId: 'cust1', propertyId: 'prop1', checkInDate: new Date().toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 300, balanceDue: 0, createdAt: new Date().toISOString() },
    { id: 'res2', customerId: 'cust2', propertyId: 'prop2', checkInDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], numberOfGuests: 4, status: ReservationStatus.ADVANCE_PAID, advanceAmount: 100, totalPrice: 400, balanceDue: 300, createdAt: new Date().toISOString() },
    { id: 'res-old-prop1', customerId: 'cust1', propertyId: 'prop1', checkInDate: '2024-01-10', checkOutDate: '2024-01-15', numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 750, balanceDue: 0, createdAt: '2024-01-01T00:00:00.000Z' },
    { id: 'res-old-prop2', customerId: 'cust2', propertyId: 'prop2', checkInDate: '2024-02-10', checkOutDate: '2024-02-15', numberOfGuests: 1, status: ReservationStatus.FULLY_PAID, totalPrice: 1000, balanceDue: 0, createdAt: '2024-02-01T00:00:00.000Z' },
    { id: 'res-old-prop1-adv', customerId: 'cust2', propertyId: 'prop1', checkInDate: '2024-03-10', checkOutDate: '2024-03-15', numberOfGuests: 3, status: ReservationStatus.ADVANCE_PAID, advanceAmount: 200, totalPrice: 750, balanceDue: 550, createdAt: '2024-03-01T00:00:00.000Z' },

];
const initialProperties: Property[] = [
    { id: 'prop1', name: 'Cabaña del Lago', description: 'Hermosa cabaña con vista al lago.', maxCapacity: 4, bedConfiguration: '1 Queen, 2 Twin', pricePerNight: 150, photoUrls: ['https://picsum.photos/seed/prop1/400/300'], calendarColor: 'bg-primary text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA, lastCleanedDate: new Date().toISOString().split('T')[0] },
    { id: 'prop2', name: 'Suite Montaña', description: 'Lujosa suite en la montaña.', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 200, photoUrls: ['https://picsum.photos/seed/prop2/400/300'], calendarColor: 'bg-accent text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
    { id: 'prop3', name: 'Apartamento Urbano', description: 'Moderno apartamento en el centro.', maxCapacity: 3, bedConfiguration: '1 Double, 1 Sofa Bed', pricePerNight: 120, photoUrls: ['https://picsum.photos/seed/prop3/400/300'], calendarColor: 'bg-emerald-500 text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.SUCIA },
];
const initialCustomers: Customer[] = [
    { id: 'cust1', fullName: 'Ana Pérez', phone: '555-1234', email: 'ana@example.com', createdAt: new Date().toISOString() },
    { id: 'cust2', fullName: 'Luis García', phone: '555-5678', createdAt: new Date().toISOString() },
];
const initialAccountingEntries: AccountingEntry[] = [
    { id: 'acc1', date: new Date().toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.HOSPEDAJE, description: 'Reserva #res1', amount: 300, createdAt: new Date().toISOString() },
    { id: 'acc2', date: new Date().toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.HOSPEDAJE, description: 'Anticipo Reserva #res2', amount: 100, createdAt: new Date().toISOString() },
    { id: 'acc3', date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.MAINTENANCE, description: 'Reparación Cabaña del Lago', amount: 50, createdAt: new Date().toISOString() },
    // Past entries for report testing
    { id: 'acc-past-inc', date: '2024-03-05', type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.EVENTOS, description: 'Evento Marzo', amount: 1200, createdAt: '2024-03-05T00:00:00.000Z' },
    { id: 'acc-past-exp', date: '2024-03-10', type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.STAFF, description: 'Nómina Marzo', amount: 400, createdAt: '2024-03-10T00:00:00.000Z' },
];


const DashboardPage: React.FC = () => {
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialProperties);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [customers, _setCustomers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialCustomers);
  const [accountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAccountingEntries);
  const navigate = useNavigate();

  const [selectedReportPeriod, setSelectedReportPeriod] = useState<ReportPeriodType>('current_month');
  const [customReportStartDate, setCustomReportStartDate] = useState<string>(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
  const [customReportEndDate, setCustomReportEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const [isDashboardReportModalOpen, setIsDashboardReportModalOpen] = useState(false);
  const [dashboardReportSummary, setDashboardReportSummary] = useState<DashboardReportSummary | null>(null);

  const today = new Date().toISOString().split('T')[0];
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const dailyOperations = useMemo(() => {
    const checkInsToday = reservations.filter(r => r.checkInDate === today && r.status !== ReservationStatus.CANCELLED).length;
    const checkOutsToday = reservations.filter(r => r.checkOutDate === today && r.status !== ReservationStatus.CANCELLED).length;
    return { checkInsToday, checkOutsToday };
  }, [reservations, today]);

  const kpis: KPIData[] = useMemo(() => {
    const totalProperties = properties.length;
    const occupiedPropertiesToday = new Set(
        reservations
        .filter(r => r.checkInDate <= today && r.checkOutDate > today && r.status !== ReservationStatus.CANCELLED) 
        .map(r => r.propertyId)
    ).size;
    const occupancyRate = totalProperties > 0 ? (occupiedPropertiesToday / totalProperties * 100).toFixed(1) : 0;
    
    const monthlyIncome = accountingEntries
        .filter(e => e.type === AccountingEntryType.INCOME && new Date(e.date).getMonth() === currentMonth && new Date(e.date).getFullYear() === currentYear)
        .reduce((sum, e) => sum + e.amount, 0);
    const monthlyBalance = monthlyIncome - accountingEntries
        .filter(e => e.type === AccountingEntryType.EXPENSE && new Date(e.date).getMonth() === currentMonth && new Date(e.date).getFullYear() === currentYear)
        .reduce((sum, e) => sum + e.amount, 0);

    return [
      { label: 'Check-ins Hoy', value: dailyOperations.checkInsToday, icon: <Icon name="check" className="w-6 h-6 text-success" /> },
      { label: 'Check-outs Hoy', value: dailyOperations.checkOutsToday, icon: <Icon name="arrowRight" className="w-6 h-6 text-danger" /> },
      { label: 'Ocupación Actual', value: `${occupancyRate}%`, icon: <Icon name="building" className="w-6 h-6 text-info" /> },
      { label: 'Ingresos (Mes)', value: `$${monthlyIncome.toFixed(2)}`, icon: <Icon name="cash" className="w-6 h-6 text-primary" /> },
      { label: 'Balance (Mes)', value: `$${monthlyBalance.toFixed(2)}`, icon: <Icon name="star" className="w-6 h-6 text-accent" /> },
    ];
  }, [properties, reservations, accountingEntries, dailyOperations, today, currentMonth, currentYear]);

  const alerts: AlertData[] = [ 
    { id: 'alert1', message: `${properties[0]?.name || 'Propiedad'} necesita revisión de AC.`, type: 'warning', link: `/properties` },
    { id: 'alert2', message: 'Bajo stock de amenities en almacén.', type: 'info' },
  ];
  
  const propertyRevenueData = useMemo(() => {
    const revenueMap = new Map<string, { name: string, revenue: number, color: string }>();
    properties.forEach(p => {
        revenueMap.set(p.id, { name: p.name, revenue: 0, color: p.calendarColor.split(' ').find(cls => cls.startsWith('bg-')) || 'bg-primary' });
    });

    reservations.forEach(r => {
        if (r.status === ReservationStatus.FULLY_PAID || r.status === ReservationStatus.ADVANCE_PAID) {
            const propData = revenueMap.get(r.propertyId);
            if (propData) {
                propData.revenue += r.totalPrice; 
            }
        }
    });
    return Array.from(revenueMap.entries()).map(([propertyId, data]) => ({
        propertyId,
        propertyName: data.name,
        revenue: data.revenue,
        color: data.color,
    })).sort((a,b) => b.revenue - a.revenue);
  }, [properties, reservations]);

  const handleGenerateDashboardReport = useCallback(() => {
    let sDate: Date;
    let eDate: Date;
    let periodLabel = "";
    const todayFull = new Date();

    switch (selectedReportPeriod) {
      case 'current_week':
        sDate = new Date(todayFull);
        sDate.setDate(todayFull.getDate() - todayFull.getDay() + (todayFull.getDay() === 0 ? -6 : 1)); // Monday
        sDate.setHours(0, 0, 0, 0);
        eDate = new Date(sDate);
        eDate.setDate(sDate.getDate() + 6); // Sunday
        eDate.setHours(23, 59, 59, 999);
        periodLabel = `Semana Actual (${sDate.toLocaleDateString('es-ES')} - ${eDate.toLocaleDateString('es-ES')})`;
        break;
      case 'current_month':
        sDate = new Date(todayFull.getFullYear(), todayFull.getMonth(), 1);
        eDate = new Date(todayFull.getFullYear(), todayFull.getMonth() + 1, 0, 23, 59, 59, 999);
        periodLabel = "Mes Actual";
        break;
      case 'current_year':
        sDate = new Date(todayFull.getFullYear(), 0, 1);
        eDate = new Date(todayFull.getFullYear(), 11, 31, 23, 59, 59, 999);
        periodLabel = "Año Actual";
        break;
      case 'custom_range':
        if (!customReportStartDate || !customReportEndDate || new Date(customReportEndDate) < new Date(customReportStartDate)) {
          alert("Por favor, seleccione un rango de fechas válido para el reporte personalizado.");
          return;
        }
        sDate = new Date(customReportStartDate + 'T00:00:00');
        eDate = new Date(customReportEndDate + 'T23:59:59');
        periodLabel = `Personalizado: ${sDate.toLocaleDateString('es-ES')} - ${eDate.toLocaleDateString('es-ES')}`;
        break;
      default: return;
    }


    const totalCheckIns = reservations.filter(r => 
        r.status !== ReservationStatus.CANCELLED &&
        new Date(r.checkInDate + 'T00:00:00') >= sDate && 
        new Date(r.checkInDate + 'T00:00:00') <= eDate
    ).length;

    const totalCheckOuts = reservations.filter(r => 
        r.status !== ReservationStatus.CANCELLED &&
        new Date(r.checkOutDate + 'T00:00:00') >= sDate && 
        new Date(r.checkOutDate + 'T00:00:00') <= eDate
    ).length;
    
    const relevantAccounting = accountingEntries.filter(entry => {
        const entryDate = new Date(entry.date + 'T00:00:00');
        return entryDate >= sDate && entryDate <= eDate;
    });

    const totalIncome = relevantAccounting.filter(e => e.type === AccountingEntryType.INCOME).reduce((sum, e) => sum + e.amount, 0);
    const totalExpenses = relevantAccounting.filter(e => e.type === AccountingEntryType.EXPENSE).reduce((sum, e) => sum + e.amount, 0);
    const netBalance = totalIncome - totalExpenses;

    let totalOccupancyPoints = 0;
    let daysInPeriod = 0;
    if (properties.length > 0) {
        for (let d = new Date(sDate); d <= eDate; d.setDate(d.getDate() + 1)) {
            daysInPeriod++;
            const dayStr = d.toISOString().split('T')[0];
            const occupiedOnDay = new Set(
                reservations
                .filter(r => r.checkInDate <= dayStr && r.checkOutDate > dayStr && r.status !== ReservationStatus.CANCELLED)
                .map(r => r.propertyId)
            ).size;
            totalOccupancyPoints += (occupiedOnDay / properties.length) * 100;
        }
    }
    const averageOccupancyRate = daysInPeriod > 0 ? totalOccupancyPoints / daysInPeriod : 0;
    
    setDashboardReportSummary({
      totalCheckIns,
      totalCheckOuts,
      averageOccupancyRate: parseFloat(averageOccupancyRate.toFixed(1)),
      totalIncome,
      totalExpenses,
      netBalance,
      startDate: sDate.toISOString().split('T')[0],
      endDate: eDate.toISOString().split('T')[0],
      periodTypeLabel: periodLabel,
      generatedAt: new Date().toISOString(),
    });
    setIsDashboardReportModalOpen(true);

  }, [customReportStartDate, customReportEndDate, selectedReportPeriod, reservations, properties, accountingEntries]);

  const reportPeriodOptions: {value: ReportPeriodType, label: string}[] = [
    { value: 'current_month', label: 'Mes Actual' },
    { value: 'current_week', label: 'Semana Actual' },
    { value: 'current_year', label: 'Año Actual' },
    { value: 'custom_range', label: 'Rango Personalizado' },
  ];


  return (
    <div>
      <PageTitle title="Panel de Control" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-8">
        {kpis.map((kpi, index) => (
          <KPICard key={index} kpi={kpi} />
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card title="Alertas Operativas" className="lg:col-span-1">
          {alerts.length > 0 ? (
            <ul className="space-y-3">
              {alerts.map(alert => (
                <li key={alert.id} className={`p-3 rounded-md flex items-start space-x-3 ${alert.type === 'warning' ? 'bg-warning/10 border border-warning/30' : 'bg-info/10 border border-info/30'}`}>
                  <Icon name={alert.type === 'warning' ? 'warning' : 'infoCircle'} className={`w-5 h-5 mt-0.5 ${alert.type === 'warning' ? 'text-warning' : 'text-info'}`} />
                  <div>
                    <p className={`text-sm ${alert.type === 'warning' ? 'text-yellow-700' : 'text-blue-700'}`}>{alert.message}</p>
                    {alert.link && <Link to={alert.link} className="text-xs text-primary hover:underline">Ver detalles</Link>}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted-foreground">No hay alertas.</p>
          )}
        </Card>

        <Card title="Ingresos por Propiedad (Ejemplo Histórico)" className="lg:col-span-2">
            <div className="p-2">
                <PropertyRevenueChart data={propertyRevenueData} />
            </div>
        </Card>
      </div>

      <Card title="Generar Reporte General del Panel" className="mb-8">
        <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <SelectInput
                    label="Seleccionar Periodo:"
                    options={reportPeriodOptions}
                    value={selectedReportPeriod}
                    onChange={(e) => setSelectedReportPeriod(e.target.value as ReportPeriodType)}
                    containerClassName="mb-0 md:col-span-1"
                />
                {selectedReportPeriod === 'custom_range' && (
                    <>
                        <DateInput
                            label="Fecha de Inicio:"
                            value={customReportStartDate}
                            onChange={(e) => setCustomReportStartDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                        <DateInput
                            label="Fecha de Fin:"
                            value={customReportEndDate}
                            onChange={(e) => setCustomReportEndDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                    </>
                )}
                 <div className={selectedReportPeriod === 'custom_range' ? "md:col-span-3" : "md:col-span-2"}>
                    <Button 
                        onClick={handleGenerateDashboardReport} 
                        leftIcon={<Icon name="documentText" className="w-5 h-5"/>} 
                        className="w-full md:self-end mt-4 md:mt-0"
                        disabled={(selectedReportPeriod === 'custom_range' && (!customReportStartDate || !customReportEndDate))}
                    >
                        Generar Reporte
                    </Button>
                 </div>
            </div>
        </div>
      </Card>

      <Card title="Acciones Rápidas">
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4"> {/* Changed to lg:grid-cols-5 */}
          <Button variant="primary" size="lg" leftIcon={<Icon name="plus" />} className="w-full" onClick={() => navigate('/reservations', { state: { openNewReservationModal: true } })}>
            Nueva Reserva
          </Button>
          <Button variant="secondary" size="lg" leftIcon={<Icon name="plus" />} className="w-full" onClick={() => navigate('/customers', { state: { openNewCustomerModal: true } })}>
            Nuevo Cliente
          </Button>
          <Button variant="secondary" size="lg" leftIcon={<Icon name="utensils" />} className="w-full" onClick={() => navigate('/restaurant', { state: { openNewOrderModal: true } })}> {/* New Comanda Button */}
            Nueva Comanda
          </Button>
           <Button variant="secondary" size="lg" leftIcon={<Icon name="plus" />} className="w-full" onClick={() => navigate('/properties', { state: { openNewPropertyModal: true } })}>
            Nueva Propiedad
          </Button>
          <Button variant="secondary" size="lg" leftIcon={<Icon name="cash" />} className="w-full" onClick={() => navigate('/accounting', { state: { openNewEntryModal: true, type: AccountingEntryType.EXPENSE } })}>
            Añadir Gasto
          </Button>
        </div>
      </Card>

      {isDashboardReportModalOpen && dashboardReportSummary && (
        <DashboardReportModal
            isOpen={isDashboardReportModalOpen}
            onClose={() => setIsDashboardReportModalOpen(false)}
            summary={dashboardReportSummary}
        />
      )}
    </div>
  );
};

export default DashboardPage;

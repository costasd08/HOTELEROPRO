
import React, { useState, useMemo, useCallback, ChangeEvent, useEffect } from 'react';
import { 
    MenuItem, Order, MenuItemCategory, OrderStatus, AccountingEntry, AccountingEntryType, 
    AccountingIncomeCategory, KPIData, ReportPeriodType, RestaurantReportSummary, PaymentMethod, 
    Reservation, Customer, Property, ReservationStatus, InventoryItem, AppSettings, MenuItemCostAnalysis,
    InventoryCategoryType, RoomCleaningStatus
} from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Modal from '../../components/common/Modal';
import Table, { TableColumn } from '../../components/common/Table';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import MenuItemForm from '../../components/restaurant/MenuItemForm';
import OrderForm from '../../components/restaurant/OrderForm';
import RestaurantReportModal from '../../components/restaurant/RestaurantReportModal';
import ImagePreviewModal from '../../components/common/ImagePreviewModal';
import MenuItemCostAnalysisModal from '../../components/restaurant/MenuItemCostAnalysisModal';
import MenuItemCostReceiptModal from '../../components/restaurant/MenuItemCostReceiptModal'; // New Import
import useMockData from '../../hooks/useMockData';
import { 
    MOCK_MENU_ITEMS_DATA_KEY, MOCK_ORDERS_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY, 
    MENU_ITEM_CATEGORY_OPTIONS, ORDER_STATUS_OPTIONS, PAYMENT_METHOD_OPTIONS,
    MOCK_RESERVATIONS_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY,
    MOCK_INVENTORY_ITEMS_DATA_KEY, APP_SETTINGS_KEY, APP_NAME, MOCK_MENU_ITEM_COST_ANALYSIS_DATA_KEY
} from '../../constants';
import SelectInput from '../../components/common/SelectInput';
import DateInput from '../../components/common/DateInput';
import { useLocation, useNavigate } from 'react-router-dom'; 

const initialMenuItems: MenuItem[] = [
    { id: 'menu1', name: 'Chilaquiles Verdes con Pollo', category: MenuItemCategory.DESAYUNO, productionCost: 35, sellingPrice: 95, isAvailable: true, createdAt: new Date().toISOString(), photoUrl: 'https://picsum.photos/seed/chilaquiles/200/150' },
    { id: 'menu2', name: 'Sopa de Tortilla', category: MenuItemCategory.COMIDA, productionCost: 25, sellingPrice: 70, isAvailable: true, createdAt: new Date().toISOString() },
    { id: 'menu3', name: 'Tacos al Pastor (Orden de 3)', category: MenuItemCategory.CENA, productionCost: 40, sellingPrice: 85, isAvailable: true, createdAt: new Date().toISOString(), photoUrl: 'https://picsum.photos/seed/tacos/200/150' },
    { id: 'menu4', name: 'Agua de Horchata (500ml)', category: MenuItemCategory.BEBIDA, productionCost: 10, sellingPrice: 30, isAvailable: true, createdAt: new Date().toISOString() },
    { id: 'menu5', name: 'Flan Napolitano', category: MenuItemCategory.POSTRE, productionCost: 20, sellingPrice: 55, isAvailable: false, createdAt: new Date().toISOString() },
];

const initialOrders: Order[] = [
    { id: 'order1', tableNumber: '5', items: [{ menuItemId: 'menu1', quantity: 1, sellingPriceAtOrderTime: 95 }, { menuItemId: 'menu4', quantity: 1, sellingPriceAtOrderTime: 30 }], totalAmount: 125, status: OrderStatus.PAGADO, paymentMethod: PaymentMethod.CARD, createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString().split('T')[0], isTakeAway: false, accountingEntryId: 'acc-order1' },
    { id: 'order2', customerName: 'Ana G.', items: [{ menuItemId: 'menu2', quantity: 2, sellingPriceAtOrderTime: 70 }], totalAmount: 140, status: OrderStatus.PENDIENTE, createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString().split('T')[0], isTakeAway: true },
    { id: 'order3', tableNumber: '3', items: [{ menuItemId: 'menu3', quantity: 1, sellingPriceAtOrderTime: 85, notes: "Con todo por favor" }], totalAmount: 85, status: OrderStatus.EN_PREPARACION, createdAt: new Date().toISOString().split('T')[0], isTakeAway: false },
    { id: 'order4', reservationId: 'res-active-1', items: [{menuItemId: 'menu1', quantity:1, sellingPriceAtOrderTime: 95}], totalAmount: 95, status: OrderStatus.PENDIENTE, createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString().split('T')[0], isTakeAway: false, customerName: 'Carlos Ruiz (Reserva)'}
];
const initialReservations: Reservation[] = [
    { id: 'res-active-1', customerId: 'cust-r1', propertyId: 'prop-r1', checkInDate: new Date().toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 300, balanceDue: 0, createdAt: new Date().toISOString() },
    { id: 'res-active-2', customerId: 'cust-r2', propertyId: 'prop-r2', checkInDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], numberOfGuests: 1, status: ReservationStatus.ADVANCE_PAID, totalPrice: 200, balanceDue: 100, createdAt: new Date().toISOString() },
];
const initialRestaurantCustomers: Customer[] = [
    { id: 'cust-r1', fullName: 'Carlos Ruiz (Reserva)', phone: '555-1111', email: 'carlos.res@example.com', createdAt: new Date().toISOString() },
    { id: 'cust-r2', fullName: 'Laura Solis (Reserva)', phone: '555-2222', createdAt: new Date().toISOString() },
];
const initialRestaurantProperties: Property[] = [
    { id: 'prop-r1', name: 'Cabaña Laguna', description: 'Cabaña cerca del agua.', maxCapacity: 4, bedConfiguration: '1 Queen', pricePerNight: 100, photoUrls: [], calendarColor: 'bg-blue-500 text-white', maintenanceLog:[], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
    { id: 'prop-r2', name: 'Suite Mirador', description: 'Suite con vista panorámica.', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 150, photoUrls: [], calendarColor: 'bg-teal-500 text-white', maintenanceLog:[], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
];
const initialInventoryItems: InventoryItem[] = [ 
    { id: 'inv-tomato', name: 'Tomate Saladette', category: InventoryCategoryType.RESTAURANTE, quantity: 10, unit: 'kg', purchasePrice: 20, createdAt: new Date().toISOString() },
    { id: 'inv-onion', name: 'Cebolla Blanca', category: InventoryCategoryType.RESTAURANTE, quantity: 5, unit: 'kg', purchasePrice: 15, createdAt: new Date().toISOString() },
];

const initialAccountingEntriesWithOrder: AccountingEntry[] = [
    { id: 'acc-order1', date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.RESTAURANT_INCOME, description: 'Ingreso Comanda #order1 (Mesa: 5)', amount: 125, orderId: 'order1', createdAt: new Date().toISOString() },
];


type OrderServiceTypeFilter = 'all' | 'DINE_IN' | 'GUEST_RESERVATION' | 'TAKE_AWAY_OTHER';

const formatDateDMMMYYYY = (dateString: string | undefined): string => {
    if (!dateString) return 'N/A';
    const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00Z');
    if (isNaN(dateObj.getTime())) {
      return "Fecha Inválida";
    }
    const day = dateObj.getUTCDate();
    const month = dateObj.toLocaleDateString('es-ES', { month: 'short', timeZone: 'UTC' }).replace('.', '').toUpperCase();
    const year = dateObj.getUTCFullYear();
    return `${day}/${month}/${year}`;
};


const RestaurantPage: React.FC = () => {
    const [menuItems, setMenuItems] = useMockData<MenuItem>(MOCK_MENU_ITEMS_DATA_KEY, initialMenuItems);
    const [orders, setOrders] = useMockData<Order>(MOCK_ORDERS_DATA_KEY, initialOrders);
    const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAccountingEntriesWithOrder);
    
    const [reservationsData] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
    const [customersData] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialRestaurantCustomers);
    const [propertiesData] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialRestaurantProperties);
    const [inventoryItems] = useMockData<InventoryItem>(MOCK_INVENTORY_ITEMS_DATA_KEY, initialInventoryItems);
    const [menuItemCostAnalyses, setMenuItemCostAnalyses] = useMockData<MenuItemCostAnalysis>(MOCK_MENU_ITEM_COST_ANALYSIS_DATA_KEY, []);

    const location = useLocation(); 
    const navigate = useNavigate(); 


    const [isMenuItemModalOpen, setIsMenuItemModalOpen] = useState(false);
    const [currentMenuItem, setCurrentMenuItem] = useState<MenuItem | null>(null);

    const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
    const [currentOrder, setCurrentOrder] = useState<Order | null>(null);

    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [reportData, setReportData] = useState<RestaurantReportSummary | null>(null);
    const [reportPeriod, setReportPeriod] = useState<ReportPeriodType>('current_month');
    const [customReportStart, setCustomReportStart] = useState<string>(new Date().toISOString().split('T')[0]);
    const [customReportEnd, setCustomReportEnd] = useState<string>(new Date().toISOString().split('T')[0]);
    
    const [filterMenuCategory, setFilterMenuCategory] = useState<MenuItemCategory | 'all'>('all');
    const [filterOrderServiceType, setFilterOrderServiceType] = useState<OrderServiceTypeFilter>('all');


    const [isImagePreviewModalOpen, setIsImagePreviewModalOpen] = useState(false);
    const [previewImageUrl, setPreviewImageUrl] = useState<string | undefined>(undefined);
    const [previewImageTitle, setPreviewImageTitle] = useState<string>('');

    const [isCostAnalysisModalOpen, setIsCostAnalysisModalOpen] = useState(false);
    const [selectedMenuItemForCostAnalysis, setSelectedMenuItemForCostAnalysis] = useState<MenuItem | null>(null);
    
    const [isCostReceiptModalOpen, setIsCostReceiptModalOpen] = useState(false); // New state for cost receipt modal
    const [selectedMenuItemForReceipt, setSelectedMenuItemForReceipt] = useState<{ item: MenuItem, analysis: MenuItemCostAnalysis } | null>(null); // New state

    const [appSettings, setAppSettings] = useState<AppSettings>({
        appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
        defaultKitchenOverheadRate: 0.10, defaultAdminSalesOverheadRate: 0.15,
        defaultCheckInTime: '14:00',
        defaultCheckOutTime: '12:00',
        reportCustomFooterText: '',
        reportCustomHeaderText: '',
        reservationPolicies: '',
        cancellationPolicies: '',
        generalObservations: '',
        otherPolicies: '',
        weatherWidgetEnabled: false,
        weatherWidgetHref: '',
        weatherWidgetDataLabel: '',
    });

    useEffect(() => {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            try {
                const parsed = JSON.parse(storedSettings);
                setAppSettings(prev => ({ ...prev, ...parsed }));
            } catch(e) { console.error("Error parsing settings", e); }
        }
    }, []);

    useEffect(() => {
        if (location.state?.openNewOrderModal) {
          handleOpenOrderModal(null); 
          navigate(location.pathname, { replace: true, state: {} }); 
        }
    }, [location.state, navigate]);


    const restaurantKPIs = useMemo(() => {
        const todayStr = new Date().toISOString().split('T')[0];
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        const salesToday = orders
            .filter(o => o.status === OrderStatus.PAGADO && o.createdAt.startsWith(todayStr))
            .reduce((sum, o) => sum + o.totalAmount, 0);

        const salesMonth = orders
            .filter(o => o.status === OrderStatus.PAGADO && new Date(o.createdAt).getMonth() === currentMonth && new Date(o.createdAt).getFullYear() === currentYear)
            .reduce((sum, o) => sum + o.totalAmount, 0);
        
        const activeOrdersToday = orders.filter(o => 
            o.createdAt.startsWith(todayStr) && 
            o.status !== OrderStatus.PAGADO && 
            o.status !== OrderStatus.CANCELADO
        ).length;

        const itemCounts: { [key: string]: { name: string, quantity: number } } = {};
        orders.filter(o => new Date(o.createdAt).getMonth() === currentMonth && new Date(o.createdAt).getFullYear() === currentYear && o.status === OrderStatus.PAGADO)
            .forEach(order => {
                order.items.forEach(item => {
                    const menuItem = menuItems.find(mi => mi.id === item.menuItemId);
                    if (menuItem) {
                        if (!itemCounts[item.menuItemId]) {
                            itemCounts[item.menuItemId] = { name: menuItem.name, quantity: 0 };
                        }
                        itemCounts[item.menuItemId].quantity += item.quantity;
                    }
                });
            });
        
        const mostSoldItemThisMonth = Object.values(itemCounts).sort((a,b) => b.quantity - a.quantity)[0];

        return [
            { label: 'Ventas de Hoy', value: `$${salesToday.toFixed(2)}`, icon: <Icon name="cash" className="w-6 h-6 text-success" /> },
            { label: 'Ventas del Mes', value: `$${salesMonth.toFixed(2)}`, icon: <Icon name="chartBar" className="w-6 h-6 text-primary" /> },
            { label: 'Órdenes Activas Hoy', value: activeOrdersToday, icon: <Icon name="utensils" className="w-6 h-6 text-info" /> },
            { label: 'Más Vendido (Mes)', value: mostSoldItemThisMonth ? `${mostSoldItemThisMonth.name} (${mostSoldItemThisMonth.quantity})` : 'N/A', icon: <Icon name="star" className="w-6 h-6 text-warning" /> },
        ];
    }, [orders, menuItems]);

    const handleOpenMenuItemModal = (item: MenuItem | null = null) => {
        setCurrentMenuItem(item);
        setIsMenuItemModalOpen(true);
    };
    const handleCloseMenuItemModal = () => {
        setIsMenuItemModalOpen(false);
        setCurrentMenuItem(null);
    };
    const handleSaveMenuItem = (data: Omit<MenuItem, 'id' | 'createdAt'> & { id?: string }) => {
        if (data.id) {
            setMenuItems(prev => prev.map(item => item.id === data.id ? { ...item, ...data } : item));
        } else {
            setMenuItems(prev => [...prev, { ...data, id: `menu-${Date.now()}`, createdAt: new Date().toISOString() }]);
        }
        handleCloseMenuItemModal();
    };
    const handleDeleteMenuItem = (id: string) => {
        if (window.confirm('¿Eliminar este platillo del menú? También se eliminará su análisis de costos si existe.')) {
            setMenuItems(prev => prev.filter(item => item.id !== id));
            setMenuItemCostAnalyses(prev => prev.filter(analysis => analysis.menuItemId !== id));
        }
    };
    const toggleMenuItemAvailability = (id: string) => {
        setMenuItems(prev => prev.map(item => item.id === id ? { ...item, isAvailable: !item.isAvailable } : item));
    };

    const filteredMenuItems = useMemo(() => {
        return menuItems.filter(item => filterMenuCategory === 'all' || item.category === filterMenuCategory);
    }, [menuItems, filterMenuCategory]);

    const handleOpenOrderModal = (order: Order | null = null) => {
        setCurrentOrder(order);
        setIsOrderModalOpen(true);
    };
    const handleCloseOrderModal = () => {
        setIsOrderModalOpen(false);
        setCurrentOrder(null);
    };
    
    const handleSaveOrder = (data: Omit<Order, 'id' | 'totalAmount' | 'accountingEntryId'> & { id?: string; status?: OrderStatus }) => {
        const orderTotal = data.items.reduce((sum, item) => sum + (item.sellingPriceAtOrderTime * item.quantity), 0);
        let savedOrder: Order;
        
        const isEditing = !!(data.id && orders.some(o => o.id === data.id));
        const originalOrder = isEditing ? orders.find(o => o.id === data.id) : null;
        
        const statusToSave = isEditing && data.status ? data.status : (isEditing && originalOrder ? originalOrder.status : OrderStatus.PENDIENTE);
        
        const createdAtToSave = data.createdAt || (isEditing && originalOrder ? originalOrder.createdAt : new Date().toISOString().split('T')[0]);


        if (isEditing && originalOrder) { 
            savedOrder = { 
                ...originalOrder, 
                ...data, 
                createdAt: createdAtToSave,
                totalAmount: orderTotal, 
                status: statusToSave,
                completedAt: (statusToSave === OrderStatus.PAGADO || statusToSave === OrderStatus.CANCELADO) ? (originalOrder.completedAt || new Date().toISOString()) : undefined 
            };
        } else { 
            savedOrder = { 
                ...data, 
                id: `order-${Date.now()}`, 
                createdAt: createdAtToSave, 
                totalAmount: orderTotal,
                status: statusToSave, 
                completedAt: (statusToSave === OrderStatus.PAGADO || statusToSave === OrderStatus.CANCELADO) ? new Date().toISOString() : undefined
            } as Order;
        }
        
        const existingAccountingEntry = accountingEntries.find(ae => ae.orderId === savedOrder.id);

        if (savedOrder.status === OrderStatus.PAGADO) {
            const accountingEntryData: Omit<AccountingEntry, 'id' | 'createdAt'> = {
                date: savedOrder.completedAt ? new Date(savedOrder.completedAt).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
                type: AccountingEntryType.INCOME,
                category: AccountingIncomeCategory.RESTAURANT_INCOME,
                description: `Ingreso Comanda #${savedOrder.id} (${savedOrder.customerName || savedOrder.tableNumber || 'N/A'})`,
                amount: savedOrder.totalAmount,
                orderId: savedOrder.id,
            };

            if (existingAccountingEntry) { 
                const updatedAccEntry = { ...existingAccountingEntry, ...accountingEntryData};
                setAccountingEntries(prevAcc => prevAcc.map(ae => ae.id === existingAccountingEntry.id ? updatedAccEntry : ae));
                savedOrder.accountingEntryId = existingAccountingEntry.id;
            } else { 
                const newAccEntryId = `acc-order-${Date.now()}`;
                setAccountingEntries(prevAcc => [...prevAcc, {...accountingEntryData, id: newAccEntryId, createdAt: new Date().toISOString()}]);
                savedOrder.accountingEntryId = newAccEntryId;
            }
        } else { 
            if (existingAccountingEntry) { 
                setAccountingEntries(prevAcc => prevAcc.filter(ae => ae.id !== existingAccountingEntry.id));
                delete savedOrder.accountingEntryId; 
            }
        }
        
        if (isEditing) {
            setOrders(prev => prev.map(o => o.id === savedOrder.id ? savedOrder : o));
        } else {
            setOrders(prev => [...prev, savedOrder]);
        }

        handleCloseOrderModal();
    };

    const handleDeleteOrder = (id: string) => {
        if (window.confirm('¿Eliminar esta comanda?')) {
            const orderToDelete = orders.find(o => o.id === id);
            setOrders(prev => prev.filter(order => order.id !== id));
            if (orderToDelete && orderToDelete.accountingEntryId) {
                setAccountingEntries(prevAcc => prevAcc.filter(ae => ae.id !== orderToDelete!.accountingEntryId));
            }
        }
    };


    const filteredOrders = useMemo(() => {
        return orders.filter(order => {
            if (filterOrderServiceType === 'all') return true;
            if (filterOrderServiceType === 'DINE_IN') {
                return !order.isTakeAway && !order.reservationId && !!order.tableNumber;
            }
            if (filterOrderServiceType === 'GUEST_RESERVATION') {
                return !!order.reservationId;
            }
            if (filterOrderServiceType === 'TAKE_AWAY_OTHER') {
                return order.isTakeAway || (!!order.customerName && !order.tableNumber && !order.reservationId);
            }
            return true;
        }).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }, [orders, filterOrderServiceType]);

    const handleGenerateReport = useCallback(() => {
        let startDate: Date;
        let endDate: Date;
        let periodLabel = "";
        const today = new Date();

        switch (reportPeriod) {
            case 'current_week':
                startDate = new Date(today.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)));
                endDate = new Date(new Date(startDate).setDate(startDate.getDate() + 6));
                periodLabel = "Semana Actual";
                break;
            case 'current_month':
                startDate = new Date(today.getFullYear(), today.getMonth(), 1);
                endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                periodLabel = "Mes Actual";
                break;
            case 'current_year':
                startDate = new Date(today.getFullYear(), 0, 1);
                endDate = new Date(today.getFullYear(), 11, 31);
                periodLabel = "Año Actual";
                break;
            case 'custom_range':
                if (!customReportStart || !customReportEnd || new Date(customReportEnd) < new Date(customReportStart)) {
                    alert("Seleccione un rango de fechas válido."); return;
                }
                startDate = new Date(customReportStart + 'T00:00:00');
                endDate = new Date(customReportEnd + 'T23:59:59');
                periodLabel = `Personalizado: ${startDate.toLocaleDateString('es-ES')} - ${endDate.toLocaleDateString('es-ES')}`;
                break;
            default: return;
        }

        const eDate = new Date(endDate); 
        eDate.setHours(23, 59, 59, 999); 

        const relevantOrders = orders.filter(o => {
            const orderDate = new Date(o.createdAt); 
            return orderDate >= startDate && orderDate <= eDate && o.status === OrderStatus.PAGADO;
        });

        const totalRev = relevantOrders.reduce((sum, o) => sum + o.totalAmount, 0);
        
        let totalProdCost = 0;
        const itemCounts: { [key: string]: { name: string, quantity: number } } = {};
        relevantOrders.forEach(order => {
            order.items.forEach(item => {
                const menuItem = menuItems.find(mi => mi.id === item.menuItemId);
                if (menuItem) {
                    totalProdCost += menuItem.productionCost * item.quantity;
                    if (!itemCounts[item.menuItemId]) itemCounts[item.menuItemId] = { name: menuItem.name, quantity: 0 };
                    itemCounts[item.menuItemId].quantity += item.quantity;
                }
            });
        });
        const mostSold = Object.values(itemCounts).sort((a,b) => b.quantity - a.quantity)[0];
        
        setReportData({
            totalOrders: relevantOrders.length,
            totalRevenue: totalRev,
            totalProductionCost: totalProdCost,
            netProfit: totalRev - totalProdCost,
            averageOrderValue: relevantOrders.length > 0 ? totalRev / relevantOrders.length : 0,
            mostSoldItem: mostSold,
            startDate: startDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0],
            periodTypeLabel: periodLabel,
            generatedAt: new Date().toISOString(),
        });
        setIsReportModalOpen(true);
    }, [orders, menuItems, reportPeriod, customReportStart, customReportEnd]);

    const handleOpenImagePreview = (imageUrl: string | undefined, title: string) => {
        setPreviewImageUrl(imageUrl);
        setPreviewImageTitle(title);
        setIsImagePreviewModalOpen(true);
    };

    const handleOpenCostAnalysisModal = (menuItem: MenuItem) => {
        setSelectedMenuItemForCostAnalysis(menuItem);
        setIsCostAnalysisModalOpen(true);
    };
    const handleCloseCostAnalysisModal = () => {
        setIsCostAnalysisModalOpen(false);
        setSelectedMenuItemForCostAnalysis(null);
    };
    const handleSaveCostAnalysis = (analysisData: MenuItemCostAnalysis) => {
        setMenuItemCostAnalyses(prev => {
            const existingIndex = prev.findIndex(a => a.id === analysisData.id);
            if (existingIndex > -1) {
                const updatedAnalyses = [...prev];
                updatedAnalyses[existingIndex] = analysisData;
                return updatedAnalyses;
            }
            return [...prev, analysisData];
        });
        if (analysisData.totalProductionCost !== undefined) {
            setMenuItems(prevItems => prevItems.map(item => 
                item.id === analysisData.menuItemId 
                ? { ...item, productionCost: analysisData.totalProductionCost! } 
                : item
            ));
        }
        handleCloseCostAnalysisModal();
    };

    const handleOpenCostReceiptModal = (item: MenuItem) => {
        const analysis = menuItemCostAnalyses.find(a => a.menuItemId === item.id);
        if (analysis) {
            setSelectedMenuItemForReceipt({ item, analysis });
            setIsCostReceiptModalOpen(true);
        } else {
            alert("No existe un análisis de costos para este platillo. Por favor, genere uno primero.");
        }
    };
    const handleCloseCostReceiptModal = () => {
        setIsCostReceiptModalOpen(false);
        setSelectedMenuItemForReceipt(null);
    };


    const menuItemColumns: TableColumn<MenuItem>[] = [
        { header: 'Platillo', accessor: 'name', className: 'font-semibold' },
        { header: 'Categoría', accessor: 'category' },
        { 
          header: 'Costo Prod.', 
          accessor: item => {
            const analysis = menuItemCostAnalyses.find(a => a.menuItemId === item.id);
            return `$${(analysis?.totalProductionCost ?? item.productionCost).toFixed(2)}`;
          }, 
          className: 'text-right' 
        },
        { header: 'Precio Venta', accessor: item => `$${item.sellingPrice.toFixed(2)}`, className: 'text-right' },
        { 
            header: 'Disponibilidad', 
            accessor: item => (
                <button 
                    onClick={(e) => { e.stopPropagation(); toggleMenuItemAvailability(item.id); }}
                    className={`px-2 py-1 text-xs rounded-full ${item.isAvailable ? 'bg-success/20 text-success hover:bg-success/30' : 'bg-danger/20 text-danger hover:bg-danger/30'}`}
                >
                    {item.isAvailable ? 'Disponible' : 'No Disponible'}
                </button>
            ),
            className: 'text-center'
        },
        {
            header: 'Acciones',
            accessor: (item) => {
                const analysisExists = menuItemCostAnalyses.some(a => a.menuItemId === item.id);
                return (
                    <div className="flex space-x-1 items-center">
                        {item.photoUrl && (
                            <Button variant="ghost" size="sm" onClick={() => handleOpenImagePreview(item.photoUrl, item.name)} title="Ver Imagen">
                                <Icon name="image" className="w-4 h-4 text-accent"/>
                            </Button>
                        )}
                        <Button variant="ghost" size="sm" onClick={() => handleOpenCostAnalysisModal(item)} title="Analizar Costo del Platillo">
                            <Icon name="chartPie" className="w-4 h-4 text-info"/>
                        </Button>
                         <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleOpenCostReceiptModal(item)} 
                            title="Ver/Descargar Ficha de Costo"
                            disabled={!analysisExists}
                            className={!analysisExists ? "opacity-50 cursor-not-allowed" : "text-purple-600 hover:text-purple-700"}
                        >
                            <Icon name="receipt" className="w-4 h-4"/>
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleOpenMenuItemModal(item)} title="Editar Platillo"><Icon name="edit" className="w-4 h-4"/></Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteMenuItem(item.id)} className="text-danger" title="Eliminar Platillo"><Icon name="trash" className="w-4 h-4"/></Button>
                    </div>
                );
            },
        },
    ];

    const orderColumns: TableColumn<Order>[] = [
        { header: 'ID Comanda', accessor: 'id', className: 'font-mono text-xs w-24 truncate' },
        { 
            header: 'Cliente/Mesa', 
            accessor: (item) => {
                if (item.isTakeAway) return `Llevar: ${item.customerName || 'N/A'}`;
                if (item.reservationId) {
                    const reservation = reservationsData.find(r => r.id === item.reservationId);
                    const customer = customersData.find(c => c.id === reservation?.customerId);
                    return `Reserva: ${customer?.fullName || 'Huésped'} (${item.reservationId.slice(0,8)}...)`;
                }
                return `Mesa: ${item.tableNumber || 'N/A'}`;
            },
            className: 'w-48 truncate'
        },
        { 
            header: 'Platillos', 
            accessor: (item) => (
                <ul className="text-xs list-disc list-inside">
                    {item.items.slice(0, 2).map(orderItem => {
                        const menuItem = menuItems.find(mi => mi.id === orderItem.menuItemId);
                        return <li key={orderItem.menuItemId} className="truncate" title={menuItem?.name}>{menuItem?.name || orderItem.menuItemId} (x{orderItem.quantity})</li>;
                    })}
                    {item.items.length > 2 && <li>y {item.items.length - 2} más...</li>}
                </ul>
            ),
            className: 'w-56' 
        },
        { header: 'Total', accessor: item => `$${item.totalAmount.toFixed(2)}`, className: 'text-right font-semibold' },
        { header: 'Fecha Comanda', accessor: item => formatDateDMMMYYYY(item.createdAt) },
        {
            header: 'Acciones',
            accessor: (item) => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenOrderModal(item)} title="Ver/Editar Comanda"><Icon name="edit" className="w-4 h-4"/></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteOrder(item.id)} className="text-danger" title="Eliminar Comanda"><Icon name="trash" className="w-4 h-4"/></Button>
                </div>
            ),
        },
    ];
    
    const reportPeriodOptions = [
        { value: 'current_month', label: 'Mes Actual' },
        { value: 'current_week', label: 'Semana Actual' },
        { value: 'current_year', label: 'Año Actual' },
        { value: 'custom_range', label: 'Rango Personalizado' },
    ];
    const categoryFilterOptions = [{value: 'all', label: 'Todas las Categorías'}, ...MENU_ITEM_CATEGORY_OPTIONS];
    
    const orderServiceTypeFilterOptions: {value: OrderServiceTypeFilter, label: string}[] = [
        {value: 'all', label: 'Todas las Comandas'},
        {value: 'DINE_IN', label: 'Por Mesa Local'},
        {value: 'GUEST_RESERVATION', label: 'Por Huésped (Reserva)'},
        {value: 'TAKE_AWAY_OTHER', label: 'Por Cliente (Llevar/Otro)'},
    ];

    const currentAnalysisData = selectedMenuItemForCostAnalysis 
        ? menuItemCostAnalyses.find(a => a.id === selectedMenuItemForCostAnalysis.id) || null
        : null;

    return (
        <div>
            <PageTitle title="Gestión de Restaurante" />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {restaurantKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
            </div>

            <Card title="Generar Reporte de Ventas del Restaurante" className="mb-6">
                <div className="p-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                        <SelectInput
                            label="Seleccionar Periodo:"
                            options={reportPeriodOptions}
                            value={reportPeriod}
                            onChange={(e) => setReportPeriod(e.target.value as ReportPeriodType)}
                            containerClassName="mb-0"
                        />
                        {reportPeriod === 'custom_range' && (
                            <>
                                <DateInput label="Fecha de Inicio:" value={customReportStart} onChange={(e) => setCustomReportStart(e.target.value)} containerClassName="mb-0"/>
                                <DateInput label="Fecha de Fin:" value={customReportEnd} onChange={(e) => setCustomReportEnd(e.target.value)} containerClassName="mb-0"/>
                            </>
                        )}
                         <div className={reportPeriod === 'custom_range' ? 'lg:col-start-4' : 'lg:col-start-auto'}>
                            <Button onClick={handleGenerateReport} leftIcon={<Icon name="documentText"/>} className="w-full">
                                Generar Reporte
                            </Button>
                        </div>
                    </div>
                </div>
            </Card>

            <Card 
                title="Gestión de Comandas (Órdenes)" 
                className="mb-6"
                titleAction={
                    <Button onClick={() => handleOpenOrderModal(null)} leftIcon={<Icon name="plus"/>} size="sm">
                        Nueva Comanda
                    </Button>
                }
            >
                <div className="p-4">
                     <div className="mb-4">
                        <SelectInput
                            label="Filtrar Comandas Por:"
                            options={orderServiceTypeFilterOptions}
                            value={filterOrderServiceType}
                            onChange={(e) => setFilterOrderServiceType(e.target.value as OrderServiceTypeFilter)}
                        />
                    </div>
                    <Table columns={orderColumns} data={filteredOrders} />
                </div>
            </Card>

            <Card 
                title="Gestión de Menú"
                titleAction={
                    <Button onClick={() => handleOpenMenuItemModal()} leftIcon={<Icon name="plus"/>} size="sm">
                        Nuevo Platillo
                    </Button>
            }>
                <div className="p-4">
                    <div className="mb-4">
                        <SelectInput
                            label="Filtrar por Categoría:"
                            options={categoryFilterOptions}
                            value={filterMenuCategory}
                            onChange={(e) => setFilterMenuCategory(e.target.value as MenuItemCategory | 'all')}
                        />
                    </div>
                    <Table columns={menuItemColumns} data={filteredMenuItems} />
                </div>
            </Card>

            {isMenuItemModalOpen && (
                <Modal isOpen={isMenuItemModalOpen} onClose={handleCloseMenuItemModal} title={currentMenuItem ? 'Editar Platillo' : 'Nuevo Platillo'} size="lg">
                    <MenuItemForm 
                        initialData={currentMenuItem} 
                        onSave={handleSaveMenuItem} 
                        onCancel={handleCloseMenuItemModal}
                        categoryOptions={MENU_ITEM_CATEGORY_OPTIONS}
                    />
                </Modal>
            )}

            {isOrderModalOpen && (
                <Modal isOpen={isOrderModalOpen} onClose={handleCloseOrderModal} title={currentOrder ? 'Editar Comanda' : 'Nueva Comanda'} size="xl">
                    <OrderForm 
                        initialData={currentOrder}
                        menuItems={menuItems.filter(mi => mi.isAvailable)} 
                        onSave={handleSaveOrder}
                        onCancel={handleCloseOrderModal}
                        paymentMethodOptions={PAYMENT_METHOD_OPTIONS}
                        reservations={reservationsData}
                        customers={customersData}
                        properties={propertiesData}
                    />
                </Modal>
            )}

            {isReportModalOpen && reportData && (
                <RestaurantReportModal
                    isOpen={isReportModalOpen}
                    onClose={() => setIsReportModalOpen(false)}
                    summary={reportData}
                />
            )}

            {isImagePreviewModalOpen && (
                <ImagePreviewModal
                    isOpen={isImagePreviewModalOpen}
                    onClose={() => setIsImagePreviewModalOpen(false)}
                    imageUrl={previewImageUrl}
                    title={previewImageTitle}
                />
            )}

            {isCostAnalysisModalOpen && selectedMenuItemForCostAnalysis && (
                <MenuItemCostAnalysisModal
                    isOpen={isCostAnalysisModalOpen}
                    onClose={handleCloseCostAnalysisModal}
                    menuItem={selectedMenuItemForCostAnalysis}
                    initialAnalysisData={currentAnalysisData}
                    inventoryItems={inventoryItems}
                    appSettings={appSettings}
                    onSave={handleSaveCostAnalysis}
                />
            )}

            {isCostReceiptModalOpen && selectedMenuItemForReceipt && (
                <MenuItemCostReceiptModal
                    isOpen={isCostReceiptModalOpen}
                    onClose={handleCloseCostReceiptModal}
                    menuItem={selectedMenuItemForReceipt.item}
                    costAnalysis={selectedMenuItemForReceipt.analysis}
                    appSettings={appSettings}
                    inventoryItems={inventoryItems}
                />
            )}
        </div>
    );
};

export default RestaurantPage;


import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Reservation, Property, Customer, ReservationStatus, AppSettings, RoomCleaningStatus } from '../types';
import PageTitle from '../components/common/PageTitle';
import Icon from '../components/common/Icon';
import Button from '../components/common/Button';
import useMockData from '../hooks/useMockData';
import { MOCK_RESERVATIONS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, APP_NAME, APP_SETTINGS_KEY } from '../constants';
import Modal from '../components/common/Modal';
import { useNavigate } from 'react-router-dom';

const initialReservations: Reservation[] = [
    { id: 'res1', customerId: 'cust1', propertyId: 'prop1', checkInDate: '2024-07-10', checkOutDate: '2024-07-15', numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 750, balanceDue: 0, createdAt: new Date().toISOString() },
    { id: 'res2', customerId: 'cust2', propertyId: 'prop2', checkInDate: '2024-07-12', checkOutDate: '2024-07-18', numberOfGuests: 4, status: ReservationStatus.ADVANCE_PAID, advanceAmount: 100, totalPrice: 1200, balanceDue: 1100, createdAt: new Date().toISOString() },
    { id: 'res3', customerId: 'cust3', propertyId: 'prop1', checkInDate: '2024-07-20', checkOutDate: '2024-07-22', numberOfGuests: 1, status: ReservationStatus.PENDING, totalPrice: 300, balanceDue: 300, createdAt: new Date().toISOString() },
    { id: 'res4', customerId: 'cust1', propertyId: 'prop3', checkInDate: '2024-07-05', checkOutDate: '2024-07-25', numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 2400, balanceDue: 0, createdAt: new Date().toISOString() },
];
const initialProperties: Property[] = [
    { id: 'prop1', name: 'Cabaña del Lago', description: 'Hermosa cabaña con vista al lago.', maxCapacity: 4, bedConfiguration: '1 Queen, 2 Twin', pricePerNight: 150, photoUrls: ['https://picsum.photos/seed/prop1/400/300'], calendarColor: 'bg-primary text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
    { id: 'prop2', name: 'Suite Montaña', description: 'Lujosa suite en la montaña.', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 200, photoUrls: ['https://picsum.photos/seed/prop2/400/300'], calendarColor: 'bg-accent text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
    { id: 'prop3', name: 'Villa Paraíso', description: 'Espaciosa villa con piscina.', maxCapacity: 6, bedConfiguration: '2 King, 2 Single', pricePerNight: 300, photoUrls: ['https://picsum.photos/seed/prop3/400/300'], calendarColor: 'bg-emerald-500 text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.SUCIA },

];
const initialCustomers: Customer[] = [
    { id: 'cust1', fullName: 'Ana Pérez', phone: '5551234', email: 'ana@example.com', createdAt: new Date().toISOString() },
    { id: 'cust2', fullName: 'Luis García', phone: '5555678', createdAt: new Date().toISOString() },
    { id: 'cust3', fullName: 'Carlos López', phone: '5558765', email: 'carlos@example.com', createdAt: new Date().toISOString() },
];

interface EnrichedReservation extends Reservation {
  propertyName: string;
  propertyColor: string;
  customerName?: string;
}

type CalendarViewMode = 'monthly' | 'timeline';

const CalendarPage: React.FC = () => {
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialProperties);
  const [customers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialCustomers);
  const navigate = useNavigate();
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedReservation, setSelectedReservation] = useState<EnrichedReservation | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<CalendarViewMode>('monthly');
  const [appSettings, setAppSettings] = useState<Partial<AppSettings>>({ appName: APP_NAME, phone: '', defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00' });


  useEffect(() => {
    const loadSettings = () => {
      try {
        const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
        if (settingsStr) {
          const parsedSettings = JSON.parse(settingsStr) as AppSettings;
          setAppSettings(prev => ({ ...prev, ...parsedSettings }));
        }
      } catch (e) {
        console.error("Could not parse app settings in CalendarPage", e);
      }
    };
    loadSettings();
    window.addEventListener('storage', loadSettings);
    return () => window.removeEventListener('storage', loadSettings);
  }, []);

  const daysInMonth = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const date = new Date(year, month, 1);
    const days = [];
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  const firstDayOfMonthOffset = useMemo(() => { // For monthly view
    const day = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
    return day === 0 ? 6 : day -1; // Monday is 0
  }, [currentDate]);

  const getReservationsForDate = useCallback((date: Date): EnrichedReservation[] => {
    const dateString = date.toISOString().split('T')[0];
    return reservations
      .filter(res => res.checkInDate <= dateString && res.checkOutDate > dateString && res.status !== ReservationStatus.CANCELLED)
      .map(res => {
        const property = properties.find(p => p.id === res.propertyId);
        const customer = customers.find(c => c.id === res.customerId);
        return {
          ...res,
          propertyName: property?.name || 'N/A',
          propertyColor: property?.calendarColor || 'bg-muted-foreground text-white',
          customerName: customer?.fullName
        };
      });
  }, [reservations, properties, customers]);

  const getReservationsForProperty = useCallback((propertyId: string): EnrichedReservation[] => {
    return reservations
        .filter(res => res.propertyId === propertyId && res.status !== ReservationStatus.CANCELLED)
        .map(res => {
            const property = properties.find(p => p.id === res.propertyId);
            const customer = customers.find(c => c.id === res.customerId);
            return {
                ...res,
                propertyName: property?.name || 'N/A',
                propertyColor: property?.calendarColor || 'bg-muted-foreground text-white',
                customerName: customer?.fullName
            };
        });
  }, [reservations, properties, customers]);


  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDayClickMonthly = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    navigate('/reservations', { state: { openNewReservationModal: true, prefillData: { checkInDate: dateString, checkInTime: appSettings.defaultCheckInTime, checkOutTime: appSettings.defaultCheckOutTime } } });
  };
  
  const handleTimelineSlotClick = (propertyId: string, date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    navigate('/reservations', { state: { openNewReservationModal: true, prefillData: { propertyId, checkInDate: dateString, checkInTime: appSettings.defaultCheckInTime, checkOutTime: appSettings.defaultCheckOutTime } } });
  };


  const handleReservationClick = (reservation: EnrichedReservation) => {
    setSelectedReservation(reservation);
    setIsModalOpen(true);
  };
  
  const handleShareWhatsApp = (reservation: EnrichedReservation | null) => {
    if (!reservation) return;
    const customerDetails = customers.find(c => c.id === reservation.customerId);
    
    let message = `*Detalles de Reserva - ${appSettings.appName || 'Hotel'}*\n\n`;
    message += `Hola ${customerDetails?.fullName || 'Cliente'},\n\n`;
    message += `Información de su reserva:\n`;
    message += `ID Reserva: ${reservation.id}\n`;
    message += `Propiedad: ${reservation.propertyName}\n`;
    message += `Check-in: ${new Date(reservation.checkInDate).toLocaleDateString('es-ES')} ${reservation.checkInTime || appSettings.defaultCheckInTime || ''}\n`;
    message += `Check-out: ${new Date(reservation.checkOutDate).toLocaleDateString('es-ES')} ${reservation.checkOutTime || appSettings.defaultCheckOutTime || ''}\n`;
    message += `Huéspedes: ${reservation.numberOfGuests}\n`;
    message += `Estado: ${reservation.status}\n`;
    message += `Total: $${reservation.totalPrice.toFixed(2)}\n`;
    if(reservation.advanceAmount) message += `Pagado: $${(reservation.advanceAmount || 0).toFixed(2)}\n`;
    message += `*Saldo Pendiente: $${reservation.balanceDue.toFixed(2)}*\n\n`;
    
    if (appSettings.phone) message += `Contacto Hotel: ${appSettings.phone}\n`;

    const customerPhone = customerDetails?.phone?.replace(/\D/g, '');
    const whatsappUrl = `https://wa.me/${customerPhone || ''}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };


  const getStatusColorClass = (status: ReservationStatus) => {
    switch (status) {
        case ReservationStatus.FULLY_PAID: return 'bg-success/20 text-success';
        case ReservationStatus.ADVANCE_PAID: return 'bg-warning/20 text-yellow-700';
        case ReservationStatus.PENDING: return 'bg-info/20 text-info';
        case ReservationStatus.CANCELLED: return 'bg-danger/20 text-danger';
        default: return 'bg-gray-200 text-gray-800';
    }
  };

  const renderMonthlyView = () => (
    <div className="bg-surface p-2 sm:p-4 rounded-lg shadow">
      <div className="grid grid-cols-7 gap-px border border-border-color bg-border-color">
        {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(day => (
          <div key={day} className="py-2 text-center text-sm font-medium text-muted-foreground bg-background">{day}</div>
        ))}
        {Array(firstDayOfMonthOffset).fill(null).map((_, index) => (
          <div key={`empty-monthly-${index}`} className="bg-background border border-border-color/50"></div>
        ))}
        {daysInMonth.map(day => {
          const dayReservations = getReservationsForDate(day);
          const isToday = day.toISOString().split('T')[0] === new Date().toISOString().split('T')[0];
          return (
            <div 
              key={day.toISOString()} 
              className={`relative min-h-[100px] sm:min-h-[140px] bg-surface p-1.5 border border-border-color/50 hover:bg-background transition-colors ${dayReservations.length === 0 ? 'cursor-pointer' : ''}`}
              onClick={() => dayReservations.length === 0 && handleDayClickMonthly(day)}
              role="gridcell"
              aria-label={`Día ${day.getDate()}`}
            >
              <time dateTime={day.toISOString()} className={`text-xs sm:text-sm font-medium ${isToday ? 'text-accent font-bold' : 'text-muted-foreground'}`}>
                {day.getDate()}
              </time>
              <div className="mt-1 space-y-1 overflow-y-auto max-h-[calc(100%-1.5rem)]">
                {dayReservations.slice(0, 4).map(res => ( // Show up to 4 simplified blocks
                  <button 
                    key={res.id}
                    onClick={(e) => { e.stopPropagation(); handleReservationClick(res); }}
                    className={`block w-full text-left p-1 text-xs rounded shadow-sm truncate ${res.propertyColor} hover:opacity-80 transition-opacity`}
                    aria-label={`Reserva para ${res.propertyName}`}
                  >
                    <span className="font-semibold truncate">{res.propertyName}</span>
                  </button>
                ))}
                {dayReservations.length > 4 && ( // If more than 4
                  <p className="text-xs text-muted-foreground text-center mt-1">+ {dayReservations.length - 4} más</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderTimelineView = () => {
    const dayWidth = 40; // width of a day cell in pixels, increased slightly
    const numDays = daysInMonth.length;
    const dayInitials = ['D', 'L', 'M', 'M', 'J', 'V', 'S']; // Domingo is 0

    return (
        <div className="bg-surface p-2 sm:p-4 rounded-lg shadow overflow-x-auto">
            <div style={{ minWidth: `${properties.length * 60 + numDays * dayWidth}px` }} className="flex"> {/* Property names + days */}
                 {/* Property Names Column */}
                <div className="sticky left-0 bg-surface z-10">
                    <div className="h-16 border-b border-r border-border-color flex items-center justify-center text-xs font-medium text-muted-foreground bg-background px-2">Propiedad</div>
                    {properties.map(prop => (
                        <div key={prop.id} className="h-12 border-b border-r border-border-color flex items-center px-2 text-xs font-semibold text-foreground truncate" title={prop.name}>
                            {prop.name}
                        </div>
                    ))}
                </div>

                {/* Days Header & Timeline Grid */}
                <div className="flex-grow">
                    <div className="grid" style={{ gridTemplateColumns: `repeat(${numDays}, minmax(${dayWidth}px, 1fr))` }}>
                        {daysInMonth.map(day => (
                            <div key={`header-${day.toISOString()}`} className="h-16 border-b border-r border-border-color flex flex-col items-center justify-center text-xs font-medium text-muted-foreground bg-background">
                                <span className="text-xs">{dayInitials[day.getDay()]}</span>
                                <span className="text-sm font-bold mt-1">{day.getDate()}</span>
                            </div>
                        ))}
                    </div>
                    
                    {properties.map(prop => {
                        const propertyReservations = getReservationsForProperty(prop.id);
                        return (
                            <div key={`row-${prop.id}`} className="relative h-12 border-b border-border-color grid" style={{ gridTemplateColumns: `repeat(${numDays}, minmax(${dayWidth}px, 1fr))` }}>
                                {daysInMonth.map((day, dayIndex) => (
                                    <div 
                                        key={`cell-${prop.id}-${day.toISOString()}`}
                                        className="border-r border-border-color hover:bg-background/50 cursor-pointer"
                                        onClick={() => handleTimelineSlotClick(prop.id, day)}
                                        role="gridcell"
                                        aria-label={`Crear reserva para ${prop.name} el ${day.toLocaleDateString()}`}
                                    >
                                        {/* Placeholder for day cell content if needed */}
                                    </div>
                                ))}
                                {/* Render reservations for this property */}
                                {propertyReservations.map(res => {
                                    const startDate = new Date(res.checkInDate + 'T00:00:00'); 
                                    const endDate = new Date(res.checkOutDate + 'T00:00:00');
                                    const firstDayOfVisibleMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
                                    
                                    if (endDate <= firstDayOfVisibleMonth || startDate > new Date(currentDate.getFullYear(), currentDate.getMonth(), numDays)) {
                                        return null; // Reservation is entirely outside the current month's view
                                    }

                                    let displayStartDayIndex;
                                    if (startDate < firstDayOfVisibleMonth) {
                                        displayStartDayIndex = 0; // Starts before this month
                                    } else {
                                        displayStartDayIndex = startDate.getDate() - 1; // 0-indexed day of month
                                    }

                                    let effectiveEndDate = endDate;
                                    if (endDate > new Date(currentDate.getFullYear(), currentDate.getMonth(), numDays, 23, 59, 59)) {
                                        effectiveEndDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), numDays + 1, 0, 0, 0); // Day after last day of month
                                    }
                                    
                                    let effectiveStartDate = startDate < firstDayOfVisibleMonth ? firstDayOfVisibleMonth : startDate;

                                    let actualDuration = (effectiveEndDate.getTime() - effectiveStartDate.getTime()) / (1000 * 3600 * 24);
                                    actualDuration = Math.max(0, actualDuration); // Ensure non-negative
                                    
                                    if (actualDuration <=0) return null;


                                    return (
                                        <button
                                            key={res.id}
                                            onClick={() => handleReservationClick(res)}
                                            className={`absolute top-0.5 bottom-0.5 rounded shadow-sm text-xs p-1 truncate ${res.propertyColor} hover:opacity-80 transition-opacity flex items-center justify-center`}
                                            style={{
                                                left: `${displayStartDayIndex * dayWidth + 1}px`, 
                                                width: `${actualDuration * dayWidth - 2}px`, 
                                            }}
                                            aria-label={`Reserva ${res.id} para ${res.propertyName}`}
                                        >
                                            <span className="truncate" title={res.customerName || `ID: ${res.customerId}`}>
                                                {res.customerName ? res.customerName.split(' ')[0] : `Res: ${res.id.slice(-4)}`}
                                            </span>
                                        </button>
                                    );
                                })}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
  };


  return (
    <div>
      <PageTitle title="Calendario de Ocupación" />
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-center bg-surface p-4 rounded-lg shadow">
        <div className="flex items-center space-x-2 mb-3 sm:mb-0">
            <Button onClick={handlePrevMonth} variant="outline" size="sm" aria-label="Mes anterior">
                <Icon name="arrowLeft" className="w-5 h-5" />
            </Button>
            <h3 className="text-xl font-semibold text-foreground w-40 sm:w-48 text-center">
              {currentDate.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
            </h3>
            <Button onClick={handleNextMonth} variant="outline" size="sm" aria-label="Mes siguiente">
                <Icon name="arrowRight" className="w-5 h-5" />
            </Button>
        </div>
        <div className="flex space-x-2">
            <Button variant={viewMode === 'monthly' ? "primary" : "outline"} size="sm" onClick={() => setViewMode('monthly')}>
                Vista Mensual
            </Button>
            <Button variant={viewMode === 'timeline' ? "primary" : "outline"} size="sm" onClick={() => setViewMode('timeline')}>
                Vista Línea de Tiempo
            </Button>
        </div>
      </div>

      {viewMode === 'monthly' ? renderMonthlyView() : renderTimelineView()}
      

      {selectedReservation && (
        <Modal
            isOpen={isModalOpen}
            onClose={() => { setIsModalOpen(false); setSelectedReservation(null); }}
            title={`Detalles de Reserva - ${selectedReservation.propertyName}`}
            footer={
                <div className="flex justify-between w-full items-center">
                     <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleShareWhatsApp(selectedReservation)}
                        leftIcon={<Icon name="whatsapp" className="w-4 h-4 text-green-500"/>}
                        className="text-green-600 hover:text-green-700"
                    >
                        Compartir WhatsApp
                    </Button>
                    <div>
                        <Button variant="outline" size="sm" onClick={() => { setIsModalOpen(false); setSelectedReservation(null); }} className="mr-2">
                            Cerrar
                        </Button>
                        <Button variant="primary" size="sm" onClick={() => navigate(`/reservations`, { state: { editReservationId: selectedReservation.id } } )}>
                            Editar Reserva
                        </Button>
                    </div>
                </div>
            }
        >
            <div className="space-y-3 text-sm">
                <p><strong>Cliente:</strong> {selectedReservation.customerName || selectedReservation.customerId}</p>
                <p><strong>Propiedad:</strong> {selectedReservation.propertyName}</p>
                <p><strong>Check-in:</strong> {new Date(selectedReservation.checkInDate).toLocaleDateString()} {selectedReservation.checkInTime || appSettings.defaultCheckInTime || ''}</p>
                <p><strong>Check-out:</strong> {new Date(selectedReservation.checkOutDate).toLocaleDateString()} {selectedReservation.checkOutTime || appSettings.defaultCheckOutTime || ''}</p>
                <p><strong>Huéspedes:</strong> {selectedReservation.numberOfGuests}</p>
                <p><strong>Estado:</strong> <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColorClass(selectedReservation.status)}`}>{selectedReservation.status}</span></p>
                <p><strong>Total:</strong> ${selectedReservation.totalPrice.toFixed(2)}</p>
                <p><strong>Saldo Pendiente:</strong> ${selectedReservation.balanceDue.toFixed(2)}</p>
                {selectedReservation.notes && <p><strong>Notas:</strong> {selectedReservation.notes}</p>}
            </div>
        </Modal>
      )}
    </div>
  );
};

export default CalendarPage;

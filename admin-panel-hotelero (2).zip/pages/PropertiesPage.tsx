
import React, { useState, useMemo, useEffect } from 'react';
import { Property, MaintenanceLogEntry, Reservation, ReservationStatus, RoomCleaningStatus } from '../types'; // Added RoomCleaningStatus
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import PropertyForm from '../components/properties/PropertyForm';
import KPICard from '../components/dashboard/KPICard';
import useMockData from '../hooks/useMockData';
import { MOCK_PROPERTIES_DATA_KEY, MOCK_RESERVATIONS_DATA_KEY, MOCK_PROPERTY_COLORS } from '../constants';
import { useLocation, useNavigate } from 'react-router-dom';
import Card from '../components/common/Card'; // For individual property cards

const initialProperties: Property[] = [
    { id: 'prop1', name: 'Cabaña del Lago', description: 'Hermosa cabaña con vista al lago.', maxCapacity: 4, bedConfiguration: '1 Queen, 2 Twin', pricePerNight: 150, photoUrls: ['https://picsum.photos/seed/prop1/400/300', 'https://picsum.photos/seed/prop1b/400/300'], calendarColor: 'bg-primary text-white', maintenanceLog: [{id: 'm1', date: '2024-06-15', description: 'Pintura exterior', cost: 500}], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA, lastCleanedDate: new Date().toISOString().split('T')[0], amenities: ['Terraza', 'Baño Propio', 'Asador'] },
    { id: 'prop2', name: 'Suite Montaña', description: 'Lujosa suite en la montaña.', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 200, photoUrls: ['https://picsum.photos/seed/prop2/400/300'], calendarColor: 'bg-accent text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA, amenities: ['Clima', 'Baño Propio'] },
    { id: 'prop3', name: 'Apartamento Urbano', description: 'Moderno apartamento en el centro.', maxCapacity: 3, bedConfiguration: '1 Double, 1 Sofa Bed', pricePerNight: 120, photoUrls: ['https://picsum.photos/seed/prop3/400/300'], calendarColor: 'bg-emerald-500 text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.SUCIA, amenities: ['Ventilador'] },
];

const initialReservations: Reservation[] = [
    { id: 'res-prop1-active', customerId: 'cust-temp', propertyId: 'prop1', checkInDate: new Date(Date.now() - 2*24*60*60*1000).toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 2*24*60*60*1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 600, balanceDue: 0, createdAt: new Date().toISOString() },
];

const PropertiesPage: React.FC = () => {
  const [properties, setProperties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialProperties);
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentProperty, setCurrentProperty] = useState<Property | null>(null);

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.state?.openNewPropertyModal) {
      handleOpenModal(null);
      navigate(location.pathname, { replace: true, state: {} }); 
    }
  }, [location.state, navigate]);

  const handleOpenModal = (property: Property | null = null) => {
    setCurrentProperty(property);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCurrentProperty(null);
  };

  const handleSaveProperty = (propertyData: Omit<Property, 'id' | 'createdAt' | 'maintenanceLog'> & { id?: string, maintenanceLog?: MaintenanceLogEntry[] }) => {
    if (currentProperty && currentProperty.id) { 
      setProperties(prev => prev.map(p => p.id === currentProperty.id ? { ...currentProperty, ...propertyData, maintenanceLog: propertyData.maintenanceLog || currentProperty.maintenanceLog } : p));
    } else { 
      setProperties(prev => [...prev, { ...propertyData, id: `prop-${Date.now()}`, createdAt: new Date().toISOString(), maintenanceLog: propertyData.maintenanceLog || [], currentCleaningStatus: propertyData.currentCleaningStatus || RoomCleaningStatus.LIMPIA }]);
    }
    handleCloseModal();
  };

  const handleDeleteProperty = (id: string, event: React.MouseEvent) => {
    event.stopPropagation(); 
    if (window.confirm('¿Está seguro de que desea eliminar esta propiedad? Esto podría afectar reservas existentes.')) {
      setProperties(prev => prev.filter(p => p.id !== id));
    }
  };
  
  const summaryStats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const occupiedPropertyIds = new Set(
      reservations
        .filter(r => r.checkInDate <= today && r.checkOutDate > today && r.status !== ReservationStatus.CANCELLED)
        .map(r => r.propertyId)
    );
    const totalProperties = properties.length;
    const occupiedToday = occupiedPropertyIds.size;
    
    const inMaintenanceToday = properties.filter(p => 
        p.maintenanceLog.some(m => {
            const mDate = new Date(m.date).toISOString().split('T')[0];
            return mDate === today && m.description.toLowerCase().includes("mantenimiento");
        })
    ).length; 
    const availableToday = totalProperties - occupiedToday - inMaintenanceToday;

    return [
        { label: 'Total Propiedades', value: totalProperties, icon: <Icon name="building" className="w-6 h-6 text-primary"/> },
        { label: 'Disponibles Hoy', value: Math.max(0, availableToday), icon: <Icon name="check" className="w-6 h-6 text-success"/> },
        { label: 'Ocupadas Hoy', value: occupiedToday, icon: <Icon name="users" className="w-6 h-6 text-warning"/> }, 
        { label: 'En Mantenimiento', value: inMaintenanceToday, icon: <Icon name="cog" className="w-6 h-6 text-info"/> }, 
    ];
  }, [properties, reservations]);


  return (
    <div>
      <PageTitle title="Gestión de Propiedades" actionButton={
        <Button onClick={() => handleOpenModal()} leftIcon={<Icon name="plus" className="w-5 h-5"/>}>
          Nueva Propiedad
        </Button>
      }/>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {summaryStats.map(stat => (
            <KPICard key={stat.label} kpi={stat} />
        ))}
      </div>
      
      {properties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {properties.map(property => (
            <div
              key={property.id}
              className="cursor-pointer h-full"
              onClick={() => handleOpenModal(property)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleOpenModal(property);
                }
              }}
              role="button"
              tabIndex={0}
              aria-label={`Ver detalles y editar ${property.name}`}
            >
              <Card 
                className="hover:shadow-xl transition-shadow duration-300 flex flex-col h-full"
              >
                <div className="relative">
                  {property.photoUrls && property.photoUrls.length > 0 ? (
                    <img src={property.photoUrls[0]} alt={property.name} className="w-full h-48 object-cover rounded-t-xl"/>
                  ) : (
                    <div className="w-full h-48 bg-muted-foreground/20 flex items-center justify-center rounded-t-xl">
                      <Icon name="image" className="w-16 h-16 text-muted-foreground/50" />
                    </div>
                  )}
                   <div className={`absolute top-2 right-2 p-1.5 rounded-full shadow-md ${property.calendarColor.split(' ').find(cls => cls.startsWith('bg-')) || 'bg-muted-foreground'}`} title="Color en Calendario">
                      <span className={`text-xs ${property.calendarColor.includes('text-white') ? 'text-white' : 'text-black'}`}> </span>
                   </div>
                   <div className={`absolute top-2 left-2 px-2 py-0.5 text-xs font-medium rounded-full shadow-md
                    ${property.currentCleaningStatus === RoomCleaningStatus.LIMPIA || property.currentCleaningStatus === RoomCleaningStatus.INSPECCIONADA ? 'bg-success text-white' :
                      property.currentCleaningStatus === RoomCleaningStatus.SUCIA ? 'bg-danger text-white' :
                      property.currentCleaningStatus === RoomCleaningStatus.EN_LIMPIEZA ? 'bg-info text-white' :
                      'bg-muted-foreground text-white'}`}
                    title={`Estado Limpieza: ${property.currentCleaningStatus}`}>
                    {property.currentCleaningStatus}
                   </div>
                   <Button 
                      variant="danger" 
                      size="sm" 
                      onClick={(e) => handleDeleteProperty(property.id, e)} 
                      className="absolute bottom-2 right-2 opacity-80 hover:opacity-100"
                      title="Eliminar Propiedad"
                    >
                      <Icon name="trash" className="w-4 h-4" />
                    </Button>
                </div>
                <div className="p-4 flex-grow flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-1 truncate" title={property.name}>{property.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2" title={property.description}>{property.description || 'Sin descripción.'}</p>
                  </div>
                  <div className="mt-2 pt-2 border-t border-border-color/50 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Capacidad:</span>
                      <span className="font-medium text-foreground">{property.maxCapacity}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Precio/Noche:</span>
                      <span className="font-medium text-success">${property.pricePerNight.toFixed(2)}</span>
                    </div>
                    {property.amenities && property.amenities.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-semibold text-muted-foreground">Amenidades:</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {property.amenities.slice(0, 3).map(amenity => ( // Show up to 3 amenities
                            <span key={amenity} className="px-1.5 py-0.5 text-xs bg-accent/10 text-accent rounded-full">
                              {amenity}
                            </span>
                          ))}
                          {property.amenities.length > 3 && (
                             <span className="px-1.5 py-0.5 text-xs bg-muted-foreground/10 text-muted-foreground rounded-full">
                              +{property.amenities.length - 3} más
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>
      ) : (
        <Card>
          <div className="text-center py-12">
            <Icon name="building" className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4"/>
            <h3 className="text-xl font-semibold text-muted-foreground mb-2">No hay propiedades registradas</h3>
            <p className="text-sm text-muted-foreground mb-4">Comience añadiendo su primera propiedad.</p>
            <Button onClick={() => handleOpenModal()} leftIcon={<Icon name="plus" />}>
              Añadir Nueva Propiedad
            </Button>
          </div>
        </Card>
      )}


      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={currentProperty ? `Editar Propiedad: ${currentProperty.name}` : 'Crear Nueva Propiedad'}
          size="xl" 
        >
          <PropertyForm
            initialData={currentProperty}
            onSave={handleSaveProperty}
            onCancel={handleCloseModal}
            colorOptions={MOCK_PROPERTY_COLORS}
          />
        </Modal>
      )}
    </div>
  );
};

export default PropertiesPage;

import React, { useState, useMemo, useCallback, ChangeEvent } from 'react';
import { Property, RoomCleaningStatus, Reservation, ReservationStatus, MaintenanceLocationType } from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Table, { TableColumn } from '../../components/common/Table';
import SelectInput from '../../components/common/SelectInput';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import useMockData from '../../hooks/useMockData';
import { MOCK_PROPERTIES_DATA_KEY, MOCK_RESERVATIONS_DATA_KEY, ROOM_CLEANING_STATUS_OPTIONS } from '../../constants';
import { useNavigate } from 'react-router-dom';

const initialProperties: Property[] = [
    // Ensure properties have a default cleaning status if not loading from somewhere else
    { id: 'prop1', name: 'Cabaña del Lago', description: 'Hermosa cabaña con vista al lago.', maxCapacity: 4, bedConfiguration: '1 Queen, 2 Twin', pricePerNight: 150, photoUrls: [], calendarColor: 'bg-primary text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA, lastCleanedDate: new Date().toISOString().split('T')[0] },
    { id: 'prop2', name: 'Suite Montaña', description: 'Lujosa suite en la montaña.', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 200, photoUrls: [], calendarColor: 'bg-accent text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.SUCIA },
    { id: 'prop3', name: 'Apartamento Urbano', description: 'Moderno apartamento en el centro.', maxCapacity: 3, bedConfiguration: '1 Double, 1 Sofa Bed', pricePerNight: 120, photoUrls: [], calendarColor: 'bg-emerald-500 text-white', maintenanceLog: [], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.EN_LIMPIEZA },
];
const initialReservations: Reservation[] = [
    { id: 'res-hk-1', customerId: 'cust-hk1', propertyId: 'prop2', checkInDate: new Date(Date.now() - 1*24*60*60*1000).toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 1*24*60*60*1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 400, balanceDue: 0, createdAt: new Date().toISOString() },
    { id: 'res-hk-2', customerId: 'cust-hk2', propertyId: 'prop3', checkInDate: new Date(Date.now() - 2*24*60*60*1000).toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 3*24*60*60*1000).toISOString().split('T')[0], numberOfGuests: 1, status: ReservationStatus.ADVANCE_PAID, totalPrice: 600, balanceDue: 300, createdAt: new Date().toISOString() },
];


const HousekeepingPage: React.FC = () => {
  const [properties, setProperties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialProperties);
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
  const navigate = useNavigate();

  const [filterCleaningStatus, setFilterCleaningStatus] = useState<RoomCleaningStatus | 'all'>('all');

  const handleCleaningStatusChange = (propertyId: string, newStatus: RoomCleaningStatus) => {
    setProperties(prev =>
      prev.map(p => {
        if (p.id === propertyId) {
          const updatedProperty = { ...p, currentCleaningStatus: newStatus };
          if (newStatus === RoomCleaningStatus.LIMPIA || newStatus === RoomCleaningStatus.INSPECCIONADA) {
            updatedProperty.lastCleanedDate = new Date().toISOString().split('T')[0];
          }
          return updatedProperty;
        }
        return p;
      })
    );
  };
  
  const getStatusColorClass = (status: RoomCleaningStatus) => {
    switch (status) {
      case RoomCleaningStatus.SUCIA: return 'bg-danger/20 text-danger';
      case RoomCleaningStatus.EN_LIMPIEZA: return 'bg-info/20 text-info';
      case RoomCleaningStatus.LIMPIA: return 'bg-success/20 text-success';
      case RoomCleaningStatus.INSPECCIONADA: return 'bg-emerald-500/20 text-emerald-600';
      case RoomCleaningStatus.FUERA_DE_SERVICIO: return 'bg-muted-foreground/20 text-muted-foreground';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  const housekeepingKPIs = useMemo(() => {
    const counts = properties.reduce((acc, prop) => {
        acc[prop.currentCleaningStatus] = (acc[prop.currentCleaningStatus] || 0) + 1;
        return acc;
    }, {} as Record<RoomCleaningStatus, number>);

    return [
        { label: 'Total Propiedades', value: properties.length, icon: <Icon name="building" className="w-6 h-6 text-primary"/> },
        { label: RoomCleaningStatus.LIMPIA, value: counts[RoomCleaningStatus.LIMPIA] || 0, icon: <Icon name="check" className="w-6 h-6 text-success"/> },
        { label: RoomCleaningStatus.SUCIA, value: counts[RoomCleaningStatus.SUCIA] || 0, icon: <Icon name="xMark" className="w-6 h-6 text-danger"/> },
        { label: RoomCleaningStatus.EN_LIMPIEZA, value: counts[RoomCleaningStatus.EN_LIMPIEZA] || 0, icon: <Icon name="cog" className="w-6 h-6 text-info"/> },
        { label: RoomCleaningStatus.INSPECCIONADA, value: counts[RoomCleaningStatus.INSPECCIONADA] || 0, icon: <Icon name="eye" className="w-6 h-6 text-emerald-600"/> },
        { label: RoomCleaningStatus.FUERA_DE_SERVICIO, value: counts[RoomCleaningStatus.FUERA_DE_SERVICIO] || 0, icon: <Icon name="warning" className="w-6 h-6 text-muted-foreground"/> },
    ];
  }, [properties]);


  const enrichedProperties = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return properties
        .filter(p => filterCleaningStatus === 'all' || p.currentCleaningStatus === filterCleaningStatus)
        .map(p => {
            const currentReservation = reservations.find(r => 
                r.propertyId === p.id && 
                r.checkInDate <= today && 
                r.checkOutDate > today &&
                r.status !== ReservationStatus.CANCELLED
            );
            const nextCheckoutReservation = reservations
                .filter(r => r.propertyId === p.id && r.checkOutDate >= today && r.status !== ReservationStatus.CANCELLED)
                .sort((a,b) => new Date(a.checkOutDate).getTime() - new Date(b.checkOutDate).getTime())[0];

            return {
                ...p,
                isOccupiedToday: !!currentReservation,
                nextCheckOutDate: nextCheckoutReservation ? nextCheckoutReservation.checkOutDate : undefined,
            };
    }).sort((a,b) => a.name.localeCompare(b.name));
  }, [properties, reservations, filterCleaningStatus]);


  const columns: TableColumn<Property & { isOccupiedToday: boolean; nextCheckOutDate?: string }>[] = [
    { header: 'Propiedad', accessor: 'name', className: 'font-semibold' },
    { 
      header: 'Estado Limpieza', 
      accessor: (item) => (
        <SelectInput
          label="" // Label is provided by the table header
          value={item.currentCleaningStatus}
          onChange={(e: ChangeEvent<HTMLSelectElement>) => handleCleaningStatusChange(item.id, e.target.value as RoomCleaningStatus)}
          options={ROOM_CLEANING_STATUS_OPTIONS}
          className={`text-xs p-1 rounded-md border-0 shadow-sm focus:ring-0 ${getStatusColorClass(item.currentCleaningStatus).replace('bg-', 'border-')}`}
          containerClassName="m-0 w-40" // Override default margin
        />
      ),
      className: 'min-w-[150px]'
    },
    { 
        header: 'Última Limpieza', 
        accessor: (item) => item.lastCleanedDate ? new Date(item.lastCleanedDate + 'T00:00:00').toLocaleDateString() : 'N/A',
        className: 'text-sm'
    },
    { 
        header: 'Ocupada Hoy', 
        accessor: (item) => item.isOccupiedToday ? <span className="text-danger font-medium">Sí</span> : <span className="text-success">No</span>,
        className: 'text-center'
    },
    { 
        header: 'Próx. Salida', 
        accessor: (item) => item.nextCheckOutDate ? new Date(item.nextCheckOutDate + 'T00:00:00').toLocaleDateString() : <span className="text-muted-foreground italic">N/A</span>,
        className: 'text-sm'
    },
    {
      header: 'Acciones',
      accessor: (item) => (
        <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigate('/maintenance', { state: { prefillPropertyId: item.id, prefillLocationType: MaintenanceLocationType.PROPIEDAD_HABITACION }})}
            leftIcon={<Icon name="wrenchScrewdriver" className="w-4 h-4"/>}
            title="Reportar Incidencia en esta Propiedad"
        >
          Reportar Falla
        </Button>
      ),
    },
  ];

  const allCleaningStatusOptions = [{value: 'all', label: 'Todos los Estados'}, ...ROOM_CLEANING_STATUS_OPTIONS];

  return (
    <div>
      <PageTitle title="Gestión de Limpieza de Habitaciones" />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
            {housekeepingKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
        </div>

      <Card>
        <div className="p-4">
          <div className="mb-4">
            <SelectInput
              label="Filtrar por Estado de Limpieza:"
              options={allCleaningStatusOptions}
              value={filterCleaningStatus}
              onChange={(e) => setFilterCleaningStatus(e.target.value as RoomCleaningStatus | 'all')}
            />
          </div>
          <Table columns={columns} data={enrichedProperties} emptyMessage="No hay propiedades que coincidan con el filtro."/>
        </div>
      </Card>
    </div>
  );
};

export default HousekeepingPage;

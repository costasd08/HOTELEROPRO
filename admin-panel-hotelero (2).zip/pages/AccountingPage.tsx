
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { AccountingEntry, AccountingEntryType, AccountingExpenseCategory, AccountingIncomeCategory, ReportPeriodType, ReportSummary } from '../types';
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import AccountingEntryForm from '../components/accounting/AccountingEntryForm';
import AccountingReportModal from '../components/accounting/AccountingReportModal';
import Card from '../components/common/Card';
import KPICard from '../components/dashboard/KPICard';
import useMockData from '../hooks/useMockData';
import { MOCK_ACCOUNTING_ENTRIES_DATA_KEY, ACCOUNTING_ENTRY_TYPE_OPTIONS } from '../constants';
import SelectInput from '../components/common/SelectInput';
import DateInput from '../components/common/DateInput';
import { useLocation, useNavigate } from 'react-router-dom';

const initialAccountingEntries: AccountingEntry[] = [
    { id: 'acc1', date: new Date(Date.now() - 5*24*60*60*1000).toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.HOSPEDAJE, description: 'Reserva #res1', amount: 300, createdAt: new Date().toISOString() },
    { id: 'acc2', date: new Date(Date.now() - 3*24*60*60*1000).toISOString().split('T')[0], type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.MAINTENANCE, description: 'Reparación Cabaña del Lago', amount: 50, createdAt: new Date().toISOString() },
    { id: 'acc3', date: new Date(Date.now() - 1*24*60*60*1000).toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.RESTAURANT_INCOME, description: 'Consumo Restaurante Mesa 5', amount: 75, createdAt: new Date().toISOString() },
    { id: 'acc4', date: new Date().toISOString().split('T')[0], type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.STAFF, description: 'Nómina Juan Pérez', amount: 1200, createdAt: new Date().toISOString() },
    // More entries for testing reports
    { id: 'acc5', date: new Date(new Date().setDate(new Date().getDate() - 8)).toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.EVENTOS, description: 'Evento Corporativo XYZ', amount: 1500, createdAt: new Date().toISOString() },
    { id: 'acc6', date: new Date(new Date().setDate(new Date().getDate() - 40)).toISOString().split('T')[0], type: AccountingEntryType.EXPENSE, category: AccountingExpenseCategory.MARKETING, description: 'Campaña Redes Sociales', amount: 250, createdAt: new Date().toISOString() },
    { id: 'acc7', date: new Date(new Date().setMonth(new Date().getMonth() - 2)).toISOString().split('T')[0], type: AccountingEntryType.INCOME, category: AccountingIncomeCategory.HOSPEDAJE, description: 'Reserva #res-old', amount: 600, createdAt: new Date().toISOString() },
];

const AccountingPage: React.FC = () => {
  const [entries, setEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAccountingEntries);

  const [isEntryModalOpen, setIsEntryModalOpen] = useState(false);
  const [currentEntry, setCurrentEntry] = useState<AccountingEntry | Partial<AccountingEntry> | null>(null);
  const [filterType, setFilterType] = useState<'all' | AccountingEntryType>( 'all');

  // State for Reports
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportEntries, setReportEntries] = useState<AccountingEntry[]>([]);
  const [reportSummary, setReportSummary] = useState<ReportSummary | null>(null);
  const [selectedReportPeriod, setSelectedReportPeriod] = useState<ReportPeriodType>('current_month');
  const [customReportStartDate, setCustomReportStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [customReportEndDate, setCustomReportEndDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.state?.openNewEntryModal) {
      const prefillData: Partial<AccountingEntry> = {};
      if (location.state.type) prefillData.type = location.state.type;
      if (location.state.category) prefillData.category = location.state.category;
      handleOpenEntryModal(prefillData);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, navigate]);


  const handleOpenEntryModal = (entry: AccountingEntry | Partial<AccountingEntry> | null = null) => {
    setCurrentEntry(entry);
    setIsEntryModalOpen(true);
  };

  const handleCloseEntryModal = () => {
    setIsEntryModalOpen(false);
    setCurrentEntry(null);
  };

  const handleSaveEntry = (entryData: Omit<AccountingEntry, 'id' | 'createdAt'> & { id?: string }) => {
    if (currentEntry && 'id' in currentEntry && currentEntry.id) {
      setEntries(prev => prev.map(e => e.id === (currentEntry as AccountingEntry).id ? { ...(currentEntry as AccountingEntry), ...entryData } : e));
    } else {
      setEntries(prev => [...prev, { ...entryData, id: `acc-${Date.now()}`, createdAt: new Date().toISOString() }]);
    }
    handleCloseEntryModal();
  };

  const handleDeleteEntry = (id: string) => {
    if (window.confirm('¿Está seguro de que desea eliminar este asiento contable?')) {
      setEntries(prev => prev.filter(e => e.id !== id));
    }
  };

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const currentMonthEntries = useMemo(() => {
    return entries.filter(entry => {
      const entryDate = new Date(entry.date);
      return entryDate.getMonth() === currentMonth && entryDate.getFullYear() === currentYear;
    });
  }, [entries, currentMonth, currentYear]);

  const summaryDataThisMonth = useMemo(() => {
    const income = currentMonthEntries.filter(e => e.type === AccountingEntryType.INCOME).reduce((sum, e) => sum + e.amount, 0);
    const expenses = currentMonthEntries.filter(e => e.type === AccountingEntryType.EXPENSE).reduce((sum, e) => sum + e.amount, 0);
    const balance = income - expenses;
    return { income, expenses, balance };
  }, [currentMonthEntries]);

  const expenseBreakdownThisMonth = useMemo(() => {
    const breakdown: { [key in AccountingExpenseCategory]?: number } = {};
    Object.values(AccountingExpenseCategory).forEach(cat => {
        breakdown[cat] = 0;
    });

    currentMonthEntries
      .filter(e => e.type === AccountingEntryType.EXPENSE)
      .forEach(e => {
        const categoryKey = e.category as AccountingExpenseCategory;
        if (Object.values(AccountingExpenseCategory).includes(categoryKey)) {
             breakdown[categoryKey]! += e.amount;
        }
      });
    return Object.entries(breakdown)
        .map(([category, amount]) => ({ category: category as AccountingExpenseCategory, amount: amount as number}))
        .filter(item => item.amount > 0)
        .sort((a,b) => b.amount - a.amount);
  }, [currentMonthEntries]);

  const filteredEntriesForTable = useMemo(() => {
    return entries
      .filter(entry => filterType === 'all' || entry.type === filterType)
      .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime() || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [entries, filterType]);

  const handleGenerateReport = useCallback(() => {
    let startDate: Date;
    let endDate: Date;
    let periodLabel = "";
    const today = new Date();

    switch (selectedReportPeriod) {
      case 'current_week':
        startDate = new Date(today.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1) )); // Monday
        endDate = new Date(new Date(startDate).setDate(startDate.getDate() + 6)); // Sunday
        periodLabel = "Semana Actual";
        break;
      case 'current_month':
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        periodLabel = "Mes Actual";
        break;
      case 'current_year':
        startDate = new Date(today.getFullYear(), 0, 1);
        endDate = new Date(today.getFullYear(), 11, 31);
        periodLabel = "Año Actual";
        break;
      case 'custom_range':
        if (!customReportStartDate || !customReportEndDate || new Date(customReportEndDate) < new Date(customReportStartDate)) {
            alert("Por favor, seleccione un rango de fechas válido.");
            return;
        }
        startDate = new Date(customReportStartDate + 'T00:00:00');
        endDate = new Date(customReportEndDate + 'T23:59:59');
        periodLabel = `Rango: ${startDate.toLocaleDateString('es-ES')} - ${endDate.toLocaleDateString('es-ES')}`;
        break;
      default:
        return;
    }

    const sDateStr = startDate.toISOString().split('T')[0];
    const eDateStr = endDate.toISOString().split('T')[0];

    const filtered = entries.filter(entry => {
      const entryDate = entry.date;
      return entryDate >= sDateStr && entryDate <= eDateStr;
    }).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const totalIncome = filtered.filter(e => e.type === AccountingEntryType.INCOME).reduce((sum, e) => sum + e.amount, 0);
    const totalExpenses = filtered.filter(e => e.type === AccountingEntryType.EXPENSE).reduce((sum, e) => sum + e.amount, 0);
    const balance = totalIncome - totalExpenses;

    setReportEntries(filtered);
    setReportSummary({
      totalIncome,
      totalExpenses,
      balance,
      startDate: sDateStr,
      endDate: eDateStr,
      periodTypeLabel: periodLabel,
      generatedAt: new Date().toISOString(),
    });
    setIsReportModalOpen(true);

  }, [entries, selectedReportPeriod, customReportStartDate, customReportEndDate]);


  const columns: { header: string; accessor: keyof AccountingEntry | ((item: AccountingEntry) => React.ReactNode); className?: string }[] = [
    { header: 'Fecha', accessor: (item) => new Date(item.date).toLocaleDateString() },
    {
      header: 'Tipo',
      accessor: (item) => (
        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${item.type === AccountingEntryType.INCOME ? 'bg-success/20 text-success' : 'bg-danger/20 text-danger'}`}>
          {item.type}
        </span>
      )
    },
    { header: 'Categoría', accessor: 'category' },
    { header: 'Descripción', accessor: 'description', className: 'truncate max-w-xs md:max-w-md lg:max-w-lg' },
    {
      header: 'Monto',
      accessor: (item: AccountingEntry) => (
        <span className={`font-semibold ${item.type === AccountingEntryType.INCOME ? 'text-success' : 'text-danger'}`}>
          {`${item.type === AccountingEntryType.EXPENSE ? '-' : ''}$${item.amount.toFixed(2)}`}
        </span>
      ),
      className: 'text-right'
    },
    {
      header: 'Acciones',
      accessor: (item) => (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleOpenEntryModal(item); }} title="Editar">
            <Icon name="edit" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleDeleteEntry(item.id); }} className="text-danger hover:text-danger/80" title="Eliminar">
            <Icon name="trash" className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  const filterOptions = [
      {value: 'all', label: 'Todos los Tipos'},
      ...ACCOUNTING_ENTRY_TYPE_OPTIONS
  ];

  const reportPeriodOptions = [
    { value: 'current_week', label: 'Semana Actual' },
    { value: 'current_month', label: 'Mes Actual' },
    { value: 'current_year', label: 'Año Actual' },
    { value: 'custom_range', label: 'Rango Personalizado' },
  ];

  return (
    <div>
      <PageTitle title="Gestión Financiera" actionButton={
        <Button onClick={() => handleOpenEntryModal()} leftIcon={<Icon name="plus" className="w-5 h-5"/>}>
          Nuevo Asiento
        </Button>
      }/>

      <Card title={`Resumen del Mes Actual (${new Date().toLocaleDateString('es-ES', {month: 'long', year: 'numeric'})})`} className="mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4">
          <KPICard kpi={{ label: 'Ingresos Totales', value: `$${summaryDataThisMonth.income.toFixed(2)}`, icon: <Icon name="cash" className="w-6 h-6 text-success" /> }} />
          <KPICard kpi={{ label: 'Gastos Totales', value: `$${summaryDataThisMonth.expenses.toFixed(2)}`, icon: <Icon name="receipt" className="w-6 h-6 text-danger" /> }} />
          <KPICard kpi={{ label: 'Balance', value: `$${summaryDataThisMonth.balance.toFixed(2)}`, icon: <Icon name="star" className="w-6 h-6 text-primary" /> }} />
        </div>
        <div className="p-4 border-t border-border-color">
            <h4 className="text-md font-semibold text-muted-foreground mb-3">Desglose de Gastos del Mes:</h4>
            {expenseBreakdownThisMonth.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {expenseBreakdownThisMonth.map(breakdownItem => (
                <div key={breakdownItem.category} className="p-3 bg-background rounded-lg shadow">
                <p className="text-sm text-muted-foreground">{breakdownItem.category}</p>
                <p className="text-lg font-semibold text-danger">${breakdownItem.amount.toFixed(2)}</p>
                </div>
            ))}
            </div>
            ) : <p className="text-sm text-muted-foreground italic">No hay gastos registrados este mes.</p>}
        </div>
      </Card>

      {/* "Registro Rápido de Gastos Comunes" Card removed */}

      <Card title="Generar Reporte Financiero" className="mb-6">
        <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                 <SelectInput
                    label="Seleccionar Periodo:"
                    options={reportPeriodOptions}
                    value={selectedReportPeriod}
                    onChange={(e) => setSelectedReportPeriod(e.target.value as ReportPeriodType)}
                    containerClassName="mb-0"
                />
                {selectedReportPeriod === 'custom_range' && (
                    <>
                        <DateInput
                            label="Fecha de Inicio:"
                            value={customReportStartDate}
                            onChange={(e) => setCustomReportStartDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                        <DateInput
                            label="Fecha de Fin:"
                            value={customReportEndDate}
                            onChange={(e) => setCustomReportEndDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                    </>
                )}
                <div className={selectedReportPeriod === 'custom_range' ? 'lg:col-start-4' : 'lg:col-start-auto'}>
                    <Button onClick={handleGenerateReport} leftIcon={<Icon name="documentText" className="w-5 h-5"/>} className="w-full">
                        Generar Reporte
                    </Button>
                </div>
            </div>
        </div>
      </Card>

      <Card title="Historial de Asientos Contables" className="mb-6">
        <div className="p-4">
            <div className="mb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="w-full sm:w-auto sm:max-w-xs">
                    <SelectInput
                        label="Filtrar por Tipo:"
                        options={filterOptions}
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value as 'all' | AccountingEntryType)}
                        containerClassName="mb-0"
                    />
                </div>
            </div>
            <Table columns={columns} data={filteredEntriesForTable} onRowClick={(item) => handleOpenEntryModal(item)} />
        </div>
      </Card>


      {isEntryModalOpen && (
        <Modal
          isOpen={isEntryModalOpen}
          onClose={handleCloseEntryModal}
          title={currentEntry && 'id' in currentEntry && currentEntry.id ? 'Editar Asiento Contable' : 'Crear Nuevo Asiento Contable'}
          size="md"
        >
          <AccountingEntryForm
            initialData={currentEntry as (AccountingEntry | Partial<Pick<AccountingEntry, 'type' | 'category'>> | null)}
            onSave={handleSaveEntry}
            onCancel={handleCloseEntryModal}
            entryTypeOptions={ACCOUNTING_ENTRY_TYPE_OPTIONS}
          />
        </Modal>
      )}

      {isReportModalOpen && reportSummary && (
        <AccountingReportModal
            isOpen={isReportModalOpen}
            onClose={() => setIsReportModalOpen(false)}
            entries={reportEntries}
            summary={reportSummary}
        />
      )}
    </div>
  );
};

export default AccountingPage;


import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Reservation, Customer, Property, ReservationStatus, AccountingEntry, AccountingEntryType, AccountingIncomeCategory, AppSettings, ReportPeriodType, ReservationReportSummary, KPIData, RoomCleaningStatus } from '../types';
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import ReservationForm from '../components/reservations/ReservationForm';
import ReservationReceipt from '../components/reservations/ReservationReceipt';
import ReservationReportModal from '../components/reservations/ReservationReportModal'; 
import useMockData from '../hooks/useMockData';
import { MOCK_RESERVATIONS_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY, RESERVATION_STATUS_OPTIONS, APP_NAME, APP_SETTINGS_KEY } from '../constants';
import TextInput from '../components/common/TextInput';
import DateInput from '../components/common/DateInput';
import SelectInput from '../components/common/SelectInput';
import Card from '../components/common/Card';
import KPICard from '../components/dashboard/KPICard'; 
import { useLocation, useNavigate } from 'react-router-dom';
// import * as googleCalendarService from '../services/googleCalendarService'; // Removed GCal Service

const initialReservations: Reservation[] = [
    { id: 'res1', customerId: 'cust1', propertyId: 'prop1', checkInDate: '2024-07-10', checkInTime: '14:00', checkOutDate: '2024-07-15', checkOutTime: '12:00', numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 750, balanceDue: 0, createdAt: new Date(Date.now() - 5*24*60*60*1000).toISOString() },
    { id: 'res2', customerId: 'cust2', propertyId: 'prop2', checkInDate: '2024-07-12', checkOutDate: '2024-07-18', numberOfGuests: 4, status: ReservationStatus.ADVANCE_PAID, advanceAmount: 100, totalPrice: 1200, balanceDue: 1100, createdAt: new Date(Date.now() - 3*24*60*60*1000).toISOString() },
    { id: 'res3', customerId: 'cust1', propertyId: 'prop2', checkInDate: '2024-08-01', checkOutDate: '2024-08-05', numberOfGuests: 1, status: ReservationStatus.PENDING, totalPrice: 800, balanceDue: 800, createdAt: new Date(Date.now() - 1*24*60*60*1000).toISOString() },
    { id: 'res-today', customerId: 'cust2', propertyId: 'prop1', checkInDate: new Date().toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 3*24*60*60*1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.PENDING, totalPrice: 450, balanceDue: 450, createdAt: new Date().toISOString() },
];
const initialCustomers: Customer[] = [
    { id: 'cust1', fullName: 'Ana Pérez', phone: '555-1234', email: 'ana@example.com', origin: 'CDMX', createdAt: new Date().toISOString() },
    { id: 'cust2', fullName: 'Luis García', phone: '555-5678', origin: 'Guadalajara', createdAt: new Date().toISOString() },
];
const initialProperties: Property[] = [
    { id: 'prop1', name: 'Cabaña del Lago', description: 'Cabaña junto al lago', maxCapacity: 4, bedConfiguration: '1 Queen, 2 Twin', pricePerNight: 150, photoUrls: [], calendarColor: 'bg-primary text-white', maintenanceLog:[], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
    { id: 'prop2', name: 'Suite Montaña', description: 'Suite con vista', maxCapacity: 2, bedConfiguration: '1 King', pricePerNight: 200, photoUrls: [], calendarColor: 'bg-accent text-white', maintenanceLog:[], createdAt: new Date().toISOString(), currentCleaningStatus: RoomCleaningStatus.LIMPIA },
];
const initialAccountingEntries: AccountingEntry[] = [];


const ReservationsPage: React.FC = () => {
  const [reservations, setReservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
  const [customers, setCustomers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialCustomers);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialProperties);
  const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAccountingEntries);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [currentReservation, setCurrentReservation] = useState<Reservation | null>(null);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [filterPropertyId, setFilterPropertyId] = useState('');

  const [isReservationReportModalOpen, setIsReservationReportModalOpen] = useState(false);
  const [reportReservationsSummary, setReportReservationsSummary] = useState<ReservationReportSummary | null>(null);
  const [selectedReservationReportPeriod, setSelectedReservationReportPeriod] = useState<ReportPeriodType>('current_month');
  const [customReservationReportStartDate, setCustomReservationReportStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [customReservationReportEndDate, setCustomReservationReportEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const [appSettings, setAppSettings] = useState<AppSettings>({ 
      appName: APP_NAME, 
      logoUrl: '', 
      hotelEmail: '', 
      responsiblePerson: '', 
      phone: '', 
      defaultCheckInTime: '14:00', 
      defaultCheckOutTime: '12:00',
      // googleCalendarConnected: false, // Removed
      // googleCalendarId: 'primary', // Removed
  });


  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const loadSettings = () => {
        try {
            const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
            if (settingsStr) {
                const parsedSettings = JSON.parse(settingsStr) as AppSettings;
                setAppSettings(prev => ({...prev, ...parsedSettings}));
            }
        } catch (e) {
            console.error("Could not parse app settings in ReservationsPage", e);
        }
    };
    loadSettings();
    window.addEventListener('storage', loadSettings); 

    if (location.state?.openNewReservationModal) {
      const prefillData = location.state.prefillData || (location.state.prefillDate ? { checkInDate: location.state.prefillDate } : {});
      const defaultTimes = {
        checkInTime: appSettings.defaultCheckInTime || '14:00',
        checkOutTime: appSettings.defaultCheckOutTime || '12:00',
      };
      handleOpenModal({ ...defaultTimes, ...prefillData } as Partial<Reservation>);
      navigate(location.pathname, { replace: true, state: {} }); 
    }
    if (location.state?.editReservationId) {
      const resToEdit = reservations.find(r => r.id === location.state.editReservationId);
      if (resToEdit) handleOpenModal(resToEdit);
      navigate(location.pathname, { replace: true, state: {} }); 
    }
  }, [location.state, navigate, reservations, appSettings.defaultCheckInTime, appSettings.defaultCheckOutTime]);


  const handleOpenModal = (reservation: Reservation | Partial<Reservation> | null = null) => {
    const fullInitialData = reservation && !('id' in reservation) 
      ? { 
          checkInTime: appSettings.defaultCheckInTime || '14:00',
          checkOutTime: appSettings.defaultCheckOutTime || '12:00',
          ...reservation 
        }
      : reservation;
    setCurrentReservation(fullInitialData as Reservation | null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCurrentReservation(null);
  };

  const handleOpenReceiptModal = (reservation: Reservation) => {
    setCurrentReservation(reservation);
    setIsReceiptModalOpen(true);
  };

  const handleCloseReceiptModal = () => {
    setIsReceiptModalOpen(false);
    setCurrentReservation(null);
  };
  
  const calculateTotalPrice = useCallback((propertyId: string, checkIn: string, checkOut: string): number => {
    const property = properties.find(p => p.id === propertyId);
    if (!property || !checkIn || !checkOut || new Date(checkOut) <= new Date(checkIn)) return 0;
    const nights = Math.max(0, (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / (1000 * 3600 * 24));
    return nights > 0 ? nights * property.pricePerNight : 0;
  },[properties]);

  const handleSaveReservation = async (
    reservationFormData: Omit<Reservation, 'id' | 'createdAt' | 'totalPrice' | 'balanceDue' | 'customer' | 'property'> & { id?: string },
    newCustomerData?: Omit<Customer, 'id' | 'createdAt'>
  ) => {
    let customerIdToUse = reservationFormData.customerId;
    let createdCustomer: Customer | null = null;

    if (newCustomerData) {
        createdCustomer = {
            ...newCustomerData, 
            id: `cust-${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        setCustomers(prev => [...prev, createdCustomer!]);
        customerIdToUse = createdCustomer.id;
    }
    
    if (!customerIdToUse) {
        alert("Error: ID de cliente no disponible para la reserva.");
        return;
    }

    const reservationDataWithCustomerId = { ...reservationFormData, customerId: customerIdToUse };
    const totalPrice = calculateTotalPrice(reservationDataWithCustomerId.propertyId, reservationDataWithCustomerId.checkInDate, reservationDataWithCustomerId.checkOutDate);
    const balanceDue = totalPrice - (reservationDataWithCustomerId.advanceAmount || 0);
    const fullReservationData = { ...reservationDataWithCustomerId, totalPrice, balanceDue };
    let savedReservation: Reservation;
    const isNewReservation = !(currentReservation && currentReservation.id && reservationFormData.id);

    if (!isNewReservation) { // Editing existing
      savedReservation = { ...currentReservation!, ...fullReservationData, id: currentReservation!.id, createdAt: currentReservation!.createdAt };
      setReservations(prev => prev.map(r => r.id === currentReservation!.id ? savedReservation : r));
    } else { // Creating new
      savedReservation = { ...fullReservationData, id: `res-${Date.now()}`, createdAt: new Date().toISOString() };
      setReservations(prev => [...prev, savedReservation]);
    }

    // Accounting Entry
    if (savedReservation.advanceAmount && savedReservation.advanceAmount > 0 && 
        (savedReservation.status === ReservationStatus.ADVANCE_PAID || savedReservation.status === ReservationStatus.FULLY_PAID)) {
      const existingEntryIndex = accountingEntries.findIndex(entry => entry.reservationId === savedReservation.id && entry.description.includes('Anticipo') );
      const customerForDesc = customers.find(c=>c.id === savedReservation.customerId) || createdCustomer;
      const entry: Omit<AccountingEntry, 'id' | 'createdAt'> = {
        date: new Date().toISOString().split('T')[0],
        type: AccountingEntryType.INCOME,
        category: AccountingIncomeCategory.HOSPEDAJE, 
        description: `Anticipo/Pago Reserva #${savedReservation.id} - Cliente ${customerForDesc?.fullName || savedReservation.customerId}`,
        amount: savedReservation.advanceAmount,
        reservationId: savedReservation.id,
      };
      if (existingEntryIndex > -1) {
        const updatedEntry = { ...accountingEntries[existingEntryIndex], ...entry, amount: savedReservation.advanceAmount };
        setAccountingEntries(prev => prev.map((e, idx) => idx === existingEntryIndex ? updatedEntry : e));
      } else {
        setAccountingEntries(prev => [...prev, { ...entry, id: `acc-${Date.now()}`, createdAt: new Date().toISOString() }]);
      }
    }
    
    // Google Calendar Event Creation Removed
    if (isNewReservation) {
        alert('Reserva guardada.');
    } else {
        alert('Reserva actualizada.'); // For edited reservations
    }

    handleCloseModal();
  };

  const handleDeleteReservation = useCallback((id: string) => {
    if (window.confirm('¿Está seguro de que desea eliminar esta reserva? Esta acción no se puede deshacer.')) {
      setReservations(prev => prev.filter(reservation => reservation.id !== id));
    }
  }, [setReservations]);
  
  const handleShareWhatsApp = (reservation: Reservation) => {
    const customer = customers.find(c => c.id === reservation.customerId);
    const property = properties.find(p => p.id === reservation.propertyId);

    let message = `*Resumen de Reserva - ${appSettings.appName || 'Hotel'}*\n\n`;
    message += `Hola ${customer?.fullName || 'Cliente'},\n\n`;
    message += `Confirmamos los detalles de su reserva:\n`;
    message += `ID Reserva: ${reservation.id}\n`;
    if (property) message += `Propiedad: ${property.name}\n`;
    message += `Check-in: ${new Date(reservation.checkInDate).toLocaleDateString('es-ES')} ${reservation.checkInTime || appSettings.defaultCheckInTime || ''}\n`;
    message += `Check-out: ${new Date(reservation.checkOutDate).toLocaleDateString('es-ES')} ${reservation.checkOutTime || appSettings.defaultCheckOutTime || ''}\n`;
    message += `Huéspedes: ${reservation.numberOfGuests}\n\n`;
    message += `Estado: ${reservation.status}\n`;
    message += `Total: $${reservation.totalPrice.toFixed(2)}\n`;
    if(reservation.advanceAmount) message += `Pagado: $${(reservation.advanceAmount || 0).toFixed(2)}\n`;
    message += `*Saldo Pendiente: $${reservation.balanceDue.toFixed(2)}*\n\n`;
    if (reservation.notes) message += `Notas Adicionales: ${reservation.notes}\n\n`;
    message += `¡Esperamos su llegada!\n`;
    if (appSettings.phone) message += `Si tiene alguna pregunta, contáctenos al: ${appSettings.phone}\n`;
    if (appSettings.hotelEmail) message += `Email: ${appSettings.hotelEmail}\n`;
    const customerPhone = customer?.phone?.replace(/\D/g, '');
    const whatsappUrl = `https://wa.me/${customerPhone || ''}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const getStatusColorClasses = (status: ReservationStatus) => {
    switch (status) {
        case ReservationStatus.FULLY_PAID: return 'bg-success/20 text-success';
        case ReservationStatus.ADVANCE_PAID: return 'bg-warning/20 text-yellow-700';
        case ReservationStatus.PENDING: return 'bg-info/20 text-info';
        case ReservationStatus.CANCELLED: return 'bg-danger/20 text-danger';
        default: return 'bg-gray-100 text-gray-700';
    }
  };

  const enrichedReservations = useMemo(() => {
    return reservations
      .map(res => {
        const customer = customers.find(c => c.id === res.customerId);
        const property = properties.find(p => p.id === res.propertyId);
        return { ...res, customer, property };
      })
      .filter(res => {
        const searchTermLower = searchTerm.toLowerCase();
        const matchesSearch = 
            (res.customer?.fullName.toLowerCase().includes(searchTermLower)) ||
            (res.property?.name.toLowerCase().includes(searchTermLower)) ||
            res.id.toLowerCase().includes(searchTermLower);
        const matchesDate = filterDate ? (res.checkInDate === filterDate || res.checkOutDate === filterDate) : true;
        const matchesProperty = filterPropertyId ? res.propertyId === filterPropertyId : true; 
        return matchesSearch && matchesDate && matchesProperty;
      })
      .sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [reservations, customers, properties, searchTerm, filterDate, filterPropertyId]);

  const reservationKPIs = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const createdToday = reservations.filter(r => new Date(r.createdAt).toISOString().split('T')[0] === todayStr).length;
    const createdThisMonth = reservations.filter(r => {
        const createdAtDate = new Date(r.createdAt);
        return createdAtDate.getMonth() === currentMonth && createdAtDate.getFullYear() === currentYear;
    }).length;
    const createdThisYear = reservations.filter(r => new Date(r.createdAt).getFullYear() === currentYear).length;
    
    const customerOrigins: { [key: string]: number } = {};
    reservations
        .filter(r => r.status !== ReservationStatus.CANCELLED)
        .forEach(res => {
            const customer = customers.find(c => c.id === res.customerId);
            if (customer?.origin && customer.origin.trim() !== '') {
                customerOrigins[customer.origin.trim()] = (customerOrigins[customer.origin.trim()] || 0) + 1;
            }
    });
    const sortedOrigins = Object.entries(customerOrigins)
        .sort(([,a],[,b]) => b-a)
        .slice(0, 2); 

    let topOriginsString = "No especificado";
    if (sortedOrigins.length > 0) {
        topOriginsString = sortedOrigins.map(([origin, count]) => `${origin} (${count})`).join(', ');
    }
    
    const kpis: KPIData[] = [
        { label: 'Reservas Hoy', value: createdToday, icon: <Icon name="plus" className="w-5 h-5 text-success"/>},
        { label: 'Reservas (Mes)', value: createdThisMonth, icon: <Icon name="calendar" className="w-5 h-5 text-primary"/>},
        { label: 'Reservas (Año)', value: createdThisYear, icon: <Icon name="star" className="w-5 h-5 text-info"/>},
        { label: 'Principales Orígenes', value: topOriginsString, icon: <Icon name="mapPin" className="w-5 h-5 text-warning"/>},
    ];
    return kpis;
  }, [reservations, customers]);

  const handleGenerateReservationReport = useCallback(() => {
    let startDate: Date;
    let endDate: Date;
    let periodLabel = "";
    const today = new Date();

    switch (selectedReservationReportPeriod) {
      case 'current_week':
        startDate = new Date(today.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1) )); 
        endDate = new Date(new Date(startDate).setDate(startDate.getDate() + 6)); 
        periodLabel = "Semana Actual (Check-in)";
        break;
      case 'current_month':
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        periodLabel = "Mes Actual (Check-in)";
        break;
      case 'current_year':
        startDate = new Date(today.getFullYear(), 0, 1);
        endDate = new Date(today.getFullYear(), 11, 31);
        periodLabel = "Año Actual (Check-in)";
        break;
      case 'custom_range':
        if (!customReservationReportStartDate || !customReservationReportEndDate || new Date(customReservationReportEndDate) < new Date(customReservationReportStartDate)) {
            alert("Por favor, seleccione un rango de fechas válido para el reporte.");
            return;
        }
        startDate = new Date(customReservationReportStartDate + 'T00:00:00');
        endDate = new Date(customReservationReportEndDate + 'T23:59:59');
        periodLabel = `Rango: ${startDate.toLocaleDateString('es-ES')} - ${endDate.toLocaleDateString('es-ES')} (Check-in)`;
        break;
      default: return;
    }
    
    const sDateStr = startDate.toISOString().split('T')[0];
    const eDateStr = endDate.toISOString().split('T')[0];

    const filteredReportReservations = reservations
      .filter(r => r.checkInDate >= sDateStr && r.checkInDate <= eDateStr)
      .map(res => { 
        const customer = customers.find(c => c.id === res.customerId);
        const property = properties.find(p => p.id === res.propertyId);
        return { ...res, customer, property }; 
      })
      .sort((a,b) => new Date(a.checkInDate).getTime() - new Date(b.checkInDate).getTime());

    const totalRes = filteredReportReservations.length;
    const totalGuests = filteredReportReservations.reduce((sum, r) => sum + r.numberOfGuests, 0);
    const totalRev = filteredReportReservations.filter(r => r.status !== ReservationStatus.CANCELLED).reduce((sum, r) => sum + r.totalPrice, 0);
    const avgPrice = totalRes > 0 ? totalRev / totalRes : 0;
 
    setReportReservationsSummary({
      totalReservations: totalRes,
      totalGuests: totalGuests,
      totalRevenue: totalRev,
      averagePricePerReservation: avgPrice,
      startDate: sDateStr,
      endDate: eDateStr,
      periodTypeLabel: periodLabel,
      generatedAt: new Date().toISOString(), 
    });
    setIsReservationReportModalOpen(true);
  }, [reservations, customers, properties, selectedReservationReportPeriod, customReservationReportStartDate, customReservationReportEndDate]);


  const columns: { header: string; accessor: keyof Reservation | ((item: Reservation) => React.ReactNode); className?: string }[] = [
    { header: 'ID', accessor: 'id', className: 'font-mono text-xs w-20 truncate' }, 
    { header: 'Cliente', accessor: (item) => item.customer?.fullName || item.customerId },
    { header: 'Propiedad', accessor: (item) => item.property?.name || item.propertyId },
    { header: 'Check-in', accessor: (item) => `${new Date(item.checkInDate).toLocaleDateString()} ${item.checkInTime || appSettings.defaultCheckInTime || ''}` },
    { header: 'Check-out', accessor: (item) => `${new Date(item.checkOutDate).toLocaleDateString()} ${item.checkOutTime || appSettings.defaultCheckOutTime || ''}` },
    { header: 'Huéspedes', accessor: 'numberOfGuests', className: 'text-center' },
    { 
      header: 'Estado', 
      accessor: (item) => (
        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColorClasses(item.status)}`}>
          {item.status}
        </span>
      ) 
    },
    { header: 'Total', accessor: (item) => `$${item.totalPrice.toFixed(2)}`, className: 'text-right' },
    { header: 'Saldo', accessor: (item) => `$${item.balanceDue.toFixed(2)}`, className: 'text-right' },
    {
      header: 'Acciones',
      accessor: (item) => (
        <div className="flex space-x-1 items-center">
          <button onClick={(e) => { e.stopPropagation(); handleOpenReceiptModal(item);}} title="Ver Recibo" className="p-1 text-muted-foreground hover:text-accent">
            <Icon name="receipt" className="w-4 h-4" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); handleOpenModal(item); }} title="Editar" className="p-1 text-muted-foreground hover:text-accent">
            <Icon name="edit" className="w-4 h-4" />
          </button>
           <button onClick={(e) => { e.stopPropagation(); handleShareWhatsApp(item); }} title="Compartir por WhatsApp" className="p-1 text-green-500 hover:text-green-600">
            <Icon name="whatsapp" className="w-4 h-4" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); handleDeleteReservation(item.id); }} className="p-1 text-danger hover:opacity-80 focus:opacity-100" title="Eliminar">
            <Icon name="trash" className="w-4 h-4" />
          </button>
        </div>
      ),
      className: 'w-32' 
    },
  ];
  
  const propertyOptions = [{value: '', label: 'Todas las Propiedades'}, ...properties.map(p => ({value: p.id, label: p.name}))];
  const reportPeriodOptions = [
    { value: 'current_week', label: 'Semana Actual' },
    { value: 'current_month', label: 'Mes Actual' },
    { value: 'current_year', label: 'Año Actual' },
    { value: 'custom_range', label: 'Rango Personalizado' },
  ];

  return (
    <div>
      <PageTitle title="Gestión de Reservas" actionButton={
        <Button onClick={() => handleOpenModal()} leftIcon={<Icon name="plus" className="w-5 h-5"/>}>
          Nueva Reserva
        </Button>
      }/>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6"> 
        {reservationKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi} />)}
      </div>

      <Card className="mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 items-end">
          <TextInput 
            label="Buscar Reserva (ID, Cliente, Propiedad)"
            placeholder="Escriba para buscar..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            containerClassName="mb-0"
          />
          <DateInput
            label="Filtrar por Fecha Check-in/out"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            containerClassName="mb-0"
          />
          <SelectInput
            label="Filtrar por Propiedad"
            options={propertyOptions}
            value={filterPropertyId}
            onChange={(e) => setFilterPropertyId(e.target.value)}
            containerClassName="mb-0"
          />
        </div>
      </Card>

      <Card title="Generar Reporte de Reservas" className="mb-6">
        <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                 <SelectInput
                    label="Seleccionar Periodo (por Check-in):"
                    options={reportPeriodOptions}
                    value={selectedReservationReportPeriod}
                    onChange={(e) => setSelectedReservationReportPeriod(e.target.value as ReportPeriodType)}
                    containerClassName="mb-0"
                />
                {selectedReservationReportPeriod === 'custom_range' && (
                    <>
                        <DateInput
                            label="Fecha de Inicio (Check-in):"
                            value={customReservationReportStartDate}
                            onChange={(e) => setCustomReservationReportStartDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                        <DateInput
                            label="Fecha de Fin (Check-in):"
                            value={customReservationReportEndDate}
                            onChange={(e) => setCustomReservationReportEndDate(e.target.value)}
                            containerClassName="mb-0"
                        />
                    </>
                )}
                <div className={selectedReservationReportPeriod === 'custom_range' ? 'lg:col-start-4' : 'lg:col-start-auto'}>
                    <Button onClick={handleGenerateReservationReport} leftIcon={<Icon name="documentText" className="w-5 h-5"/>} className="w-full">
                        Generar Reporte
                    </Button>
                </div>
            </div>
        </div>
      </Card>


      <Table columns={columns} data={enrichedReservations} onRowClick={(item) => handleOpenModal(item as Reservation)} />

      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={currentReservation?.id ? 'Editar Reserva' : 'Crear Nueva Reserva'}
          size="lg"
        >
          <ReservationForm
            initialData={currentReservation}
            customers={customers}
            properties={properties}
            reservationStatusOptions={RESERVATION_STATUS_OPTIONS}
            onSave={handleSaveReservation}
            onCancel={handleCloseModal}
            calculateTotalPrice={calculateTotalPrice}
          />
        </Modal>
      )}

      {isReceiptModalOpen && currentReservation && (
        <Modal
            isOpen={isReceiptModalOpen}
            onClose={handleCloseReceiptModal}
            title={`Recibo de Reserva - ${currentReservation.id}`}
            size="md"
        >
            <ReservationReceipt 
                reservation={currentReservation} 
                customer={customers.find(c => c.id === currentReservation.customerId)} 
                property={properties.find(p => p.id === currentReservation.propertyId)} 
            />
        </Modal>
      )}

      {isReservationReportModalOpen && reportReservationsSummary && (
        <ReservationReportModal
            isOpen={isReservationReportModalOpen}
            onClose={() => setIsReservationReportModalOpen(false)}
            summary={reportReservationsSummary}
        />
      )}
    </div>
  );
};

export default ReservationsPage;

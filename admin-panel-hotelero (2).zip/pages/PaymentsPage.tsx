import React, { useState, useMemo, useCallback } from 'react';
import { Reservation, Customer, Property, AccountingEntry, AccountingEntryType, PaymentMethod, ReservationPayment, ReservationStatus, AccountingIncomeCategory } from '../types';
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import Card from '../components/common/Card';
import SelectInput from '../components/common/SelectInput';
import TextInput from '../components/common/TextInput';
import DateInput from '../components/common/DateInput';
import useMockData from '../hooks/useMockData';
import { MOCK_RESERVATIONS_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY, PAYMENT_METHOD_OPTIONS } from '../constants';

// For simplicity, using existing mock data keys. In a real app, payments might have their own.

const PaymentsPage: React.FC = () => {
  const [reservations, setReservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, []);
  const [customers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, []);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, []);
  const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, []);

  const [selectedReservationId, setSelectedReservationId] = useState<string>('');
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  const activeReservationsWithBalance = useMemo(() => {
    return reservations.filter(r => r.balanceDue > 0 && r.status !== ReservationStatus.CANCELLED);
  }, [reservations]);

  const selectedReservation = useMemo(() => {
    if (!selectedReservationId) return null;
    const reservation = activeReservationsWithBalance.find(r => r.id === selectedReservationId);
    if (!reservation) return null;
    const customer = customers.find(c => c.id === reservation.customerId);
    const property = properties.find(p => p.id === reservation.propertyId);
    return { ...reservation, customer, property };
  }, [selectedReservationId, activeReservationsWithBalance, customers, properties]);

  const handleRecordPayment = useCallback(() => {
    if (!selectedReservation || paymentAmount <= 0) {
      alert('Por favor, seleccione una reserva y ingrese un monto de pago válido.');
      return;
    }
    if (paymentAmount > selectedReservation.balanceDue) {
      alert('El monto del pago no puede exceder el saldo pendiente.');
      return;
    }

    const newPayment: ReservationPayment = {
      id: `pay-${Date.now()}`,
      amount: paymentAmount,
      paymentDate,
      method: paymentMethod,
      notes: paymentNotes,
      createdAt: new Date().toISOString(),
    };

    // Update Reservation
    const updatedReservation: Reservation = {
      ...selectedReservation,
      advanceAmount: (selectedReservation.advanceAmount || 0) + paymentAmount,
      balanceDue: selectedReservation.balanceDue - paymentAmount,
      payments: [...(selectedReservation.payments || []), newPayment],
      status: (selectedReservation.balanceDue - paymentAmount <= 0) ? ReservationStatus.FULLY_PAID : selectedReservation.status,
    };
    setReservations(prev => prev.map(r => r.id === selectedReservation.id ? updatedReservation : r));

    // Create Accounting Entry
    const newAccountingEntry: AccountingEntry = {
      id: `acc-${Date.now()}`,
      date: paymentDate,
      type: AccountingEntryType.INCOME,
      category: AccountingIncomeCategory.HOSPEDAJE, // Corrected category
      description: `Pago Reserva #${selectedReservation.id} (${selectedReservation.customer?.fullName || 'N/A'}) - Método: ${paymentMethod}`,
      amount: paymentAmount,
      createdAt: new Date().toISOString(),
      reservationId: selectedReservation.id,
    };
    setAccountingEntries(prev => [...prev, newAccountingEntry]);

    alert('Pago registrado exitosamente!');
    // Reset form
    setSelectedReservationId('');
    setPaymentAmount(0);
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setPaymentMethod(PaymentMethod.CASH);
    setPaymentNotes('');

  }, [selectedReservation, paymentAmount, paymentDate, paymentMethod, paymentNotes, setReservations, setAccountingEntries, customers]);


  const reservationOptions = activeReservationsWithBalance.map(r => {
    const cust = customers.find(c => c.id === r.customerId);
    return { value: r.id, label: `ID: ${r.id} - ${cust?.fullName || 'Cliente Desconocido'} (Saldo: $${r.balanceDue.toFixed(2)})` };
  });

  return (
    <div>
      <PageTitle title="Registrar Pagos de Reservas" />

      <Card title="Seleccionar Reserva y Registrar Pago">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <SelectInput
              label="Seleccionar Reserva con Saldo Pendiente*"
              options={reservationOptions}
              value={selectedReservationId}
              onChange={(e) => setSelectedReservationId(e.target.value)}
              containerClassName="mb-0"
            />
            {selectedReservation && (
              <div className="p-4 bg-background rounded-md shadow space-y-2 text-sm">
                <p><strong>Cliente:</strong> {selectedReservation.customer?.fullName}</p>
                <p><strong>Propiedad:</strong> {selectedReservation.property?.name}</p>
                <p><strong>Total Reserva:</strong> ${selectedReservation.totalPrice.toFixed(2)}</p>
                <p><strong>Total Pagado:</strong> ${selectedReservation.advanceAmount?.toFixed(2) || '0.00'}</p>
                <p className="font-semibold text-danger"><strong>Saldo Pendiente:</strong> ${selectedReservation.balanceDue.toFixed(2)}</p>
              </div>
            )}
          </div>

          {selectedReservation && (
            <div className="space-y-4 border-t md:border-t-0 md:border-l border-border-color pt-6 md:pt-0 md:pl-6">
              <TextInput
                label="Monto a Pagar*"
                type="number"
                value={paymentAmount.toString()}
                onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                min="0.01"
                step="0.01"
                max={selectedReservation.balanceDue.toString()}
                disabled={!selectedReservationId}
              />
              <DateInput
                label="Fecha de Pago*"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                disabled={!selectedReservationId}
              />
              <SelectInput
                label="Método de Pago*"
                options={PAYMENT_METHOD_OPTIONS}
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                disabled={!selectedReservationId}
              />
              <TextInput
                label="Notas del Pago (Opcional)"
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                disabled={!selectedReservationId}
              />
              <Button 
                onClick={handleRecordPayment} 
                disabled={!selectedReservationId || paymentAmount <= 0 || paymentAmount > selectedReservation.balanceDue}
                leftIcon={<Icon name="check" className="w-5 h-5"/>}
              >
                Registrar Pago
              </Button>
            </div>
          )}
        </div>
      </Card>
      
      <Card title="Guía de Otros Pagos" className="mt-6">
        <ul className="list-disc list-inside space-y-2 text-sm text-muted-foreground">
            <li>Para registrar pagos a personal (nóminas, etc.), utilice el módulo de <a href="#/accounting" className="text-primary hover:underline">Contabilidad</a> creando un nuevo asiento de tipo "Gasto" con la categoría "Personal".</li>
            <li>Para registrar pagos de servicios generales (luz, agua, internet, proveedores), utilice el módulo de <a href="#/accounting" className="text-primary hover:underline">Contabilidad</a> creando un nuevo asiento de tipo "Gasto" con la categoría correspondiente (Ej: "Fijos", "Operativos").</li>
        </ul>
      </Card>
    </div>
  );
};

export default PaymentsPage;
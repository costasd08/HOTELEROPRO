
import React, { useState, useMemo, useCallback } from 'react';
import {
  Reservation, Property, AccountingEntry, Customer, AppSettings,
  KPIData, ReportPeriodType, ReservationStatus, AccountingEntryType,
  AnalyticsReportSummary, AnalyticsSectionData, ChartDataPoint, TrendData, RoomCleaningStatus, Order, OrderStatus, MenuItem, MenuItemCategory
} from '../../types';
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import AnalyticsReportModal from '../../components/analytics/AnalyticsReportModal';
import SimpleBarDisplay from '../../components/analytics/SimpleBarDisplay';
import SimplePieDisplay from '../../components/analytics/SimplePieDisplay';
// SimpleTrendDisplay is no longer needed for financial summary, but might be used for restaurant trends later
import SimpleTrendDisplay from '../../components/analytics/SimpleTrendDisplay'; 
import useMockData from '../../hooks/useMockData';
import {
  MOCK_RESERVATIONS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, MOCK_ACCOUNTING_ENTRIES_DATA_KEY,
  MOCK_CUSTOMERS_DATA_KEY, APP_SETTINGS_KEY, APP_NAME, MOCK_ORDERS_DATA_KEY, MOCK_MENU_ITEMS_DATA_KEY
} from '../../constants';
import SelectInput from '../../components/common/SelectInput';
import DateInput from '../../components/common/DateInput';

const initialAnalyticsReservations: Reservation[] = [];
const initialAnalyticsProperties: Property[] = [];
const initialAnalyticsAccounting: AccountingEntry[] = [];
const initialAnalyticsCustomers: Customer[] = [];
const initialAnalyticsOrders: Order[] = [];
const initialMenuItems: MenuItem[] = [];


const AnalyticsPage: React.FC = () => {
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialAnalyticsReservations);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, initialAnalyticsProperties);
  const [accountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, initialAnalyticsAccounting);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [customers, _setCustomers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialAnalyticsCustomers);
  const [orders] = useMockData<Order>(MOCK_ORDERS_DATA_KEY, initialAnalyticsOrders);
  const [menuItems] = useMockData<MenuItem>(MOCK_MENU_ITEMS_DATA_KEY, initialMenuItems);

  const [selectedPeriod, setSelectedPeriod] = useState<ReportPeriodType>('current_month');
  const [customStartDate, setCustomStartDate] = useState<string>(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
  const [customEndDate, setCustomEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportSummaryData, setReportSummaryData] = useState<AnalyticsReportSummary | null>(null);
  
  const [appSettings, setAppSettings] = useState<AppSettings>({
    appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
    defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomFooterText: '',
    reportCustomHeaderText: '', reservationPolicies: '', cancellationPolicies: '',
    generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
    weatherWidgetHref: '', weatherWidgetDataLabel: '', defaultKitchenOverheadRate: 0.1, defaultAdminSalesOverheadRate: 0.15
  });

  React.useEffect(() => {
    const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
    if (storedSettings) {
      try {
        const parsed = JSON.parse(storedSettings);
        setAppSettings(prev => ({ ...prev, ...parsed }));
      } catch (e) { console.error("Error parsing settings", e); }
    }
  }, []);

  const getPeriodDates = useCallback(() => {
    let sDate: Date, eDate: Date;
    const today = new Date();
    today.setHours(0,0,0,0); 

    switch (selectedPeriod) {
      case 'current_week':
        sDate = new Date(today);
        sDate.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)); 
        eDate = new Date(sDate);
        eDate.setDate(sDate.getDate() + 6); 
        break;
      case 'current_month':
        sDate = new Date(today.getFullYear(), today.getMonth(), 1);
        eDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        break;
      case 'current_year':
        sDate = new Date(today.getFullYear(), 0, 1);
        eDate = new Date(today.getFullYear(), 11, 31);
        break;
      case 'custom_range':
        sDate = new Date(customStartDate + 'T00:00:00');
        eDate = new Date(customEndDate + 'T00:00:00');
        break;
      default:
        sDate = new Date(today.getFullYear(), today.getMonth(), 1);
        eDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    }
    eDate.setHours(23, 59, 59, 999); 
    return { startDate: sDate, endDate: eDate };
  }, [selectedPeriod, customStartDate, customEndDate]);
  
  // getPreviousPeriodDates is kept as it might be useful for restaurant trends later
  const getPreviousPeriodDates = useCallback((currentStartDate: Date, currentEndDate: Date, periodType: ReportPeriodType) => {
    let prevStartDate: Date, prevEndDate: Date;
    switch(periodType){
        case 'current_week':
            prevStartDate = new Date(currentStartDate);
            prevStartDate.setDate(currentStartDate.getDate() - 7);
            prevEndDate = new Date(currentEndDate);
            prevEndDate.setDate(currentEndDate.getDate() - 7);
            break;
        case 'current_month':
            prevStartDate = new Date(currentStartDate.getFullYear(), currentStartDate.getMonth() - 1, 1);
            prevEndDate = new Date(currentStartDate.getFullYear(), currentStartDate.getMonth(), 0);
            break;
        case 'current_year':
            prevStartDate = new Date(currentStartDate.getFullYear() - 1, 0, 1);
            prevEndDate = new Date(currentStartDate.getFullYear() - 1, 11, 31);
            break;
        default: 
            const diff = currentEndDate.getTime() - currentStartDate.getTime();
            prevStartDate = new Date(currentStartDate.getTime() - diff - (1 * 24 * 60 * 60 * 1000));
            prevEndDate = new Date(currentStartDate.getTime() - (1 * 24 * 60 * 60 * 1000)); 
            break;
    }
    prevEndDate.setHours(23,59,59,999);
    return { startDate: prevStartDate, endDate: prevEndDate };
  }, []);


  const occupancyData = useMemo(() => {
    const { startDate, endDate } = getPeriodDates();
    let totalNightsAvailable = 0;
    let totalNightsBooked = 0;
    const revenueByProperty: { [key: string]: number } = {};
    let totalDuration = 0;
    let bookedReservationsCount = 0;

    properties.forEach(prop => {
      const diffDays = Math.max(0, (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24)) + 1;
      totalNightsAvailable += diffDays * prop.maxCapacity; 
    });

    reservations.forEach(res => {
      if (res.status === ReservationStatus.CANCELLED) return;
      const checkIn = new Date(res.checkInDate + 'T00:00:00');
      const checkOut = new Date(res.checkOutDate + 'T00:00:00');
      const overlapStart = new Date(Math.max(startDate.getTime(), checkIn.getTime()));
      const overlapEnd = new Date(Math.min(endDate.getTime() + (24*60*60*1000-1), checkOut.getTime())); 
      
      if (overlapStart < overlapEnd) {
        const nightsInPeriod = Math.max(0, (overlapEnd.getTime() - overlapStart.getTime()) / (1000 * 3600 * 24));
        totalNightsBooked += nightsInPeriod * res.numberOfGuests; 
        const stayDurationTotal = Math.max(1, (checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24));
        const revenueForThisStayInPeriod = (res.totalPrice / stayDurationTotal) * nightsInPeriod;
        revenueByProperty[res.propertyId] = (revenueByProperty[res.propertyId] || 0) + (isNaN(revenueForThisStayInPeriod) ? 0 : revenueForThisStayInPeriod);
        totalDuration += stayDurationTotal; 
        bookedReservationsCount++;
      }
    });

    const occupancyRate = totalNightsAvailable > 0 ? (totalNightsBooked / totalNightsAvailable) * 100 : 0;
    const revPAR = totalNightsAvailable > 0 ? (Object.values(revenueByProperty).reduce((s,r)=>s+r,0) / (properties.length ? (totalNightsAvailable / properties.length) : 1)) : 0;
    const avgStayDuration = bookedReservationsCount > 0 ? totalDuration / bookedReservationsCount : 0;
    
    const topPropertiesByRevenue = Object.entries(revenueByProperty)
        .map(([id, revenue]) => ({ id, label: properties.find(p => p.id === id)?.name || id, value: revenue, color: properties.find(p => p.id === id)?.calendarColor.split(' ').find(c => c.startsWith('bg-')) || 'bg-primary' }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 3);

    return { occupancyRate, revPAR, avgStayDuration, topPropertiesByRevenue };
  }, [reservations, properties, getPeriodDates]);

  const financialData = useMemo(() => {
    const { startDate, endDate } = getPeriodDates();
    const relevantEntries = accountingEntries.filter(e => {
      const entryDate = new Date(e.date + 'T00:00:00');
      return entryDate >= startDate && entryDate <= endDate;
    });

    const totalIncome = relevantEntries.filter(e => e.type === AccountingEntryType.INCOME).reduce((sum, e) => sum + e.amount, 0);
    const totalExpenses = relevantEntries.filter(e => e.type === AccountingEntryType.EXPENSE).reduce((sum, e) => sum + e.amount, 0);
    const netBalance = totalIncome - totalExpenses;

    const incomeByCategory = relevantEntries.filter(e => e.type === AccountingEntryType.INCOME).reduce((acc, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {} as { [key: string]: number });

    const expensesByCategory = relevantEntries.filter(e => e.type === AccountingEntryType.EXPENSE).reduce((acc, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {} as { [key: string]: number });

    return {
      totalIncome, totalExpenses, netBalance,
      incomeBreakdown: Object.entries(incomeByCategory).map(([label, value]) => ({ label, value, id: label })),
      expenseBreakdown: Object.entries(expensesByCategory).map(([label, value]) => ({ label, value, id: label })),
    };
  }, [accountingEntries, getPeriodDates]);

  const occupancyTrend = useMemo(() => {
    const periods: TrendData[] = [];
    let current = getPeriodDates();
    for (let i = 0; i < 3; i++) {
        let totalNightsAvailable = 0;
        let totalNightsBooked = 0;
        properties.forEach(prop => {
            const diffDays = Math.max(0, (current.endDate.getTime() - current.startDate.getTime()) / (1000 * 3600 * 24)) + 1;
            totalNightsAvailable += diffDays * prop.maxCapacity;
        });
        reservations.forEach(res => {
            if (res.status === ReservationStatus.CANCELLED) return;
            const checkIn = new Date(res.checkInDate + 'T00:00:00');
            const checkOut = new Date(res.checkOutDate + 'T00:00:00');
            const overlapStart = new Date(Math.max(current.startDate.getTime(), checkIn.getTime()));
            const overlapEnd = new Date(Math.min(current.endDate.getTime() + (24*60*60*1000-1), checkOut.getTime()));
            if (overlapStart < overlapEnd) {
                totalNightsBooked += (Math.max(0, (overlapEnd.getTime() - overlapStart.getTime()) / (1000 * 3600 * 24))) * res.numberOfGuests;
            }
        });
        const rate = totalNightsAvailable > 0 ? (totalNightsBooked / totalNightsAvailable) * 100 : 0;
        periods.unshift({ period: `${current.startDate.toLocaleDateString('es-ES', {month:'short', year:'2-digit'})}`, value: parseFloat(rate.toFixed(1)) });
        if (i < 2) { 
            current = getPreviousPeriodDates(current.startDate, current.endDate, selectedPeriod === 'custom_range' ? 'current_month' : selectedPeriod); 
        }
    }
    return periods;
  }, [getPeriodDates, getPreviousPeriodDates, properties, reservations, selectedPeriod]);

  const restaurantAnalyticsData = useMemo(() => {
    const { startDate, endDate } = getPeriodDates();
    const periodOrders = orders.filter(o => {
        const orderDate = new Date(o.createdAt);
        return orderDate >= startDate && orderDate <= endDate && o.status === OrderStatus.PAGADO;
    });

    const totalRestaurantOrders = periodOrders.length;
    const totalRestaurantRevenue = periodOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const averageOrderValue = totalRestaurantOrders > 0 ? totalRestaurantRevenue / totalRestaurantOrders : 0;

    const itemCounts: { [key: string]: { name: string, quantity: number } } = {};
    periodOrders.forEach(order => {
        order.items.forEach(item => {
            const menuItem = menuItems.find(mi => mi.id === item.menuItemId);
            if (menuItem) {
                if (!itemCounts[item.menuItemId]) {
                    itemCounts[item.menuItemId] = { name: menuItem.name, quantity: 0 };
                }
                itemCounts[item.menuItemId].quantity += item.quantity;
            }
        });
    });
    const mostSoldRaw = Object.values(itemCounts).sort((a,b) => b.quantity - a.quantity)[0];
    const mostSoldItem = mostSoldRaw ? `${mostSoldRaw.name} (${mostSoldRaw.quantity})` : 'N/A';

    const revenueByCategory = periodOrders.reduce((acc, order) => {
        order.items.forEach(item => {
            const menuItem = menuItems.find(mi => mi.id === item.menuItemId);
            if (menuItem) {
                const category = menuItem.category || 'Otra';
                acc[category] = (acc[category] || 0) + (item.sellingPriceAtOrderTime * item.quantity);
            }
        });
        return acc;
    }, {} as Record<string, number>);
    const revenueByCategoryChartData: ChartDataPoint[] = Object.entries(revenueByCategory)
        .map(([label, value]) => ({ label, value, id: label }))
        .sort((a,b) => b.value - a.value);

    const ordersByDayOfWeekArray = Array(7).fill(0); // 0: Dom, 1: Lun, ... 6: Sab
    const dayLabels = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    periodOrders.forEach(order => {
        const dayIndex = new Date(order.createdAt + 'T00:00:00').getDay(); // Ensure local interpretation for day
        ordersByDayOfWeekArray[dayIndex]++;
    });
    const ordersByDayOfWeekChartData: ChartDataPoint[] = dayLabels.map((label, index) => ({
        label, value: ordersByDayOfWeekArray[index], id: label
    }));

    return {
        totalRestaurantOrders,
        totalRestaurantRevenue,
        averageOrderValue,
        mostSoldItem,
        revenueByCategoryChartData,
        ordersByDayOfWeekChartData
    };
  }, [orders, menuItems, getPeriodDates]);


  const handleGenerateReport = () => {
    const { startDate, endDate } = getPeriodDates();
    const periodLabel = `${formatDateToDMesAño(startDate.toISOString())} - ${formatDateToDMesAño(endDate.toISOString())}`;

    const occupancySection: AnalyticsSectionData = {
      title: "Ocupación y Rendimiento de Propiedades",
      kpis: [
        { label: "Tasa Ocupación Promedio", value: `${occupancyData.occupancyRate.toFixed(1)}%` },
        { label: "RevPAR (Simplificado)", value: `$${occupancyData.revPAR.toFixed(2)}` },
        { label: "Duración Promedio Estadía", value: `${occupancyData.avgStayDuration.toFixed(1)} noches` },
      ],
      charts: [
        { id: 'occTrend', title: "Tendencia Tasa de Ocupación (%)", type: 'trend', data: occupancyTrend },
        { id: 'topProps', title: "Top Propiedades por Ingresos", type: 'bar', data: occupancyData.topPropertiesByRevenue },
      ]
    };

    const financialSection: AnalyticsSectionData = {
      title: "Análisis Financiero General",
      kpis: [
        { label: "Ingresos Totales", value: `$${financialData.totalIncome.toFixed(2)}` },
        { label: "Gastos Totales", value: `$${financialData.totalExpenses.toFixed(2)}` },
        { label: "Beneficio Neto", value: `$${financialData.netBalance.toFixed(2)}` },
      ],
      charts: [
        // Removed: { id: 'incExpTrend', title: "Tendencia Ingresos vs. Gastos", type: 'trend', data: incomeExpenseTrend },
        { id: 'incBreakdown', title: "Desglose de Ingresos (%)", type: 'pie', data: financialData.incomeBreakdown },
        { id: 'expBreakdown', title: "Desglose de Gastos (%)", type: 'pie', data: financialData.expenseBreakdown },
      ]
    };
    
    const restaurantSection: AnalyticsSectionData = {
        title: "Análisis del Restaurante",
        kpis: [
            {label: "Total Órdenes Pagadas", value: restaurantAnalyticsData.totalRestaurantOrders},
            {label: "Ingresos Totales Restaurante", value: `$${restaurantAnalyticsData.totalRestaurantRevenue.toFixed(2)}`},
            {label: "Valor Promedio por Orden", value: `$${restaurantAnalyticsData.averageOrderValue.toFixed(2)}`},
            {label: "Platillo Más Vendido", value: restaurantAnalyticsData.mostSoldItem },
        ],
        charts: [
            { id: 'resRevenueByCategory', title: "Ingresos por Categoría de Platillo", type: 'bar', data: restaurantAnalyticsData.revenueByCategoryChartData },
            { id: 'resOrdersByDay', title: "Órdenes por Día de la Semana", type: 'bar', data: restaurantAnalyticsData.ordersByDayOfWeekChartData }
        ]
    };

    setReportSummaryData({
      reportTitle: `Reporte Analítico Consolidado - ${appSettings.appName}`,
      periodLabel,
      generatedAt: new Date().toISOString(),
      sections: [occupancySection, financialSection, restaurantSection], 
      overallSummary: `Análisis general del periodo ${periodLabel}.`,
    });
    setIsReportModalOpen(true);
  };
  
  const reportPeriodOptions: { value: ReportPeriodType; label: string }[] = [
    { value: 'current_month', label: 'Mes Actual' },
    { value: 'current_week', label: 'Semana Actual' },
    { value: 'current_year', label: 'Año Actual' },
    { value: 'custom_range', label: 'Rango Personalizado' },
  ];

  const formatDateToDMesAño = (dateString: string): string => {
    const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
    if (isNaN(dateObj.getTime())) return "Fecha Inválida";
    const day = dateObj.getDate();
    const month = dateObj.toLocaleDateString('es-ES', { month: 'short' }).replace('.', '');
    const year = dateObj.getFullYear();
    return `${day}/${month}/${year}`;
  };


  return (
    <div>
      <PageTitle title="Centro de Analíticas y Reportes" />

      <Card className="mb-6">
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <SelectInput
              label="Seleccionar Periodo:"
              options={reportPeriodOptions}
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value as ReportPeriodType)}
              containerClassName="md:col-span-1 mb-0"
            />
            {selectedPeriod === 'custom_range' && (
              <>
                <DateInput label="Fecha de Inicio:" value={customStartDate} onChange={(e) => setCustomStartDate(e.target.value)} containerClassName="mb-0"/>
                <DateInput label="Fecha de Fin:" value={customEndDate} onChange={(e) => setCustomEndDate(e.target.value)} containerClassName="mb-0"/>
              </>
            )}
             <div className={selectedPeriod === 'custom_range' ? "md:col-span-3" : "md:col-span-2 self-end"}>
                <Button 
                    onClick={handleGenerateReport} 
                    leftIcon={<Icon name="documentText" />} 
                    className="w-full"
                    disabled={selectedPeriod === 'custom_range' && (!customStartDate || !customEndDate || new Date(customEndDate) < new Date(customStartDate))}
                >
                    Generar Reporte Consolidado
                </Button>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Ocupación y Rendimiento de Propiedades" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <KPICard kpi={{ label: "Tasa Ocupación", value: `${occupancyData.occupancyRate.toFixed(1)}%`, icon: <Icon name="users" /> }} />
            <KPICard kpi={{ label: "RevPAR (Simpl.)", value: `$${occupancyData.revPAR.toFixed(2)}`, icon: <Icon name="cash" /> }} />
            <KPICard kpi={{ label: "Estadía Prom.", value: `${occupancyData.avgStayDuration.toFixed(1)} N`, icon: <Icon name="calendar" /> }} />
          </div>
          <SimpleTrendDisplay title="Tendencia Ocupación (%)" data={occupancyTrend} />
          <SimpleBarDisplay title="Top 3 Propiedades por Ingresos" data={occupancyData.topPropertiesByRevenue} />
        </Card>

        <Card title="Análisis Financiero General" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <KPICard kpi={{ label: "Ingresos", value: `$${financialData.totalIncome.toFixed(2)}`, icon: <Icon name="arrowRight" className="text-success rotate-[-45deg]"/> }} />
            <KPICard kpi={{ label: "Gastos", value: `$${financialData.totalExpenses.toFixed(2)}`, icon: <Icon name="arrowRight" className="text-danger rotate-[135deg]"/> }} />
            <KPICard kpi={{ label: "Beneficio Neto", value: `$${financialData.netBalance.toFixed(2)}`, icon: <Icon name="star" /> }} />
          </div>
          {/* Removed: <SimpleTrendDisplay title="Tendencia Ingresos vs. Gastos" data={incomeExpenseTrend} /> */}
          <SimplePieDisplay title="Desglose Ingresos (%)" data={financialData.incomeBreakdown} />
          <SimplePieDisplay title="Desglose Gastos (%)" data={financialData.expenseBreakdown} />
        </Card>

        <Card title="Análisis del Restaurante" className="lg:col-span-2 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <KPICard kpi={{label: "Órdenes Pagadas", value: restaurantAnalyticsData.totalRestaurantOrders, icon: <Icon name="receipt"/>}}/>
                <KPICard kpi={{label: "Ingresos Totales", value: `$${restaurantAnalyticsData.totalRestaurantRevenue.toFixed(2)}`, icon: <Icon name="cash"/>}}/>
                <KPICard kpi={{label: "Ticket Promedio", value: `$${restaurantAnalyticsData.averageOrderValue.toFixed(2)}`, icon: <Icon name="chartBar"/>}}/>
                <KPICard kpi={{label: "Más Vendido", value: restaurantAnalyticsData.mostSoldItem, icon: <Icon name="star"/>}}/>
            </div>
            <SimpleBarDisplay title="Ingresos por Categoría de Platillo" data={restaurantAnalyticsData.revenueByCategoryChartData} />
            <SimpleBarDisplay title="Órdenes por Día de la Semana" data={restaurantAnalyticsData.ordersByDayOfWeekChartData} />
        </Card>
      </div>
      

      {isReportModalOpen && reportSummaryData && (
        <AnalyticsReportModal
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          summary={reportSummaryData}
          appSettings={appSettings}
        />
      )}
    </div>
  );
};

export default AnalyticsPage;

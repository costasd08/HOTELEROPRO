
import React, { useState, useMemo, useCallback } from 'react';
import { InventoryItem, InventoryCategoryType, KPIData, AccountingEntry, AccountingEntryType, AccountingExpenseCategory } from '../../types';
import PageTitle from '../components/common/PageTitle';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import Table, { TableColumn } from '../components/common/Table';
import Card from '../components/common/Card';
import KPICard from '../components/dashboard/KPICard';
import InventoryItemForm from '../components/inventory/InventoryItemForm';
import useMockData from '../hooks/useMockData';
import { MOCK_INVENTORY_ITEMS_DATA_KEY, INVENTORY_CATEGORY_OPTIONS, MOCK_ACCOUNTING_ENTRIES_DATA_KEY } from '../constants';
import SelectInput from '../components/common/SelectInput';
import TextInput from '../components/common/TextInput';

const initialInventoryItems: InventoryItem[] = [
    { id: 'inv-res-1', name: 'Tomates Frescos', category: InventoryCategoryType.RESTAURANTE, quantity: 20, unit: 'kg', purchasePrice: 25.50, lowStockThreshold: 5, supplierInfo: 'Proveedor Frutas & Verduras', lastRestockDate: '2024-07-15', createdAt: new Date().toISOString() },
    { id: 'inv-res-2', name: 'Pechuga de Pollo', category: InventoryCategoryType.RESTAURANTE, quantity: 10, unit: 'kg', purchasePrice: 80.00, lowStockThreshold: 2, createdAt: new Date().toISOString() },
    { id: 'inv-cab-1', name: 'Sábanas Matrimoniales', category: InventoryCategoryType.CABANAS_HABITACIONES, quantity: 50, unit: 'unidad', purchasePrice: 150.00, lowStockThreshold: 10, notes: 'Algodón Egipcio', createdAt: new Date().toISOString() },
    { id: 'inv-cab-2', name: 'Jabón de Tocador (Caja 100u)', category: InventoryCategoryType.CABANAS_HABITACIONES, quantity: 5, unit: 'caja', purchasePrice: 250.00, lowStockThreshold: 1, createdAt: new Date().toISOString() },
    { id: 'inv-man-1', name: 'Martillos', category: InventoryCategoryType.MANTENIMIENTO_GENERAL, quantity: 3, unit: 'unidad', purchasePrice: 120.00, lowStockThreshold: 1, createdAt: new Date().toISOString() },
    { id: 'inv-man-2', name: 'Focos LED (Paquete 10u)', category: InventoryCategoryType.MANTENIMIENTO_GENERAL, quantity: 10, unit: 'paquete', purchasePrice: 90.00, createdAt: new Date().toISOString() },
];

const InventoryPage: React.FC = () => {
    const [inventoryItems, setInventoryItems] = useMockData<InventoryItem>(MOCK_INVENTORY_ITEMS_DATA_KEY, initialInventoryItems);
    const [accountingEntries, setAccountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, []);

    const [isItemModalOpen, setIsItemModalOpen] = useState(false);
    const [currentItem, setCurrentItem] = useState<InventoryItem | null>(null);
    
    const [activeTab, setActiveTab] = useState<InventoryCategoryType>(InventoryCategoryType.RESTAURANTE);
    const [searchTerm, setSearchTerm] = useState('');

    const inventoryKPIs = useMemo(() => {
        const totalItems = inventoryItems.length;
        const lowStockItems = inventoryItems.filter(item => item.lowStockThreshold !== undefined && item.quantity < item.lowStockThreshold).length;
        
        const itemsByCategory = inventoryItems.reduce((acc, item) => {
            acc[item.category] = (acc[item.category] || 0) + 1;
            return acc;
        }, {} as Record<InventoryCategoryType, number>);

        return [
            { label: 'Total Artículos', value: totalItems, icon: <Icon name="clipboardList" className="w-6 h-6 text-primary" /> },
            { label: 'Bajos en Stock', value: lowStockItems, icon: <Icon name="warning" className="w-6 h-6 text-danger" /> },
            { label: `Restaurante (${itemsByCategory[InventoryCategoryType.RESTAURANTE] || 0})`, value: '', icon: <Icon name="utensils" className="w-5 h-5 text-info"/> },
            { label: `Cabañas (${itemsByCategory[InventoryCategoryType.CABANAS_HABITACIONES] || 0})`, value: '', icon: <Icon name="building" className="w-5 h-5 text-accent"/>},
        ];
    }, [inventoryItems]);

    const handleOpenItemModal = (item: InventoryItem | null = null) => {
        setCurrentItem(item);
        setIsItemModalOpen(true);
    };

    const handleCloseItemModal = () => {
        setIsItemModalOpen(false);
        setCurrentItem(null);
    };

    const handleSaveItem = (data: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'> & { id?: string; batchPurchaseCost?: number }) => {
        const { batchPurchaseCost, ...itemData } = data; 
        const now = new Date().toISOString();
        let savedItem: InventoryItem;

        if (itemData.id) { 
            savedItem = { ...inventoryItems.find(i => i.id === itemData.id)!, ...itemData, updatedAt: now };
            setInventoryItems(prev => prev.map(item => item.id === itemData.id ? savedItem : item));
        } else { 
            savedItem = { ...itemData, id: `inv-${Date.now()}`, createdAt: now, updatedAt: now };
            setInventoryItems(prev => [...prev, savedItem]);
        }

        if (batchPurchaseCost && batchPurchaseCost > 0 && !itemData.id) { // Only for new items if batchPurchaseCost is provided
            const accountingEntry: AccountingEntry = {
                id: `acc-inv-${Date.now()}`,
                date: now.split('T')[0],
                type: AccountingEntryType.EXPENSE,
                category: AccountingExpenseCategory.INVENTORY_PURCHASE,
                description: `Compra de inventario (lote): ${savedItem.name} (x${savedItem.quantity} ${savedItem.unit})`,
                amount: batchPurchaseCost,
                createdAt: now,
                inventoryItemId: savedItem.id,
            };
            setAccountingEntries(prev => [...prev, accountingEntry]);
        }
        handleCloseItemModal();
    };

    const handleDeleteItem = (id: string) => {
        if (window.confirm('¿Eliminar este artículo del inventario?')) {
            setInventoryItems(prev => prev.filter(item => item.id !== id));
        }
    };

    const filteredAndSortedItems = useMemo(() => {
        return inventoryItems
            .filter(item => item.category === activeTab && item.name.toLowerCase().includes(searchTerm.toLowerCase()))
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [inventoryItems, activeTab, searchTerm]);

    const itemColumns: TableColumn<InventoryItem>[] = [
        { header: 'Nombre Artículo', accessor: 'name', className: 'font-semibold' },
        { header: 'Cantidad', accessor: 'quantity', className: 'text-center' },
        { header: 'Unidad', accessor: 'unit' },
        { 
            header: 'Precio Compra', 
            accessor: item => item.purchasePrice !== undefined ? `$${item.purchasePrice.toFixed(2)}` : <span className="text-muted-foreground italic">N/A</span>,
            className: 'text-right'
        },
        { 
            header: 'Stock Bajo (Umbral)', 
            accessor: item => item.lowStockThreshold !== undefined ? 
                <span className={item.quantity < item.lowStockThreshold ? 'text-danger font-bold' : ''}>
                    {item.quantity < item.lowStockThreshold ? `¡BAJO! (${item.lowStockThreshold})` : `${item.lowStockThreshold}`}
                </span> 
                : <span className="text-muted-foreground italic">N/A</span>,
            className: 'text-center'
        },
        { header: 'Proveedor', accessor: item => item.supplierInfo || <span className="text-muted-foreground italic">N/A</span>, className: "truncate max-w-xs" },
        { header: 'Últ. Surtido', accessor: item => item.lastRestockDate ? new Date(item.lastRestockDate).toLocaleDateString() : <span className="text-muted-foreground italic">N/A</span> },
        { header: 'Notas', accessor: item => item.notes || <span className="text-muted-foreground italic">N/A</span>, className: "truncate max-w-xs" },
        {
            header: 'Acciones',
            accessor: (item) => (
                <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenItemModal(item)} title="Editar"><Icon name="edit" className="w-4 h-4"/></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteItem(item.id)} className="text-danger" title="Eliminar"><Icon name="trash" className="w-4 h-4"/></Button>
                </div>
            ),
        },
    ];

    return (
        <div>
            <PageTitle title="Gestión de Inventarios" />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                {inventoryKPIs.map(kpi => <KPICard key={kpi.label} kpi={kpi}/>)}
            </div>

            <Card>
                <div className="p-4">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
                        <div className="flex border-b border-border-color">
                            {INVENTORY_CATEGORY_OPTIONS.map(opt => (
                                <button
                                    key={opt.value}
                                    onClick={() => setActiveTab(opt.value as InventoryCategoryType)}
                                    className={`px-4 py-2.5 text-sm font-medium focus:outline-none transition-colors duration-150
                                        ${activeTab === opt.value 
                                            ? 'border-b-2 border-primary text-primary' 
                                            : 'text-muted-foreground hover:text-foreground'}`}
                                >
                                    {opt.label}
                                </button>
                            ))}
                        </div>
                        <Button onClick={() => handleOpenItemModal(null)} leftIcon={<Icon name="plus" />} size="sm">
                            Añadir Artículo
                        </Button>
                    </div>

                    <TextInput 
                        label={`Buscar en ${activeTab.replace('_', ' ')}...`}
                        placeholder="Nombre del artículo..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        containerClassName="mb-4"
                    />
                    
                    <Table columns={itemColumns} data={filteredAndSortedItems} emptyMessage="No hay artículos en esta categoría de inventario."/>
                </div>
            </Card>

            {isItemModalOpen && (
                <Modal 
                    isOpen={isItemModalOpen} 
                    onClose={handleCloseItemModal} 
                    title={currentItem ? 'Editar Artículo de Inventario' : 'Nuevo Artículo de Inventario'}
                    size="lg"
                >
                    <InventoryItemForm
                        initialData={currentItem}
                        onSave={handleSaveItem}
                        onCancel={handleCloseItemModal}
                        categoryOptions={INVENTORY_CATEGORY_OPTIONS}
                        currentCategory={activeTab} 
                    />
                </Modal>
            )}
        </div>
    );
};

export default InventoryPage;

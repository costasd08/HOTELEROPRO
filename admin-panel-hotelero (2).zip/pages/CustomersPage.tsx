import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Customer, Reservation, ReservationStatus, AppSettings, GuestFeedback, EnrichedGuestFeedback, Employee, FeedbackType, FeedbackSource, FeedbackStatus } from '../../types'; // Added GuestFeedback, EnrichedGuestFeedback, Employee, and Feedback enums
import PageTitle from '../../components/common/PageTitle';
import Button from '../../components/common/Button';
import Icon from '../../components/common/Icon';
import Modal from '../../components/common/Modal';
import Table from '../../components/common/Table';
import CustomerForm from '../../components/customers/CustomerForm';
import FeedbackDetailModal from '../../components/feedback/FeedbackDetailModal';
import CustomerDetailModal from '../../components/customers/CustomerDetailModal'; // New Import for Customer Detail View
import TextInput from '../../components/common/TextInput';
import Card from '../../components/common/Card';
import KPICard from '../../components/dashboard/KPICard';
import useMockData from '../../hooks/useMockData';
import { MOCK_CUSTOMERS_DATA_KEY, MOCK_RESERVATIONS_DATA_KEY, MOCK_GUEST_FEEDBACK_DATA_KEY, MOCK_EMPLOYEES_DATA_KEY, APP_SETTINGS_KEY, APP_NAME, FEEDBACK_STATUS_OPTIONS, FEEDBACK_SOURCE_OPTIONS, FEEDBACK_TYPE_OPTIONS } from '../../constants'; // Added MOCK_GUEST_FEEDBACK_DATA_KEY, MOCK_EMPLOYEES_DATA_KEY
import { generateSmartCustomerNotes } from '../../services/geminiService';
import { useLocation, useNavigate } from 'react-router-dom';

const initialCustomers: Customer[] = [
    { id: 'cust1', fullName: 'Ana Pérez', phone: '555-1234', email: 'ana@example.com', origin: 'Referido', notes: 'Prefiere habitaciones tranquilas. Celebró aniversario en mayo.', createdAt: new Date(Date.now() - 10*24*60*60*1000).toISOString() },
    { id: 'cust2', fullName: 'Luis García', phone: '555-5678', createdAt: new Date(Date.now() - 5*24*60*60*1000).toISOString() },
    { id: 'cust3', fullName: 'Maria Rodríguez', phone: '555-8765', email: 'maria@example.com', origin: 'Online', createdAt: new Date(Date.now() - 2*24*60*60*1000).toISOString()},
];
const initialReservations: Reservation[] = [
    { id: 'res-cust1-1', customerId: 'cust1', propertyId: 'prop1', checkInDate: '2024-05-01', checkOutDate: '2024-05-05', numberOfGuests: 2, status: ReservationStatus.FULLY_PAID, totalPrice: 600, balanceDue: 0, notes: "Aniversario", createdAt: new Date().toISOString() },
    { id: 'res-cust1-2', customerId: 'cust1', propertyId: 'prop2', checkInDate: '2024-06-10', checkOutDate: '2024-06-12', numberOfGuests: 1, status: ReservationStatus.FULLY_PAID, totalPrice: 400, balanceDue: 0, createdAt: new Date().toISOString() },
    { id: 'res-cust3-1', customerId: 'cust3', propertyId: 'prop1', checkInDate: new Date().toISOString().split('T')[0], checkOutDate: new Date(Date.now() + 3*24*60*60*1000).toISOString().split('T')[0], numberOfGuests: 2, status: ReservationStatus.PENDING, totalPrice: 450, balanceDue: 450, createdAt: new Date().toISOString() },
];
const initialFeedback: GuestFeedback[] = [
    { id: 'fb-cust1', dateReceived: '2024-05-03', customerId: 'cust1', reservationId: 'res-cust1-1', type: FeedbackType.ELOGIO, source: FeedbackSource.VERBAL_PERSONAL, details: 'Excelente servicio durante el aniversario.', status: FeedbackStatus.CERRADO, createdAt: new Date().toISOString() }
];
const initialEmployees: Employee[] = [];


const CustomersPage: React.FC = () => {
  const [customers, setCustomers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, initialCustomers);
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, initialReservations);
  const [feedbackEntries] = useMockData<GuestFeedback>(MOCK_GUEST_FEEDBACK_DATA_KEY, initialFeedback);
  const [employees] = useMockData<Employee>(MOCK_EMPLOYEES_DATA_KEY, initialEmployees);

  const [isFormModalOpen, setIsFormModalOpen] = useState(false); // For Create/Edit
  const [isDetailViewModalOpen, setIsDetailViewModalOpen] = useState(false); // For View Details
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [smartNotesLoading, setSmartNotesLoading] = useState(false);
  const [smartNotesResult, setSmartNotesResult] = useState('');
  const [appSettings, setAppSettings] = useState<AppSettings>({
    appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
    defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomHeaderText: '',
    reportCustomFooterText: '', reservationPolicies: '', cancellationPolicies: '',
    generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
    weatherWidgetHref: '', googleCalendarConnected: false, googleCalendarId: '',
    defaultKitchenOverheadRate: 0.1, defaultAdminSalesOverheadRate: 0.15
  });

  const [isFeedbackDetailModalOpen, setIsFeedbackDetailModalOpen] = useState(false);
  const [selectedFeedbackForDetail, setSelectedFeedbackForDetail] = useState<EnrichedGuestFeedback | null>(null);


  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
    if (storedSettings) {
      setAppSettings(JSON.parse(storedSettings));
    }

    if (location.state?.openNewCustomerModal) {
      handleOpenFormModal(null); // Open create/edit form modal for new customer
      navigate(location.pathname, { replace: true, state: {} }); 
    }
  }, [location.state, navigate]);

  const handleOpenFormModal = (customer: Customer | null = null) => {
    setCurrentCustomer(customer);
    setSmartNotesResult(''); 
    setIsFormModalOpen(true);
  };

  const handleCloseFormModal = () => {
    setIsFormModalOpen(false);
    setCurrentCustomer(null);
  };

  const handleOpenDetailViewModal = (customer: Customer) => {
    setCurrentCustomer(customer);
    setIsDetailViewModalOpen(true);
  };

  const handleCloseDetailViewModal = () => {
    setIsDetailViewModalOpen(false);
    setCurrentCustomer(null);
  };

  const handleSaveCustomer = (customerData: Omit<Customer, 'id' | 'createdAt'> & { id?: string }) => {
    if (currentCustomer && currentCustomer.id) { 
      setCustomers(prev => prev.map(c => c.id === currentCustomer.id ? { ...currentCustomer, ...customerData, notes: customerData.notes || currentCustomer.notes } : c));
    } else { 
      setCustomers(prev => [...prev, { ...customerData, id: `cust-${Date.now()}`, createdAt: new Date().toISOString() }]);
    }
    handleCloseFormModal();
  };

  const handleDeleteCustomer = (id: string) => {
    if (window.confirm('¿Está seguro de que desea eliminar este cliente? Esto podría afectar sus reservas asociadas.')) {
      setCustomers(prev => prev.filter(c => c.id !== id));
    }
  };
  
  const handleGenerateSmartNotes = useCallback(async (customer: Customer | null) => {
    if (!customer) return;
    setSmartNotesLoading(true);
    setSmartNotesResult('');
    try {
      const customerReservations = reservations.filter(r => r.customerId === customer.id && r.status !== ReservationStatus.CANCELLED)
        .map(({ propertyId, checkInDate, checkOutDate, numberOfGuests, totalPrice, notes: reservationNotes }) => 
            ({ propertyId, checkInDate, checkOutDate, numberOfGuests, totalPrice, notes: reservationNotes }));
      
      const notes = await generateSmartCustomerNotes({
          customerId: customer.id,
          bookingHistory: customerReservations,
          customerPreferences: customer.notes
      });
      setSmartNotesResult(notes);
    } catch (error) {
      console.error("Error generating smart notes:", error);
      let errorMessage = "Error al generar notas. Verifique la consola y la clave API.";
      if (error instanceof Error && error.message.includes("API_KEY")) {
        errorMessage = "Error: Clave API de Gemini no configurada o inválida.";
      } else if (error instanceof Error) {
        errorMessage = `Error de IA: ${error.message}`;
      }
      setSmartNotesResult(errorMessage);
    } finally {
      setSmartNotesLoading(false);
    }
  }, [reservations]);

  const handleShareWhatsAppToCustomer = (customer: Customer) => {
    const customerPhone = customer.phone?.replace(/\D/g, '');
    if (!customerPhone) {
      alert('El número de teléfono del cliente no es válido o no está disponible.');
      return;
    }
    const message = encodeURIComponent(`Hola ${customer.fullName}, le contactamos de ${appSettings.appName || 'nuestro hotel'}. ¿En qué podemos ayudarle hoy?`);
    const whatsappUrl = `https://wa.me/${customerPhone}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleOpenFeedbackDetailModalGlobal = (feedbackId: string) => { // Renamed to avoid conflict if used elsewhere
    const feedback = feedbackEntries.find(f => f.id === feedbackId);
    if (feedback) {
        const customer = feedback.customerId ? customers.find(c => c.id === feedback.customerId) : undefined;
        const reservation = feedback.reservationId ? reservations.find(r => r.id === feedback.reservationId) : undefined;
        const employeeHandling = feedback.employeeHandlingId ? employees.find(e => e.id === feedback.employeeHandlingId) : undefined;
        
        setSelectedFeedbackForDetail({
            ...feedback,
            customer,
            reservation,
            employeeHandling
        });
        setIsFeedbackDetailModalOpen(true);
    }
  };
  const handleCloseFeedbackDetailModal = () => {
    setIsFeedbackDetailModalOpen(false);
    setSelectedFeedbackForDetail(null);
  };


  const filteredCustomers = useMemo(() => {
    return customers.filter(customer =>
      customer.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm) ||
      (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase()))
    ).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [customers, searchTerm]);
  
  const summaryStats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const activeTodayCustomerIds = new Set(
        reservations
        .filter(r => r.checkInDate <= today && r.checkOutDate > today && r.status !== ReservationStatus.CANCELLED)
        .map(r => r.customerId)
    );
    return [
        { label: 'Total Clientes', value: customers.length, icon: <Icon name="users" className="w-6 h-6 text-primary"/> },
        { label: 'Clientes Activos Hoy', value: activeTodayCustomerIds.size, icon: <Icon name="sun" className="w-6 h-6 text-warning"/> },
        { label: 'Nuevos Clientes (Mes)', value: customers.filter(c => new Date(c.createdAt).getMonth() === currentMonth && new Date(c.createdAt).getFullYear() === currentYear).length, icon: <Icon name="star" className="w-6 h-6 text-accent"/> },
    ];
  }, [customers, reservations]);

  const columns: { header: string; accessor: keyof Customer | ((item: Customer) => React.ReactNode); className?: string }[] = [
    { header: 'Nombre Completo', accessor: 'fullName', className: 'font-semibold' },
    { header: 'Teléfono', accessor: 'phone' },
    { header: 'Email', accessor: (item) => item.email || <span className="text-muted-foreground italic">N/A</span> },
    { header: 'Origen', accessor: (item) => item.origin || <span className="text-muted-foreground italic">N/A</span> },
    { header: 'Fecha Registro', accessor: (item) => new Date(item.createdAt).toLocaleDateString() },
    {
      header: 'Acciones',
      accessor: (item) => (
        <div className="flex space-x-1">
           <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleOpenDetailViewModal(item); }} title="Ver Detalles">
            <Icon name="eye" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleOpenFormModal(item); }} title="Editar Cliente">
            <Icon name="edit" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleShareWhatsAppToCustomer(item); }} title="Contactar por WhatsApp" className="text-green-500 hover:text-green-600">
            <Icon name="whatsapp" className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleDeleteCustomer(item.id); }} className="text-danger hover:text-danger/80" title="Eliminar">
            <Icon name="trash" className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageTitle title="Gestión de Clientes" actionButton={
        <Button onClick={() => handleOpenFormModal()} leftIcon={<Icon name="plus" className="w-5 h-5"/>}>
          Nuevo Cliente
        </Button>
      }/>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {summaryStats.map(stat => (
            <KPICard key={stat.label} kpi={stat} />
        ))}
      </div>

      <Card className="mb-6">
        <div className="p-4">
          <TextInput
            label="Buscar Cliente (Nombre, Teléfono, Email)"
            placeholder="Escriba para buscar..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            containerClassName="mb-0"
          />
        </div>
      </Card>
      
      <Table columns={columns} data={filteredCustomers} onRowClick={(item) => handleOpenDetailViewModal(item)} /> {/* Default row click to Detail View */}

      {isFormModalOpen && ( // Modal for Create/Edit
        <Modal
          isOpen={isFormModalOpen}
          onClose={handleCloseFormModal}
          title={currentCustomer ? `Editar Cliente: ${currentCustomer.fullName}` : 'Crear Nuevo Cliente'}
          size="xl"
        >
          <CustomerForm
            initialData={currentCustomer}
            onSave={handleSaveCustomer}
            onCancel={handleCloseFormModal}
            bookingHistory={currentCustomer ? reservations.filter(r => r.customerId === currentCustomer.id && r.status !== ReservationStatus.CANCELLED) : []}
            feedbackHistory={currentCustomer ? feedbackEntries.filter(fb => fb.customerId === currentCustomer.id) : []}
            onGenerateSmartNotes={() => handleGenerateSmartNotes(currentCustomer)}
            smartNotes={smartNotesResult}
            smartNotesLoading={smartNotesLoading}
          />
        </Modal>
      )}
      
      {isDetailViewModalOpen && currentCustomer && ( // Modal for View Details
        <CustomerDetailModal
          isOpen={isDetailViewModalOpen}
          onClose={handleCloseDetailViewModal}
          customer={currentCustomer}
          bookingHistory={reservations.filter(r => r.customerId === currentCustomer.id && r.status !== ReservationStatus.CANCELLED)}
          feedbackHistory={feedbackEntries.filter(fb => fb.customerId === currentCustomer.id)}
        />
      )}


      {isFeedbackDetailModalOpen && selectedFeedbackForDetail && ( // This modal remains for global feedback viewing if needed from other pages.
        <FeedbackDetailModal
          isOpen={isFeedbackDetailModalOpen}
          onClose={handleCloseFeedbackDetailModal}
          feedbackData={selectedFeedbackForDetail}
          appSettings={appSettings}
        />
      )}
    </div>
  );
};

export default CustomersPage;
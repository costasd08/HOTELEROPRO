
import React, { useState, useEffect } from 'react';
import { MaintenanceRequest, MaintenanceTaskStatus, MaintenanceUrgency, MaintenanceLocationType, Property, Employee } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Icon from '../common/Icon';
import { MAINTENANCE_TASK_STATUS_OPTIONS, MAINTENANCE_URGENCY_OPTIONS, MAINTENANCE_LOCATION_TYPE_OPTIONS } from '../../constants';

interface MaintenanceRequestFormProps {
  initialData: MaintenanceRequest | null;
  onSave: (data: MaintenanceRequest) => void;
  onCancel: () => void;
  properties: Property[]; // For location dropdown
  employees: Employee[]; // For assignedTo dropdown
}

const MaintenanceRequestForm: React.FC<MaintenanceRequestFormProps> = ({
  initialData,
  onSave,
  onCancel,
  properties,
  employees,
}) => {
  const [formData, setFormData] = useState<Partial<MaintenanceRequest>>(() => {
    const defaults: Partial<MaintenanceRequest> = {
      reportedDate: new Date().toISOString().split('T')[0],
      reportedBy: '',
      locationType: MaintenanceLocationType.PROPIEDAD_HABITACION,
      propertyId: '',
      locationName: '',
      issueDescription: '',
      urgency: MaintenanceUrgency.MEDIA,
      photoUrls: [],
      status: MaintenanceTaskStatus.REPORTADO,
      assignedToEmployeeId: '',
      estimatedCost: undefined,
      actualCost: undefined,
      completionDate: undefined,
      resolutionNotes: '',
      inventoryItemsUsedNotes: '',
    };
    return initialData ? { ...defaults, ...initialData } : defaults;
  });
  
  const [photoPreviews, setPhotoPreviews] = useState<string[]>(initialData?.photoUrls || []);

  useEffect(() => {
    // Reset locationName or propertyId when locationType changes
    setFormData(prev => ({
      ...prev,
      propertyId: prev.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION ? prev.propertyId : '',
      locationName: prev.locationType !== MaintenanceLocationType.PROPIEDAD_HABITACION ? prev.locationName : '',
    }));
  }, [formData.locationType]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: (name === 'estimatedCost' || name === 'actualCost')
        ? (value === '' ? undefined : parseFloat(value))
        : value,
    }));
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      const currentPhotoCount = photoPreviews.length;
      if (currentPhotoCount + filesArray.length > 5) {
          alert("Puede subir un máximo de 5 fotos.");
          return;
      }

      const newPreviews: string[] = [];
      const newPhotoDataUrls: string[] = [];

      filesArray.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newPreviews.push(reader.result as string);
          newPhotoDataUrls.push(reader.result as string);
          if (newPreviews.length === filesArray.length) {
            setPhotoPreviews(prev => [...prev, ...newPreviews].slice(0,5));
            setFormData(prevData => ({
              ...prevData,
              photoUrls: [...(prevData.photoUrls || []), ...newPhotoDataUrls].slice(0,5),
            }));
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };
  
  const handleRemovePhoto = (indexToRemove: number) => {
    setPhotoPreviews(prev => prev.filter((_, index) => index !== indexToRemove));
    setFormData(prevData => ({
        ...prevData,
        photoUrls: prevData.photoUrls?.filter((_,index) => index !== indexToRemove)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.reportedDate || !formData.issueDescription || !formData.locationType || !formData.urgency || !formData.status) {
      alert('Por favor, complete todos los campos obligatorios: Fecha Reporte, Descripción, Tipo Ubicación, Urgencia y Estado.');
      return;
    }
    if (formData.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION && !formData.propertyId) {
      alert('Por favor, seleccione una propiedad.');
      return;
    }
    if (formData.locationType !== MaintenanceLocationType.PROPIEDAD_HABITACION && !formData.locationName) {
      alert('Por favor, ingrese el nombre del área/equipo.');
      return;
    }
    if (formData.status === MaintenanceTaskStatus.COMPLETADO && !formData.completionDate) {
        alert('Si la tarea está completada, por favor ingrese la fecha de finalización.');
        return;
    }

    onSave(formData as MaintenanceRequest); // Cast because we've filled defaults
  };

  const propertyOptions = [{ value: '', label: 'Seleccione propiedad...' }, ...properties.map(p => ({ value: p.id, label: p.name }))];
  const employeeOptions = [{ value: '', label: 'Sin asignar' }, ...employees.map(e => ({ value: e.id, label: e.fullName }))];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha del Reporte*" name="reportedDate" value={formData.reportedDate} onChange={handleChange} required />
        <TextInput label="Reportado Por (Nombre/Rol)*" name="reportedBy" value={formData.reportedBy} onChange={handleChange} required />
      </div>

      <SelectInput label="Tipo de Ubicación*" name="locationType" value={formData.locationType} onChange={handleChange} options={MAINTENANCE_LOCATION_TYPE_OPTIONS} required />

      {formData.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION ? (
        <SelectInput label="Propiedad/Habitación Específica*" name="propertyId" value={formData.propertyId} onChange={handleChange} options={propertyOptions} required={formData.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION} />
      ) : (
        <TextInput label="Nombre Área/Equipo Específico*" name="locationName" value={formData.locationName} onChange={handleChange} required={true} placeholder="Ej: Cocina, Lobby, Bomba Piscina" />
      )}

      <TextareaInput label="Descripción de la Falla/Incidencia*" name="issueDescription" value={formData.issueDescription} onChange={handleChange} rows={3} required />
      
      <div>
        <label className="block text-sm font-medium text-muted-foreground mb-1">Fotos (Máx. 5, Opcional)</label>
        <input type="file" multiple accept="image/*" onChange={handlePhotoChange} className="block w-full text-sm text-muted-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer"/>
        {photoPreviews.length > 0 && (
          <div className="mt-2 grid grid-cols-3 sm:grid-cols-5 gap-2">
            {photoPreviews.map((previewUrl, index) => (
              <div key={index} className="relative">
                <img src={previewUrl} alt={`Preview ${index}`} className="w-full h-24 object-cover rounded shadow-md"/>
                <Button type="button" variant="danger" size="sm" onClick={() => handleRemovePhoto(index)} className="absolute top-1 right-1 p-0.5 leading-none h-5 w-5" title="Quitar foto">
                    <Icon name="xMark" className="w-3 h-3"/>
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>


      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SelectInput label="Urgencia*" name="urgency" value={formData.urgency} onChange={handleChange} options={MAINTENANCE_URGENCY_OPTIONS} required />
        <SelectInput label="Estado de la Tarea*" name="status" value={formData.status} onChange={handleChange} options={MAINTENANCE_TASK_STATUS_OPTIONS} required />
      </div>

      <SelectInput label="Asignado A (Empleado)" name="assignedToEmployeeId" value={formData.assignedToEmployeeId} onChange={handleChange} options={employeeOptions} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TextInput label="Costo Estimado ($)" name="estimatedCost" type="number" value={formData.estimatedCost?.toString() || ''} onChange={handleChange} min="0" step="0.01" />
        <TextInput label="Costo Real ($)" name="actualCost" type="number" value={formData.actualCost?.toString() || ''} onChange={handleChange} min="0" step="0.01" helperText="Si se completa, generará asiento contable."/>
      </div>
      
      <TextareaInput label="Notas sobre Partes/Materiales Usados" name="inventoryItemsUsedNotes" value={formData.inventoryItemsUsedNotes} onChange={handleChange} rows={2} placeholder="Ej: 1 filtro de aire modelo X, 2m de cable..." />

      {formData.status === MaintenanceTaskStatus.COMPLETADO && (
          <DateInput label="Fecha de Finalización*" name="completionDate" value={formData.completionDate} onChange={handleChange} required={formData.status === MaintenanceTaskStatus.COMPLETADO}/>
      )}
      <TextareaInput label="Notas de Resolución/Observaciones" name="resolutionNotes" value={formData.resolutionNotes} onChange={handleChange} rows={3} />


      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData?.id ? 'Actualizar Solicitud' : 'Crear Solicitud'}</Button>
      </div>
    </form>
  );
};

export default MaintenanceRequestForm;

import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { MaintenanceRequest, Employee, Property, AppSettings, MaintenanceUrgency, MaintenanceTaskStatus, MaintenanceLocationType } from '../../types'; // Added MaintenanceLocationType
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';

interface ReportData {
  request: MaintenanceRequest;
  assignedEmployee?: Employee;
  property?: Property;
}

interface MaintenanceRequestReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  requestData: ReportData;
  appSettings: AppSettings;
}

const formatDate = (dateString: string | undefined): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString.includes('T') ? dateString : dateString + 'T00:00:00');
  return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
};

const MaintenanceRequestReportModal: React.FC<MaintenanceRequestReportModalProps> = ({
  isOpen,
  onClose,
  requestData,
  appSettings,
}) => {
  const reportContentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const { request, assignedEmployee, property } = requestData;

  const handleDownloadImage = async () => {
    if (!reportContentRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(reportContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        onclone: (document) => {
            const elementsToHide = document.querySelectorAll('.hide-on-capture');
            elementsToHide.forEach(el => (el as HTMLElement).style.display = 'none');
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `reporte_falla_${request.id.slice(-6)}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating report image:", error);
      alert("Hubo un error al generar la imagen del reporte.");
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShareWhatsApp = () => {
    if (!assignedEmployee || !assignedEmployee.contactInfo) {
      alert("No hay un empleado asignado o su información de contacto no está completa para enviar por WhatsApp.");
      return;
    }

    // Basic phone number extraction: remove non-digits, then check length.
    // This is a simple approach and might need adjustment for international numbers or complex formats.
    let phone = assignedEmployee.contactInfo.replace(/\D/g, '');
    if (phone.startsWith('521') && phone.length === 12) { // Common for MX mobile if '1' is included after country code
        phone = '52' + phone.substring(3);
    } else if (phone.startsWith('52') && phone.length === 12 && phone.charAt(2) !== '1') {
        // No change if it's already 52 + 10 digits
    } else if (phone.length === 10) { // Assume local MX, add country code
        phone = `52${phone}`;
    }
    // Add more robust validation/formatting if needed

    if (!/^\d{10,15}$/.test(phone)) { // Basic check for 10-15 digits
        alert(`El número de contacto "${assignedEmployee.contactInfo}" no parece ser un número de teléfono válido para WhatsApp.`);
        return;
    }


    let message = `*Reporte de Falla/Incidencia - ${appSettings.appName}*\n\n`;
    message += `Estimado/a ${assignedEmployee.fullName.split(' ')[0]},\n\n`;
    message += `Se le ha asignado la siguiente solicitud de mantenimiento:\n`;
    message += `ID Solicitud: *${request.id.slice(-6)}*\n`;
    message += `Fecha Reporte: ${formatDate(request.reportedDate)}\n`;
    message += `Ubicación: ${request.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION ? (property?.name || request.propertyId) : request.locationName}\n`;
    message += `Descripción: ${request.issueDescription}\n`;
    message += `Urgencia: *${request.urgency}*\n`;
    message += `Estado Actual: ${request.status}\n\n`;
    message += `Por favor, atienda esta solicitud a la brevedad.\n`;
    if (appSettings.phone) message += `Contacto Administración: ${appSettings.phone}\n`;

    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };
  
  const getUrgencyColorClass = (urgency: MaintenanceUrgency) => {
    if (urgency === MaintenanceUrgency.CRITICA) return 'text-red-700 border-red-700';
    if (urgency === MaintenanceUrgency.ALTA) return 'text-danger border-danger';
    if (urgency === MaintenanceUrgency.MEDIA) return 'text-warning border-warning';
    return 'text-info border-info';
  };

  const getStatusColorClass = (status: MaintenanceTaskStatus) => {
    if (status === MaintenanceTaskStatus.COMPLETADO) return 'text-success border-success';
    if (status === MaintenanceTaskStatus.CANCELADO) return 'text-muted-foreground border-muted-foreground';
    if (status === MaintenanceTaskStatus.EN_PROGRESO) return 'text-blue-600 border-blue-600';
    if (status === MaintenanceTaskStatus.EN_ESPERA) return 'text-orange-600 border-orange-600';
    return 'text-info border-info';
  };


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Ficha de Reporte: Solicitud #${request.id.slice(-6)}`}
      size="lg"
      footer={
        <div className="flex justify-between w-full items-center hide-on-capture">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cerrar
          </Button>
          <div className="flex space-x-2">
            <Button
                variant="secondary"
                size="sm"
                onClick={handleShareWhatsApp}
                leftIcon={<Icon name="whatsapp" className="w-4 h-4 text-green-500"/>}
                disabled={!assignedEmployee || !assignedEmployee.contactInfo}
                title={!assignedEmployee || !assignedEmployee.contactInfo ? "Empleado no asignado o sin contacto" : "Compartir por WhatsApp"}
            >
                Compartir
            </Button>
            <Button
                variant="primary"
                size="sm"
                onClick={handleDownloadImage}
                leftIcon={<Icon name="image" className="w-4 h-4" />}
                isLoading={isDownloading}
                disabled={isDownloading}
            >
                {isDownloading ? 'Descargando...' : 'Descargar Imagen'}
            </Button>
          </div>
        </div>
      }
    >
      <div ref={reportContentRef} className="printable-report-area bg-surface p-4 sm:p-6 text-sm">
        <header className="text-center mb-4 border-b-2 border-primary pb-3">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-16 mx-auto mb-2 object-contain" />
          )}
          <h1 className="text-xl font-bold text-primary">{appSettings.appName}</h1>
          <p className="text-md font-semibold text-foreground">FICHA DE REPORTE DE FALLA / INCIDENCIA</p>
          {appSettings.responsiblePerson && (
            <p className="text-xs text-muted-foreground mt-1">Atendido por: {appSettings.responsiblePerson}</p>
          )}
          <p className="text-xs text-muted-foreground">Ficha Generada: {new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
        </header>

        <section className="mb-3 space-y-1">
            <div className="grid grid-cols-2 gap-x-4">
                <p><strong>ID Solicitud:</strong> <span className="font-mono">{request.id.slice(-6)}</span></p>
                <p><strong>Fecha Reporte:</strong> {formatDate(request.reportedDate)}</p>
                <p><strong>Reportado Por:</strong> {request.reportedBy}</p>
                 <p><strong>Urgencia:</strong> <span className={`font-bold px-1 border rounded-sm text-xs ${getUrgencyColorClass(request.urgency)}`}>{request.urgency}</span></p>
                <p><strong>Estado Actual:</strong> <span className={`font-bold px-1 border rounded-sm text-xs ${getStatusColorClass(request.status)}`}>{request.status}</span></p>
                 <p><strong>Asignado A:</strong> {assignedEmployee?.fullName || 'No asignado'}</p>
            </div>
        </section>
        
        <section className="mb-3 p-2 border border-border-color rounded-md bg-background">
            <h3 className="font-semibold text-muted-foreground mb-0.5">Ubicación e Incidencia:</h3>
            <p><strong>Tipo:</strong> {request.locationType}</p>
            <p><strong>Específica:</strong> {request.locationType === MaintenanceLocationType.PROPIEDAD_HABITACION ? (property?.name || request.propertyId) : request.locationName}</p>
            <p className="mt-1"><strong>Descripción de la Falla:</strong></p>
            <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50">{request.issueDescription}</p>
        </section>

        {(request.status === MaintenanceTaskStatus.COMPLETADO || request.actualCost || request.resolutionNotes) && (
            <section className="mb-3 p-2 border border-border-color rounded-md bg-background">
                <h3 className="font-semibold text-muted-foreground mb-0.5">Detalles de Resolución:</h3>
                {request.completionDate && <p><strong>Fecha Finalización:</strong> {formatDate(request.completionDate)}</p>}
                {request.actualCost !== undefined && <p><strong>Costo Real:</strong> ${request.actualCost.toFixed(2)}</p>}
                {request.resolutionNotes && <p className="mt-1"><strong>Notas de Resolución:</strong></p>}
                {request.resolutionNotes && <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50">{request.resolutionNotes}</p>}
                {request.inventoryItemsUsedNotes && <p className="mt-1"><strong>Materiales Usados:</strong></p>}
                {request.inventoryItemsUsedNotes && <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50">{request.inventoryItemsUsedNotes}</p>}
            </section>
        )}
         {request.estimatedCost !== undefined && request.status !== MaintenanceTaskStatus.COMPLETADO && (
            <p className="text-xs"><strong>Costo Estimado:</strong> ${request.estimatedCost.toFixed(2)}</p>
         )}


        {request.photoUrls && request.photoUrls.length > 0 && (
          <section className="mb-3">
            <h3 className="font-semibold text-muted-foreground mb-1">Fotos Adjuntas:</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {request.photoUrls.map((url, index) => (
                <img key={index} src={url} alt={`Foto ${index + 1}`} className="w-full h-28 object-cover rounded shadow-md border border-border-color" />
              ))}
            </div>
          </section>
        )}

        <footer className="text-center text-xs text-muted-foreground pt-3 mt-3 border-t border-border-color">
          <p>{appSettings.appName}</p>
          {appSettings.phone && <p>Tel: {appSettings.phone}</p>}
        </footer>
      </div>
      <style>{`
        @media print { 
          .hide-on-capture { display: none !important; } /* Also hide for print */
          body * { visibility: hidden; }
          .printable-report-area, .printable-report-area * { visibility: visible; }
          .printable-report-area { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 15px !important; font-size: 9pt; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>
    </Modal>
  );
};

export default MaintenanceRequestReportModal;
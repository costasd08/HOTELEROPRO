import React, { useState } from 'react';
import { EmployeeTransaction, EmployeeTransactionType } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import SelectInput from '../common/SelectInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import { EMPLOYEE_TRANSACTION_TYPE_OPTIONS } from '../../constants';

interface EmployeeTransactionFormProps {
  initialData: Omit<EmployeeTransaction, 'id' | 'createdAt' | 'employeeId' | 'accountingEntryId'> | null; // For new transaction, employeeId comes from parent
  onSave: (data: Omit<EmployeeTransaction, 'id' | 'createdAt' | 'employeeId' | 'accountingEntryId'> & { id?: string }) => void;
  onCancel: () => void;
  employeeName: string; // To display in the form title or header
}

const EmployeeTransactionForm: React.FC<EmployeeTransactionFormProps> = ({ 
    initialData, 
    onSave, 
    onCancel,
    employeeName 
}) => {
  const [formData, setFormData] = useState({
    date: initialData?.date || new Date().toISOString().split('T')[0],
    type: initialData?.type || EmployeeTransactionType.SALARY,
    description: initialData?.description || '',
    amount: initialData?.amount || 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ 
        ...prev, 
        [name]: name === 'amount' ? parseFloat(value) || 0 : value 
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.date || !formData.description || formData.amount <= 0) {
        alert("Fecha, descripción y monto (mayor a 0) son obligatorios para la transacción.");
        return;
    }
    onSave({ id: (initialData as EmployeeTransaction)?.id, ...formData }); // Pass ID if editing
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-sm text-muted-foreground mb-3">Registrando movimiento para: <strong>{employeeName}</strong></p>
      <DateInput
        label="Fecha de Transacción*"
        name="date"
        value={formData.date}
        onChange={handleChange}
        required
      />
      <SelectInput
        label="Tipo de Transacción*"
        name="type"
        value={formData.type}
        onChange={handleChange}
        options={EMPLOYEE_TRANSACTION_TYPE_OPTIONS}
        required
      />
      <TextareaInput
        label="Descripción*"
        name="description"
        value={formData.description}
        onChange={handleChange}
        rows={3}
        required
      />
      <TextInput
        label="Monto ($)*"
        name="amount"
        type="number"
        value={formData.amount.toString()}
        onChange={handleChange}
        min="0.01"
        step="0.01"
        required
      />
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {(initialData && (initialData as EmployeeTransaction).id) ? 'Actualizar Movimiento' : 'Crear Movimiento'}
        </Button>
      </div>
    </form>
  );
};

export default EmployeeTransactionForm;
import React, { useState } from 'react';
import { Employee } from '../../types';
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import DateInput from '../common/DateInput';
import SelectInput from '../common/SelectInput'; // For isActive status

interface EmployeeFormProps {
  initialData: Employee | null;
  onSave: (data: Omit<Employee, 'id' | 'createdAt'> & { id?: string }) => void;
  onCancel: () => void;
}

const EmployeeForm: React.FC<EmployeeFormProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    fullName: initialData?.fullName || '',
    position: initialData?.position || '',
    hireDate: initialData?.hireDate || new Date().toISOString().split('T')[0],
    baseSalary: initialData?.baseSalary || 0,
    contactInfo: initialData?.contactInfo || '',
    bankAccount: initialData?.bankAccount || '',
    notes: initialData?.notes || '',
    isActive: initialData?.isActive !== undefined ? initialData.isActive : true,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ 
            ...prev, 
            [name]: name === 'baseSalary' ? parseFloat(value) || 0 : value 
        }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.position || !formData.hireDate || formData.baseSalary < 0) {
        alert("Nombre, Puesto, Fecha de Contratación y Salario Base (no negativo) son obligatorios.");
        return;
    }
    onSave({ id: initialData?.id, ...formData });
  };
  
  const statusOptions = [
      {value: 'true', label: 'Activo'},
      {value: 'false', label: 'Inactivo'}
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TextInput label="Nombre Completo*" name="fullName" value={formData.fullName} onChange={handleChange} required />
        <TextInput label="Puesto*" name="position" value={formData.position} onChange={handleChange} required />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Contratación*" name="hireDate" value={formData.hireDate} onChange={handleChange} required />
        <TextInput label="Salario Base ($)*" name="baseSalary" type="number" value={formData.baseSalary.toString()} onChange={handleChange} min="0" step="0.01" required />
      </div>
      <TextInput label="Información de Contacto (Tel/Email)*" name="contactInfo" value={formData.contactInfo} onChange={handleChange} required />
      <TextInput label="Cuenta Bancaria (Opcional)" name="bankAccount" value={formData.bankAccount} onChange={handleChange} />
      <TextareaInput label="Notas Adicionales" name="notes" value={formData.notes} onChange={handleChange} rows={3} />
      
      <div className="mb-4">
        <label htmlFor="isActive" className="block text-sm font-medium text-muted-foreground mb-1">Estado del Empleado*</label>
        <SelectInput
            id="isActive"
            name="isActive"
            label="" // Label is provided above
            containerClassName="mb-0" // Remove default bottom margin
            value={String(formData.isActive)} // Ensure value is string for SelectInput
            onChange={(e) => setFormData(prev => ({...prev, isActive: e.target.value === 'true'}))}
            options={statusOptions}
            required
        />
      </div>


      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {initialData ? 'Actualizar Empleado' : 'Crear Empleado'}
        </Button>
      </div>
    </form>
  );
};

export default EmployeeForm;
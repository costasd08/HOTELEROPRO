
import React from 'react';
import { ChartDataPoint } from '../../types';

interface SimpleBarDisplayProps {
  title: string;
  data: ChartDataPoint[];
}

const SimpleBarDisplay: React.FC<SimpleBarDisplayProps> = ({ title, data }) => {
  if (!data || data.length === 0) {
    return <p className="text-xs text-muted-foreground italic">{title}: No hay datos para mostrar.</p>;
  }

  const maxValue = Math.max(...data.map(d => d.value), 0);

  return (
    <div className="p-2 bg-surface/50 rounded">
      {title && <h6 className="text-xs font-medium text-muted-foreground mb-1">{title}</h6>}
      <div className="space-y-1">
        {data.map((item, index) => (
          <div key={item.id || index} className="flex items-center text-xs">
            <div className="w-1/3 truncate pr-1" title={item.label}>{item.label}</div>
            <div className="w-2/3 flex items-center">
              <div className="w-full bg-border-color rounded-sm h-3 mr-1">
                <div
                  className={`${item.color || 'bg-primary'} h-3 rounded-sm transition-all duration-300`}
                  style={{ width: maxValue > 0 ? `${(item.value / maxValue) * 100}%` : '0%' }}
                  title={`Valor: ${item.value.toLocaleString()}`}
                ></div>
              </div>
              <span className="w-12 text-right font-mono text-muted-foreground">{item.value.toLocaleString()}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SimpleBarDisplay;

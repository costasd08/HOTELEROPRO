import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { AnalyticsReportSummary, AppSettings, KPIData, ChartDataPoint, TrendData } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import SimpleBarDisplay from './SimpleBarDisplay';
import SimplePieDisplay from './SimplePieDisplay';
import SimpleTrendDisplay from './SimpleTrendDisplay';

interface AnalyticsReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: AnalyticsReportSummary;
  appSettings: AppSettings;
}

const formatDateForReport = (dateString: string | undefined): string => {
  if (!dateString) return 'N/A';
  const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
  if (isNaN(dateObj.getTime())) return "Fecha Inválida";
  return dateObj.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
};

const AnalyticsReportModal: React.FC<AnalyticsReportModalProps> = ({ isOpen, onClose, summary, appSettings }) => {
  const reportContentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handlePrint = () => window.print();

  const handleDownloadImage = async () => {
    if (!reportContentRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(reportContentRef.current, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `reporte_analitico_${summary.periodLabel.replace(/[:\s/]/g, '_')}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating report image:", error);
      alert("Hubo un error al generar la imagen del reporte.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Reporte Analítico Consolidado" size="xl" footer={
      <div className="flex justify-between items-center w-full">
        <Button variant="outline" size="sm" onClick={onClose}>Cerrar</Button>
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm" onClick={handleDownloadImage} leftIcon={<Icon name="image" />} isLoading={isDownloading} disabled={isDownloading}>
            {isDownloading ? 'Generando...' : 'Descargar Imagen'}
          </Button>
          <Button variant="primary" size="sm" onClick={handlePrint} leftIcon={<Icon name="download" />}>
            Imprimir/PDF
          </Button>
        </div>
      </div>
    }>
      <div ref={reportContentRef} className="printable-analytics-report bg-surface p-4 sm:p-6 text-sm">
        <header className="text-center mb-6 print:mb-4">
          {appSettings.logoUrl && <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-20 mx-auto mb-3 object-contain print:max-h-16"/>}
          {appSettings.reportCustomHeaderText && <p className="text-xs text-muted-foreground mb-1 print:text-xs whitespace-pre-line">{appSettings.reportCustomHeaderText}</p>}
          <h2 className="text-2xl font-bold text-primary print:text-xl">{appSettings.appName}</h2>
          <h3 className="text-xl font-semibold text-foreground print:text-lg">{summary.reportTitle}</h3>
          {appSettings.responsiblePerson && (
            <p className="text-sm text-muted-foreground mt-1 print:text-xs">Responsable: {appSettings.responsiblePerson}</p>
          )}
          <p className="text-sm text-muted-foreground print:text-xs">Periodo: {summary.periodLabel}</p>
          <p className="text-xs text-muted-foreground print:text-xs">Generado el: {formatDateForReport(summary.generatedAt)}</p>
        </header>

        {summary.overallSummary && (
          <section className="mb-4 p-3 bg-background rounded-md">
            <h4 className="font-semibold text-foreground mb-1">Resumen General del Periodo:</h4>
            <p className="text-xs text-muted-foreground whitespace-pre-line">{summary.overallSummary}</p>
          </section>
        )}

        {summary.sections.map((section, sectionIndex) => (
          <section key={sectionIndex} className="mb-6 p-3 border border-border-color rounded-lg">
            <h4 className="text-lg font-bold text-accent mb-3 print:text-base border-b border-accent/30 pb-1">{section.title}</h4>
            
            {section.kpis && section.kpis.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mb-3">
                {section.kpis.map((kpi, kpiIndex) => (
                  <div key={kpiIndex} className="p-2 bg-background rounded shadow-sm print:border print:border-border-color">
                    <p className="text-xs text-muted-foreground">{kpi.label}:</p>
                    <p className="text-md font-semibold text-foreground print:text-sm">{kpi.value}</p>
                  </div>
                ))}
              </div>
            )}

            {section.charts && section.charts.length > 0 && (
              <div className="space-y-4">
                {section.charts.map(chart => (
                  <div key={chart.id} className="p-2 bg-background/50 rounded">
                    <h5 className="text-sm font-semibold text-muted-foreground mb-1">{chart.title}</h5>
                    {chart.type === 'bar' && <SimpleBarDisplay title="" data={chart.data as ChartDataPoint[]} />}
                    {chart.type === 'pie' && <SimplePieDisplay title="" data={chart.data as ChartDataPoint[]} />}
                    {chart.type === 'trend' && <SimpleTrendDisplay title="" data={chart.data as TrendData[]} />}
                    {chart.type === 'list' && Array.isArray(chart.data) && (chart.data as ChartDataPoint[]).map(item => (
                         <p key={item.id || item.label} className="text-xs">{item.label}: {item.value}</p>
                    ))}
                    {chart.type === 'summary' && typeof chart.data === 'string' && (
                        <p className="text-xs text-muted-foreground italic">{chart.data}</p>
                    )}
                    {chart.notes && <p className="text-xs text-muted-foreground mt-1 italic">{chart.notes}</p>}
                  </div>
                ))}
              </div>
            )}
             {section.notes && <p className="text-xs text-muted-foreground mt-2 italic">{section.notes}</p>}
          </section>
        ))}

        <footer className="text-center text-xs text-muted-foreground pt-6 border-t border-border-color mt-6 print:mt-4 print:pt-2">
          {appSettings.reportCustomFooterText && <p className="mb-1 print:mb-1 whitespace-pre-line">{appSettings.reportCustomFooterText}</p>}
          Reporte generado por {appSettings.appName}.
        </footer>
      </div>
      <style>
        {`
          @media print {
            body * { visibility: hidden; }
            .printable-analytics-report, .printable-analytics-report * { visibility: visible; }
            .printable-analytics-report { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 15px !important; font-size: 9pt; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .modal-footer-print-hidden { display: none !important; } /* Hide modal footer from print */
            .bg-surface { background-color: #fff !important; }
            .bg-background { background-color: #f8f9fa !important; } /* Lightest gray for print background */
            .text-primary { color: hsl(215, 60%, 50%) !important; }
            .text-accent { color: hsl(210, 65%, 60%) !important; }
            .text-success { color: hsl(145, 63%, 42%) !important; }
            .text-danger { color: hsl(0, 72%, 51%) !important; }
            .text-foreground { color: hsl(220, 25%, 25%) !important; }
            .text-muted-foreground { color: hsl(220, 15%, 55%) !important; }
            .border-border-color { border-color: hsl(220, 20%, 85%) !important; }
            .border-primary { border-color: hsl(215, 60%, 50%) !important; }
            .border-accent\\/30 { border-color: hsla(210, 65%, 60%, 0.3) !important; }
            .shadow-sm, .shadow-md, .shadow-lg, .rounded-lg { box-shadow: none !important; border-radius: 0 !important; }
            .print\\:border { border-width: 1px !important; }
            .print\\:text-xs { font-size: 0.7rem !important; }
            .print\\:text-sm { font-size: 0.8rem !important; }
            .print\\:text-base { font-size: 0.9rem !important; }
            .print\\:text-lg { font-size: 1rem !important; }
            .print\\:text-xl { font-size: 1.2rem !important; }
            .print\\:max-h-16 { max-height: 3.5rem !important; }
            .whitespace-pre-line { white-space: pre-line !important; }
          }
        `}
      </style>
    </Modal>
  );
};

export default AnalyticsReportModal;
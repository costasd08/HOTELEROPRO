
import React from 'react';
import { ChartDataPoint } from '../../types';

interface SimplePieDisplayProps {
  title: string;
  data: ChartDataPoint[];
}

const SimplePieDisplay: React.FC<SimplePieDisplayProps> = ({ title, data }) => {
  if (!data || data.length === 0) {
    return <p className="text-xs text-muted-foreground italic">{title}: No hay datos para mostrar.</p>;
  }

  const totalValue = data.reduce((sum, item) => sum + item.value, 0);

  // Assign some default colors if not provided, good for up to ~5-7 categories
  const defaultColors = [
    'bg-primary', 'bg-accent', 'bg-success', 'bg-warning', 'bg-info', 
    'bg-emerald-500', 'bg-rose-500', 'bg-sky-500'
  ];

  return (
    <div className="p-2 bg-surface/50 rounded">
      {title && <h6 className="text-xs font-medium text-muted-foreground mb-2">{title}</h6>}
      <div className="space-y-1 text-xs">
        {data.map((item, index) => {
          const percentage = totalValue > 0 ? (item.value / totalValue) * 100 : 0;
          const colorClass = item.color || defaultColors[index % defaultColors.length];
          return (
            <div key={item.id || index} className="flex items-center">
              <div className={`w-2 h-2 rounded-full mr-1.5 ${colorClass}`}></div>
              <span className="w-2/3 truncate text-muted-foreground" title={item.label}>{item.label}:</span>
              <span className="w-1/3 text-right font-semibold text-foreground">
                {item.value.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})} ({percentage.toFixed(1)}%)
              </span>
            </div>
          );
        })}
      </div>
       {totalValue === 0 && data.length > 0 && (
        <p className="text-xs text-muted-foreground italic mt-1">Todos los valores son cero.</p>
      )}
    </div>
  );
};

export default SimplePieDisplay;

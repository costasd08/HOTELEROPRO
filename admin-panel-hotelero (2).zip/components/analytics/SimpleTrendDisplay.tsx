
import React from 'react';
import { TrendData } from '../../types';
import Icon from '../common/Icon'; // For trend arrows

interface SimpleTrendDisplayProps {
  title: string;
  data: TrendData[]; // Expects data sorted chronologically, oldest to newest
}

const SimpleTrendDisplay: React.FC<SimpleTrendDisplayProps> = ({ title, data }) => {
  if (!data || data.length === 0) {
    return <p className="text-xs text-muted-foreground italic">{title}: No hay datos de tendencia para mostrar.</p>;
  }

  return (
    <div className="p-2 bg-surface/50 rounded">
      {title && <h6 className="text-xs font-medium text-muted-foreground mb-1">{title}</h6>}
      <div className="space-y-1 text-xs">
        {data.map((item, index) => {
          let trendIcon = null;
          let trendColor = 'text-muted-foreground';
          // For income/expense trend, the 'period' might include (I) or (G)
          const isIncome = item.period.includes('(I)');
          const isExpense = item.period.includes('(G)');

          if (index > 0 && data[index-1]) { // Compare with previous item if available
            const prevItem = data[index-1];
            if (item.value > prevItem.value) {
              trendIcon = <Icon name="arrowRight" className="w-2.5 h-2.5 text-success transform -rotate-45" />;
              trendColor = isExpense ? 'text-danger' : 'text-success'; // Higher expense is bad
            } else if (item.value < prevItem.value) {
              trendIcon = <Icon name="arrowRight" className="w-2.5 h-2.5 text-danger transform rotate-45" />;
              trendColor = isExpense ? 'text-success' : 'text-danger'; // Lower expense is good
            }
          } else if (item.previousValue !== undefined) { // Compare with explicit previousValue
             if (item.value > item.previousValue) {
              trendIcon = <Icon name="arrowRight" className="w-2.5 h-2.5 text-success transform -rotate-45" />;
              trendColor = isExpense ? 'text-danger' : 'text-success';
            } else if (item.value < item.previousValue) {
              trendIcon = <Icon name="arrowRight" className="w-2.5 h-2.5 text-danger transform rotate-45" />;
              trendColor = isExpense ? 'text-success' : 'text-danger';
            }
          }
          
          return (
            <div key={item.period + index} className="flex justify-between items-center p-0.5 rounded">
              <span className="text-muted-foreground truncate w-2/5">{item.period}</span>
              <div className="flex items-center justify-end w-3/5">
                {trendIcon && <span className="mr-1">{trendIcon}</span>}
                <span className={`font-semibold ${trendColor} ${isIncome ? 'text-success' : ''} ${isExpense ? 'text-danger' : ''}`}>
                  {item.value.toLocaleString(undefined, {minimumFractionDigits: item.value % 1 !== 0 ? 1:0 , maximumFractionDigits: item.value % 1 !== 0 ? 1:0})}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SimpleTrendDisplay;

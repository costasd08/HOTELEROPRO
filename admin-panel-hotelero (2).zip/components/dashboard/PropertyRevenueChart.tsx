import React from 'react';
import { Property } from '../../types';

interface PropertyRevenueData {
  propertyId: string;
  propertyName: string;
  revenue: number;
  color: string; // Tailwind bg class
}

interface PropertyRevenueChartProps {
  data: PropertyRevenueData[];
}

const PropertyRevenueChart: React.FC<PropertyRevenueChartProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return <p className="text-muted-foreground italic">No hay datos de ingresos de propiedades para mostrar.</p>;
  }

  const maxRevenue = Math.max(...data.map(d => d.revenue), 0);

  return (
    <div className="space-y-4">
      {data.map(item => (
        <div key={item.propertyId} className="flex items-center group">
          <div className="w-1/3 sm:w-1/4 truncate text-sm text-muted-foreground pr-2" title={item.propertyName}>
            {item.propertyName}
          </div>
          <div className="w-2/3 sm:w-3/4 flex items-center">
            <div
              className={`h-6 rounded-r-md transition-all duration-500 ease-out group-hover:opacity-100 opacity-90 ${item.color || 'bg-primary'}`}
              style={{ width: maxRevenue > 0 ? `${(item.revenue / maxRevenue) * 100}%` : '0%' }}
              title={`$${item.revenue.toFixed(2)}`}
            >
            </div>
            <span className="ml-2 text-xs font-semibold text-foreground">${item.revenue.toFixed(2)}</span>
          </div>
        </div>
      ))}
      {maxRevenue === 0 && data.length > 0 && (
         <p className="text-muted-foreground text-sm italic">Todas las propiedades listadas tienen $0 de ingresos registrados.</p>
      )}
    </div>
  );
};

export default PropertyRevenueChart;
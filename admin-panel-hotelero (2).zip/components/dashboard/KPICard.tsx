import React from 'react';
import { KPIData } from '../../types';

interface KPICardProps {
  kpi: KPIData;
}

const KPICard: React.FC<KPICardProps> = ({ kpi }) => {
  const defaultBgColor = 'bg-surface'; // Use surface for card backgrounds
  const bgColor = kpi.bgColor || defaultBgColor;

  return (
    <div className={`${bgColor} p-6 rounded-xl shadow-lg flex items-center space-x-4`}>
      {kpi.icon && (
        <div className="p-3 bg-primary/10 rounded-full"> {/* primary with alpha for icon background */}
           {kpi.icon}
        </div>
      )}
      <div>
        <p className="text-sm text-muted-foreground">{kpi.label}</p>
        <p className="text-2xl font-semibold text-foreground">{kpi.value}</p>
      </div>
    </div>
  );
};

export default KPICard;
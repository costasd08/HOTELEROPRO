import React, { useState, useEffect, useCallback } from 'react';
import { Reservation, Customer, Property, ReservationStatus, AppSettings } from '../../types';
import Button from '../common/Button';
import SelectInput from '../common/SelectInput';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import Icon from '../common/Icon';
import { APP_SETTINGS_KEY } from '../../constants';


interface ReservationFormProps {
  initialData: Reservation | Partial<Reservation> | null; // Allow Partial for prefill from calendar
  customers: Customer[];
  properties: Property[];
  reservationStatusOptions: { value: string; label: string }[];
  onSave: (
    data: Omit<Reservation, 'id' | 'createdAt' | 'totalPrice' | 'balanceDue' | 'customer' | 'property'> & { id?: string },
    newCustomerData?: Omit<Customer, 'id' | 'createdAt'>
  ) => void;
  onCancel: () => void;
  calculateTotalPrice: (propertyId: string, checkIn: string, checkOut: string) => number;
}

const ReservationForm: React.FC<ReservationFormProps> = ({
  initialData,
  customers,
  properties,
  reservationStatusOptions,
  onSave,
  onCancel,
  calculateTotalPrice,
}) => {
  
  const isEditing = !!(initialData && 'id' in initialData && initialData.id);
  const [appSettings, setAppSettings] = useState<Partial<AppSettings>>({ defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00'});

  useEffect(() => {
    const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
    if (storedSettings) {
        try {
            const parsedSettings = JSON.parse(storedSettings) as AppSettings;
            setAppSettings(prev => ({...prev, ...parsedSettings}));
        } catch(e) { console.error("Error parsing settings in ReservationForm", e)}
    }
  }, []);


  const [formData, setFormData] = useState(() => {
    const defaults = {
      customerId: '',
      propertyId: '',
      checkInDate: '',
      checkInTime: appSettings.defaultCheckInTime || '14:00',
      checkOutDate: '',
      checkOutTime: appSettings.defaultCheckOutTime || '12:00',
      numberOfGuests: 1,
      status: ReservationStatus.PENDING,
      advanceAmount: 0,
      paymentProofDataUrl: '',
      notes: '',
    };
    
    if (!initialData) return defaults;
    
    // If it's a prefill (not editing an existing reservation), merge defaults with prefill data
    // The `initialData` for prefill might be a `Partial<Reservation>`
    if (!isEditing) {
        return {
            ...defaults, // Start with defaults (which now include appSettings defaults for times)
            ...(initialData as Partial<Reservation>) // Overlay any prefill data
        };
    }

    // For editing an existing reservation, use its data or fall back to defaults
    const typedInitialData = initialData as Reservation; // Safe to cast if isEditing
    return {
      customerId: typedInitialData.customerId || defaults.customerId,
      propertyId: typedInitialData.propertyId || defaults.propertyId,
      checkInDate: typedInitialData.checkInDate || defaults.checkInDate,
      checkInTime: typedInitialData.checkInTime || defaults.checkInTime,
      checkOutDate: typedInitialData.checkOutDate || defaults.checkOutDate,
      checkOutTime: typedInitialData.checkOutTime || defaults.checkOutTime,
      numberOfGuests: typedInitialData.numberOfGuests !== undefined ? typedInitialData.numberOfGuests : defaults.numberOfGuests,
      status: typedInitialData.status || defaults.status,
      advanceAmount: typedInitialData.advanceAmount !== undefined ? typedInitialData.advanceAmount : defaults.advanceAmount,
      paymentProofDataUrl: typedInitialData.paymentProofDataUrl || defaults.paymentProofDataUrl,
      notes: typedInitialData.notes || defaults.notes,
    };
  });
  
  // Re-sync form times if appSettings load after initial state set (and not editing)
  useEffect(() => {
    if (!isEditing) { // Only for new reservations
        setFormData(prev => ({
            ...prev,
            checkInTime: prev.checkInTime && prev.checkInTime !== '14:00' ? prev.checkInTime : (appSettings.defaultCheckInTime || '14:00'), // Prioritize prefill data if different from hardcoded default
            checkOutTime: prev.checkOutTime && prev.checkOutTime !== '12:00' ? prev.checkOutTime : (appSettings.defaultCheckOutTime || '12:00'),
        }));
    }
  }, [appSettings.defaultCheckInTime, appSettings.defaultCheckOutTime, isEditing]);


  const [calculatedPrice, setCalculatedPrice] = useState(0);
  const [balance, setBalance] = useState(0);
  const [showNewCustomerForm, setShowNewCustomerForm] = useState(false);
  const [newCustomerData, setNewCustomerData] = useState({
    fullName: '',
    phone: '',
    email: '',
    origin: '', // Added origin for new customer
  });

  const updatePriceAndBalance = useCallback(() => {
    const price = calculateTotalPrice(formData.propertyId, formData.checkInDate, formData.checkOutDate);
    setCalculatedPrice(price);
    const newBalance = price - (Number(formData.advanceAmount) || 0);
    setBalance(newBalance);
  }, [formData.propertyId, formData.checkInDate, formData.checkOutDate, formData.advanceAmount, calculateTotalPrice]);


  useEffect(() => {
    updatePriceAndBalance();
  }, [updatePriceAndBalance]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'numberOfGuests' || name === 'advanceAmount' ? parseFloat(value) || 0 : value }));
  };
  
  const handleNewCustomerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewCustomerData(prev => ({ ...prev, [name]: value }));
  };
  
  const handlePaymentProofChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, paymentProofDataUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    } else {
      setFormData(prev => ({ ...prev, paymentProofDataUrl: '' }));
    }
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let currentCustomerId = formData.customerId;
    let customerToSave: Omit<Customer, 'id' | 'createdAt'> | undefined = undefined;

    if (showNewCustomerForm) {
        if (!newCustomerData.fullName || !newCustomerData.phone) {
            alert("Por favor complete el nombre y teléfono del nuevo cliente.");
            return;
        }
        // Include origin when preparing new customer data to save
        customerToSave = { 
            fullName: newCustomerData.fullName,
            phone: newCustomerData.phone,
            email: newCustomerData.email,
            origin: newCustomerData.origin 
        };
        currentCustomerId = 'NEW_CUSTOMER_PLACEHOLDER'; // Placeholder, will be replaced on save
    }


    if (!currentCustomerId || !formData.propertyId || !formData.checkInDate || !formData.checkOutDate) {
        alert("Por favor complete todos los campos obligatorios: Cliente (o nuevo cliente), Propiedad, Check-in, Check-out.");
        return;
    }
    if (new Date(formData.checkOutDate) <= new Date(formData.checkInDate)) {
        alert("La fecha de Check-out debe ser posterior a la fecha de Check-in.");
        return;
    }
    const idToSave = isEditing ? (initialData as Reservation).id : undefined;
    
    // Strip customerId if it's the placeholder
    const finalFormData = { ...formData };
    if (showNewCustomerForm) {
      delete (finalFormData as any).customerId; // Customer ID will be set by parent after creating customer
    }

    onSave({ id: idToSave, ...finalFormData }, customerToSave);
  };

  const customerOptions = customers.map(c => ({ value: c.id, label: c.fullName }));
  if (!isEditing && !showNewCustomerForm) { // Only add if not editing and new customer form is hidden
      customerOptions.unshift({ value: '_NEW_', label: '--- Registrar Nuevo Cliente ---' });
  }

  const handleCustomerSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (e.target.value === '_NEW_') {
        setShowNewCustomerForm(true);
        setFormData(prev => ({...prev, customerId: ''})); // Clear existing selection
    } else {
        setShowNewCustomerForm(false);
        handleChange(e);
    }
  };
  
  const selectedCustomerDetails = customers.find(c => c.id === formData.customerId);


  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {!isEditing && (
         <div className="mb-4 p-3 bg-background rounded-md">
             <label className="flex items-center space-x-2 cursor-pointer">
                 <input 
                    type="checkbox"
                    checked={showNewCustomerForm}
                    onChange={(e) => {
                        setShowNewCustomerForm(e.target.checked);
                        if (!e.target.checked && formData.customerId === '') { 
                           // Potentially reset customerId or rely on validation
                        }
                    }}
                    className="form-checkbox h-5 w-5 text-primary rounded focus:ring-primary"
                 />
                 <span className="text-sm font-medium text-muted-foreground">Registrar Nuevo Cliente en esta Reserva</span>
             </label>
         </div>
      )}

      {showNewCustomerForm && !isEditing ? (
        <div className="p-4 border border-accent/50 rounded-lg space-y-3 bg-accent/5">
          <h3 className="text-md font-semibold text-accent mb-2">Datos del Nuevo Cliente</h3>
          <TextInput label="Nombre Completo Nuevo Cliente*" name="fullName" value={newCustomerData.fullName} onChange={handleNewCustomerChange} required={showNewCustomerForm} />
          <TextInput label="Teléfono Nuevo Cliente*" name="phone" value={newCustomerData.phone} onChange={handleNewCustomerChange} required={showNewCustomerForm} />
          <TextInput label="Email Nuevo Cliente" name="email" type="email" value={newCustomerData.email} onChange={handleNewCustomerChange} />
          <TextInput label="Lugar de Origen (Nuevo Cliente)" name="origin" value={newCustomerData.origin} onChange={handleNewCustomerChange} /> 
        </div>
      ) : (
        <>
          <SelectInput
            label="Cliente*"
            name="customerId"
            value={formData.customerId}
            onChange={handleCustomerSelectChange}
            options={customerOptions}
            required={!showNewCustomerForm}
            disabled={isEditing && !!(initialData as Reservation)?.customerId} // If editing and customer ID was pre-filled, disable
          />
          {selectedCustomerDetails && !showNewCustomerForm && (
            <div className="mt-1 mb-3 p-2 bg-background rounded text-sm text-muted-foreground">
              Origen del cliente seleccionado: <strong>{selectedCustomerDetails.origin || 'No especificado'}</strong>
            </div>
          )}
        </>
      )}

      <SelectInput
        label="Propiedad*"
        name="propertyId"
        value={formData.propertyId}
        onChange={handleChange}
        options={properties.map(p => ({ value: p.id, label: p.name }))}
        required
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Check-in*" name="checkInDate" value={formData.checkInDate} onChange={handleChange} required />
        <TextInput label="Hora de Check-in" name="checkInTime" type="time" value={formData.checkInTime} onChange={handleChange} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Check-out*" name="checkOutDate" value={formData.checkOutDate} onChange={handleChange} required />
        <TextInput label="Hora de Check-out" name="checkOutTime" type="time" value={formData.checkOutTime} onChange={handleChange} />
      </div>
      <TextInput label="Número de Huéspedes*" name="numberOfGuests" type="number" value={formData.numberOfGuests.toString()} onChange={handleChange} min="1" required />
      <SelectInput label="Estado de la Reserva*" name="status" value={formData.status} onChange={handleChange} options={reservationStatusOptions} required />
      <TextInput label="Monto de Anticipo/Pagado ($)" name="advanceAmount" type="number" value={formData.advanceAmount.toString()} onChange={handleChange} min="0" step="0.01" />
      
      <div className="p-3 bg-background rounded-md">
        <p className="text-sm font-medium text-muted-foreground">Precio Total Calculado: <span className="font-bold text-primary">${calculatedPrice.toFixed(2)}</span></p>
        <p className="text-sm font-medium text-muted-foreground">Saldo Pendiente: <span className="font-bold text-danger">${balance.toFixed(2)}</span></p>
      </div>
      
      <div>
        <label htmlFor="paymentProof" className="block text-sm font-medium text-muted-foreground mb-1">
          Comprobante de Pago (Imagen)
        </label>
        <div className="mt-1 flex items-center space-x-3">
          <input
            id="paymentProof"
            name="paymentProofDataUrl"
            type="file"
            accept="image/*"
            onChange={handlePaymentProofChange}
            className="block w-full text-sm text-muted-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer"
          />
          {formData.paymentProofDataUrl && (
            <Icon name="check" className="w-5 h-5 text-success"/>
          )}
        </div>
        {formData.paymentProofDataUrl && (
            <div className="mt-2 p-2 border border-border-color rounded-md inline-block bg-background">
                <img src={formData.paymentProofDataUrl} alt="Comprobante de pago" className="max-h-24 max-w-xs object-contain rounded"/>
            </div>
        )}
      </div>

      <TextareaInput label="Notas Adicionales" name="notes" value={formData.notes} onChange={handleChange} />
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {isEditing ? 'Actualizar Reserva' : 'Crear Reserva'}
        </Button>
      </div>
    </form>
  );
};

export default ReservationForm;
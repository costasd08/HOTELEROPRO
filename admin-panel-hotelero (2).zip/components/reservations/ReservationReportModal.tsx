import React, { useRef, useState } from 'react'; 
import html2canvas from 'html2canvas'; 
import { Reservation, ReservationReportSummary, AppSettings, Customer, Property } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
// Table component is no longer needed as details are removed
// import Table from '../common/Table'; 
import { APP_NAME, APP_SETTINGS_KEY } from '../../constants';

interface ReservationReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  // reservations: (Reservation & { customer?: Customer, property?: Property })[]; // No longer needed
  summary: ReservationReportSummary;
}

const formatDateToDMesAño = (dateString: string): string => {
  // Handles both 'YYYY-MM-DD' and ISO strings by ensuring it's parsed as local
  // For 'YYYY-MM-DD', appending 'T00:00:00' helps interpret it as local start of day
  const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
  if (isNaN(dateObj.getTime())) {
    return "Fecha Inválida";
  }
  const day = dateObj.getDate();
  const month = dateObj.toLocaleDateString('es-ES', { month: 'short' }).replace('.', ''); // Remove period if present e.g. "jul." -> "jul"
  const year = dateObj.getFullYear();
  return `${day}/${month}/${year}`;
};

const ReservationReportModal: React.FC<ReservationReportModalProps> = ({ isOpen, onClose, summary }) => {
  const reportContentRef = useRef<HTMLDivElement>(null); 
  const [isDownloadingImage, setIsDownloadingImage] = useState(false);

  let appSettings: AppSettings = { 
    appName: APP_NAME, 
    logoUrl: '', 
    hotelEmail: '', 
    responsiblePerson: '', 
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
  };
  try {
    const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
    if (settingsStr) {
      const parsed = JSON.parse(settingsStr);
      appSettings = { ...appSettings, ...parsed };
    }
  } catch (e) { /* ignore */ }
  
  const reportTitle = `Reporte de Reservas - ${summary.periodTypeLabel}`;

  // Columns for the detail table are no longer needed
  /*
  const columns: { header: string; accessor: keyof Reservation | ((item: Reservation) => React.ReactNode); className?: string }[] = [
    // ... column definitions (removed as table is removed)
  ];
  */
  
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadImage = async () => {
    if (!reportContentRef.current) return;
    setIsDownloadingImage(true);
    try {
      const canvas = await html2canvas(reportContentRef.current, { 
        scale: 2, 
        useCORS: true,
        backgroundColor: '#ffffff',
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `reporte_reservas_${formatDateToDMesAño(summary.startDate).replace(/\//g, '-')}_${formatDateToDMesAño(summary.endDate).replace(/\//g, '-')}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating image:", error);
      alert("Hubo un error al generar la imagen del reporte.");
    } finally {
      setIsDownloadingImage(false);
    }
  };

  return (
    // Changed size from 'xl' to 'lg' as the table is removed.
    <Modal isOpen={isOpen} onClose={onClose} title="Vista Previa del Reporte de Reservas" size="lg" footer={
      <>
        <Button variant="outline" size="sm" onClick={onClose} className="mr-auto">Cerrar</Button>
        <Button 
            variant="secondary" 
            size="sm"
            onClick={handleDownloadImage} 
            leftIcon={<Icon name="image" className="w-4 h-4"/>}
            isLoading={isDownloadingImage}
            disabled={isDownloadingImage}
            className="mr-2"
        >
            {isDownloadingImage ? 'Generando...' : 'Descargar Imagen'}
        </Button>
        <Button variant="primary" size="sm" onClick={handlePrint} leftIcon={<Icon name="download" className="w-4 h-4"/>}>
            Imprimir/PDF
        </Button>
      </>
    }>
      <div ref={reportContentRef} className="printable-report-area space-y-6 bg-surface p-4 sm:p-6">
        <header className="text-center mb-6 print:mb-4">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-20 mx-auto mb-3 object-contain print:max-h-16"/>
          )}
          {appSettings.reportCustomHeaderText && (
            <p className="text-sm text-muted-foreground mb-2 print:text-xs whitespace-pre-line">{appSettings.reportCustomHeaderText}</p>
          )}
          <h2 className="text-2xl font-bold text-primary print:text-xl">{appSettings.appName}</h2>
          <h3 className="text-xl font-semibold text-foreground print:text-lg">{reportTitle}</h3>
          {appSettings.responsiblePerson && (
            <p className="text-sm text-muted-foreground mt-1 print:text-xs">Responsable: {appSettings.responsiblePerson}</p>
          )}
          <p className="text-sm text-muted-foreground print:text-xs">
            Periodo (Check-in): {formatDateToDMesAño(summary.startDate)} al {formatDateToDMesAño(summary.endDate)}
          </p>
          <p className="text-sm text-muted-foreground print:text-xs">
            Generado el: {formatDateToDMesAño(summary.generatedAt)}
          </p>
        </header>

        <section className="p-4 bg-background rounded-lg shadow print:shadow-none print:p-0">
          <h4 className="text-lg font-semibold text-foreground mb-3 print:text-base">Resumen del Periodo</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-center sm:text-left">
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Total Reservas:</p>
              <p className="text-xl font-bold text-primary print:text-lg">{summary.totalReservations}</p>
            </div>
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Total Huéspedes:</p>
              <p className="text-xl font-bold text-primary print:text-lg">{summary.totalGuests}</p>
            </div>
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Ingresos Totales (No canceladas):</p>
              <p className="text-xl font-bold text-success print:text-lg">${summary.totalRevenue.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Precio Promedio/Reserva:</p>
              <p className="text-xl font-bold text-accent print:text-lg">${summary.averagePricePerReservation.toFixed(2)}</p>
            </div>
          </div>
        </section>

        {/* Section for Detailed Reservations Table REMOVED
        <section>
          <h4 className="text-lg font-semibold text-foreground mb-3 print:text-base">Detalle de Reservas</h4>
          {reservations.length > 0 ? (
            <Table columns={columns} data={reservations} emptyMessage="No hay reservas en este periodo."/>
          ) : (
            <p className="text-muted-foreground italic p-4 text-center">No se encontraron reservas para el periodo seleccionado.</p>
          )}
        </section>
        */}
        
        <footer className="text-center text-xs text-muted-foreground pt-6 border-t border-border-color mt-6 print:mt-4 print:pt-2">
            {appSettings.reportCustomFooterText && (
                <p className="mb-2 print:mb-1 whitespace-pre-line">{appSettings.reportCustomFooterText}</p>
            )}
            Reporte generado por {appSettings.appName}.
            {appSettings.phone && <span className="print:block"> Contacto: {appSettings.phone}</span>}
            {appSettings.hotelEmail && <span className="print:block"> Email: {appSettings.hotelEmail}</span>}
        </footer>
      </div>

      <style>
        {`
          @media print {
            body * {
              visibility: hidden;
            }
            .printable-report-area, .printable-report-area * {
              visibility: visible;
            }
            .printable-report-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              margin: 0;
              padding: 20px !important; 
              font-size: 9pt; 
              background-color: #ffffff !important; 
              -webkit-print-color-adjust: exact; 
              print-color-adjust: exact;
            }
            .bg-surface { background-color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .text-primary { color: hsl(215, 60%, 50%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-success { color: hsl(145, 63%, 42%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-danger { color: hsl(0, 72%, 51%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-accent { color: hsl(210, 65%, 60%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-foreground { color: hsl(220, 25%, 25%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-muted-foreground { color: hsl(220, 15%, 55%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .border-border-color { border-color: hsl(220, 20%, 85%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .bg-background { background-color: hsl(220, 60%, 96%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .shadow, .shadow-md, .shadow-lg { box-shadow: none !important; }
            .print\\:text-xs { font-size: 0.65rem !important; line-height: 0.9rem !important; }
            .print\\:text-sm { font-size: 0.75rem !important; line-height: 1rem !important; }
            .print\\:text-base { font-size: 0.85rem !important; line-height: 1.1rem !important; }
            .print\\:text-lg { font-size: 0.95rem !important; line-height: 1.2rem !important; }
            .print\\:text-xl { font-size: 1.1rem !important; line-height: 1.3rem !important; }
            .print\\:max-h-16 { max-height: 3.5rem !important; }
            /* Removed table specific print styles as table is gone */
            .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area,
            .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area * {
                visibility: visible !important;
            }
            .fixed.inset-0 > div > div:first-child button { 
                display: none !important;
            }
            .whitespace-pre-line { white-space: pre-line !important; }
          }
        `}
      </style>
    </Modal>
  );
};

export default ReservationReportModal;
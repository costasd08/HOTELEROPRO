import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { Reservation, Customer, Property, AppSettings } from '../../types';
import { APP_NAME, APP_SETTINGS_KEY } from '../../constants';
import Icon from '../common/Icon'; 
import Button from '../common/Button';

interface ReservationReceiptProps {
  reservation: Reservation;
  customer?: Customer;
  property?: Property;
}

const formatDateToDMMMYYYY = (dateString: string): string => {
  // Handles both 'YYYY-MM-DD' and ISO strings by ensuring it's parsed as local
  const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
  if (isNaN(dateObj.getTime())) {
    return "Fecha Inválida";
  }
  const day = dateObj.getDate();
  const month = dateObj.toLocaleDateString('es-ES', { month: 'short' }).replace('.', '').toUpperCase(); // E.g., MAR
  const year = dateObj.getFullYear();
  return `${day}/${month}/${year}`;
};


const ReservationReceipt: React.FC<ReservationReceiptProps> = ({ reservation, customer, property }) => {
  const receiptContentRef = useRef<HTMLDivElement>(null);
  const [isDownloadingImage, setIsDownloadingImage] = useState(false);

  const today = formatDateToDMMMYYYY(new Date().toISOString());

  let appSettings: AppSettings = { 
    appName: APP_NAME, 
    logoUrl: '', 
    hotelEmail: '', 
    responsiblePerson: '', 
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
    defaultCheckInTime: '14:00',
    defaultCheckOutTime: '12:00',
    reservationPolicies: '',
    cancellationPolicies: '',
    generalObservations: '',
    otherPolicies: '',
  };
  try {
    const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
    if (settingsStr) {
      const parsed = JSON.parse(settingsStr);
      appSettings = { ...appSettings, ...parsed };
    }
  } catch (e) { /* ignore */ }
  
  const handleShareWhatsAppLocal = () => { 
    let message = `*Confirmación de Reserva - ${appSettings.appName}*\n\n`;
    message += `Estimado/a ${customer?.fullName || 'Cliente'},\n\n`;
    message += `Le confirmamos los detalles de su reserva:\n`;
    message += `Número de Reserva: ${reservation.id}\n`;
    if (property) message += `Alojamiento: ${property.name}\n`;
    message += `Entrada: ${formatDateToDMMMYYYY(reservation.checkInDate)} ${reservation.checkInTime || appSettings.defaultCheckInTime || ''}\n`;
    message += `Salida: ${formatDateToDMMMYYYY(reservation.checkOutDate)} ${reservation.checkOutTime || appSettings.defaultCheckOutTime || ''}\n`;
    message += `Huéspedes: ${reservation.numberOfGuests}\n\n`;
    message += `Estado Actual: ${reservation.status}\n`;
    message += `Importe Total: $${reservation.totalPrice.toFixed(2)}\n`;
    if(reservation.advanceAmount) message += `Monto Pagado: $${(reservation.advanceAmount || 0).toFixed(2)}\n`;
    message += `*Saldo a Pagar: $${reservation.balanceDue.toFixed(2)}*\n\n`;
    if (reservation.notes) message += `Notas Adicionales: ${reservation.notes}\n\n`;
    
    if (appSettings.reservationPolicies) message += `*Políticas de Reservación:*\n${appSettings.reservationPolicies}\n\n`;
    if (appSettings.cancellationPolicies) message += `*Políticas de Cancelación:*\n${appSettings.cancellationPolicies}\n\n`;

    message += `¡Gracias por elegirnos! Esperamos su visita.\n`;
    if (appSettings.responsiblePerson) message += `Atendido por: ${appSettings.responsiblePerson}\n`;
    if (appSettings.phone) message += `Para consultas, contáctenos al: ${appSettings.phone}\n`;
    if (appSettings.hotelEmail) message += `O por email: ${appSettings.hotelEmail}\n`;

    const customerPhone = customer?.phone?.replace(/\D/g, ''); 
    const whatsappUrl = `https://wa.me/${customerPhone || ''}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleDownloadImage = async () => {
    if (!receiptContentRef.current) return;
    setIsDownloadingImage(true);
    try {
      const canvas = await html2canvas(receiptContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff', // Use surface color or white for capture
        onclone: (document) => {
          // Hide buttons specifically for image capture if they are inside receiptContentRef
          const footerToHide = document.querySelector('.receipt-footer-for-capture-hide');
          if (footerToHide) {
            (footerToHide as HTMLElement).style.display = 'none';
          }
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `recibo_reserva_${reservation.id}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating receipt image:", error);
      alert("Hubo un error al generar la imagen del recibo.");
    } finally {
      setIsDownloadingImage(false);
    }
  };


  return (
    // Added receiptContentRef here
    <div ref={receiptContentRef} className="bg-surface text-foreground p-6 sm:p-8 printable-area"> 
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b-2 border-border-color">
        <div className="mb-4 sm:mb-0">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-16 mb-2 object-contain"/>
          )}
          <h1 className="text-2xl sm:text-3xl font-bold text-primary">{appSettings.appName}</h1>
          <p className="text-sm text-muted-foreground">Recibo de Reserva</p>
        </div>
        <div className="text-left sm:text-right">
          {appSettings.responsiblePerson && (
            <p className="text-sm text-muted-foreground"><strong>Atendido por:</strong> {appSettings.responsiblePerson}</p>
          )}
          <p className="text-sm text-muted-foreground"><strong>Fecha de Emisión:</strong> {today}</p>
          <p className="text-sm text-muted-foreground"><strong>Reserva ID:</strong> <span className="font-mono">{reservation.id}</span></p>
        </div>
      </header>

      <section className="my-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-2">Detalles del Cliente</h2>
          <p className="text-sm text-muted-foreground"><strong>Nombre:</strong> {customer?.fullName || 'N/A'}</p>
          <p className="text-sm text-muted-foreground"><strong>Teléfono:</strong> {customer?.phone || 'N/A'}</p>
          {customer?.email && <p className="text-sm text-muted-foreground"><strong>Email:</strong> {customer.email}</p>}
          <p className="text-sm text-muted-foreground"><strong>Lugar de Origen:</strong> {customer?.origin || 'N/A'}</p>
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-2">Detalles de la Propiedad</h2>
          <p className="text-sm text-muted-foreground"><strong>Nombre:</strong> {property?.name || 'N/A'}</p>
          <p className="text-sm text-muted-foreground"><strong>Descripción:</strong> {property?.description || 'N/A'}</p>
        </div>
      </section>

      <section className="my-6">
        <h2 className="text-lg font-semibold text-foreground mb-2">Detalles de la Reserva</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border-color">
            <tbody className="bg-surface divide-y divide-border-color">
              <tr>
                <td className="px-4 py-3 text-sm font-medium text-muted-foreground">Check-in:</td>
                <td className="px-4 py-3 text-sm text-foreground">{formatDateToDMMMYYYY(reservation.checkInDate)} {reservation.checkInTime || appSettings.defaultCheckInTime || ''}</td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-sm font-medium text-muted-foreground">Check-out:</td>
                <td className="px-4 py-3 text-sm text-foreground">{formatDateToDMMMYYYY(reservation.checkOutDate)} {reservation.checkOutTime || appSettings.defaultCheckOutTime || ''}</td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-sm font-medium text-muted-foreground">Noches:</td>
                <td className="px-4 py-3 text-sm text-foreground">
                  {(new Date(reservation.checkOutDate).getTime() - new Date(reservation.checkInDate).getTime()) / (1000 * 3600 * 24)}
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-sm font-medium text-muted-foreground">Huéspedes:</td>
                <td className="px-4 py-3 text-sm text-foreground">{reservation.numberOfGuests}</td>
              </tr>
              <tr>
                <td className="px-4 py-3 text-sm font-medium text-muted-foreground">Estado:</td>
                <td className="px-4 py-3 text-sm text-foreground">{reservation.status}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section className="my-6 pt-6 border-t-2 border-border-color">
        <h2 className="text-lg font-semibold text-foreground mb-2">Resumen Financiero</h2>
        <div className="space-y-1 text-right">
          <p className="text-sm text-muted-foreground">Subtotal: <span className="font-semibold text-foreground">${reservation.totalPrice.toFixed(2)}</span></p>
          {reservation.advanceAmount && reservation.advanceAmount > 0 && (
            <p className="text-sm text-muted-foreground">Pagado: <span className="font-semibold text-success">${reservation.advanceAmount.toFixed(2)}</span></p>
          )}
          <p className="text-lg font-bold text-foreground">Saldo Pendiente: <span className="text-danger">${reservation.balanceDue.toFixed(2)}</span></p>
        </div>
      </section>
      
      {/* Comprobante de Pago Adjunto section REMOVED */}

      {reservation.notes && (
        <section className="my-6">
          <h2 className="text-lg font-semibold text-foreground mb-1">Notas Adicionales</h2>
          <p className="text-sm text-muted-foreground p-3 bg-background rounded-md whitespace-pre-line">{reservation.notes}</p>
        </section>
      )}

      <section className="my-6">
        <h2 className="text-lg font-semibold text-foreground mb-2">Políticas y Condiciones</h2>
        {appSettings.reservationPolicies && (
            <div className="mb-3">
                <h3 className="text-md font-medium text-muted-foreground">Políticas de Reservación:</h3>
                <p className="text-sm text-muted-foreground p-2 bg-background rounded-md whitespace-pre-line">{appSettings.reservationPolicies}</p>
            </div>
        )}
        {appSettings.cancellationPolicies && (
            <div className="mb-3">
                <h3 className="text-md font-medium text-muted-foreground">Políticas de Cancelación:</h3>
                <p className="text-sm text-muted-foreground p-2 bg-background rounded-md whitespace-pre-line">{appSettings.cancellationPolicies}</p>
            </div>
        )}
        {appSettings.generalObservations && (
            <div className="mb-3">
                <h3 className="text-md font-medium text-muted-foreground">Observaciones Generales:</h3>
                <p className="text-sm text-muted-foreground p-2 bg-background rounded-md whitespace-pre-line">{appSettings.generalObservations}</p>
            </div>
        )}
         {appSettings.otherPolicies && (
            <div className="mb-3">
                <h3 className="text-md font-medium text-muted-foreground">Otras Políticas:</h3>
                <p className="text-sm text-muted-foreground p-2 bg-background rounded-md whitespace-pre-line">{appSettings.otherPolicies}</p>
            </div>
        )}
        {!(appSettings.reservationPolicies || appSettings.cancellationPolicies || appSettings.generalObservations || appSettings.otherPolicies) && (
            <p className="text-sm text-muted-foreground italic">No hay políticas adicionales especificadas.</p>
        )}
      </section>


      {/* Added class receipt-footer-for-capture-hide to hide this footer during image capture */}
      <footer className="mt-8 pt-6 border-t-2 border-border-color text-center print:hidden receipt-footer-for-capture-hide">
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-3 sm:space-y-0 sm:gap-3">
            <Button 
                variant="outline" 
                size="sm"
                onClick={handleShareWhatsAppLocal} 
                title="Compartir Resumen por WhatsApp al Cliente"
            >
                <Icon name="whatsapp" className="w-4 h-4 mr-2 text-green-500"/>
                Enviar a Cliente
            </Button>
            <div className="flex gap-3">
              <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={handleDownloadImage}
                  isLoading={isDownloadingImage}
                  disabled={isDownloadingImage}
                  leftIcon={<Icon name="image" className="w-4 h-4" />}
              >
                  {isDownloadingImage ? 'Generando...' : 'Descargar Imagen'}
              </Button>
              <Button 
                  variant="primary" 
                  size="sm"
                  onClick={() => window.print()} 
                  leftIcon={<Icon name="download" className="w-4 h-4" />}
              >
                  Imprimir/PDF
              </Button>
            </div>
        </div>
        <p className="text-sm text-muted-foreground mt-6">Gracias por su reserva.</p>
        <p className="text-xs text-gray-400 mt-1">{appSettings.appName} - Contacto: {appSettings.phone || '(123) 456-7890'} | {appSettings.hotelEmail || 'email@example.com'}</p>
      </footer>
      
      <style>
        {`
          @media print {
            body * {
              visibility: hidden;
            }
            .printable-area, .printable-area * {
              visibility: visible;
            }
            .printable-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              margin: 0;
              padding: 20px;
              box-shadow: none !important;
              border: none !important;
            }
            .bg-surface { background-color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .text-primary { color: hsl(215, 60%, 50%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-success { color: hsl(145, 63%, 42%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-danger { color: hsl(0, 72%, 51%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-foreground { color: hsl(220, 25%, 25%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-muted-foreground { color: hsl(220, 15%, 55%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .border-border-color { border-color: hsl(220, 20%, 85%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .bg-background { background-color: hsl(220, 60%, 96%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .print\\:hidden { display: none !important; }
            .whitespace-pre-line { white-space: pre-line !important; }
          }
        `}
      </style>
    </div>
  );
};

export default ReservationReceipt;
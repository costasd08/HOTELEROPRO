
import React, { useState } from 'react';
import { EmailMarketingCampaign, EmailCampaignStatus, MarketingCampaign } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';

interface EmailCampaignFormProps {
  initialData: EmailMarketingCampaign | null;
  campaigns: MarketingCampaign[]; // For associating with a broader marketing campaign
  statusOptions: { value: string; label: string }[];
  onSave: (data: Omit<EmailMarketingCampaign, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onCancel: () => void;
}

const EmailCampaignForm: React.FC<EmailCampaignFormProps> = ({
  initialData,
  campaigns,
  statusOptions,
  onSave,
  onCancel,
}) => {
  const [formData, setFormData] = useState(() => {
    const now = new Date();
    const initialScheduledDateTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1, 0, 0).toISOString();

    return {
        campaignId: initialData?.campaignId || '',
        name: initialData?.name || '',
        subject: initialData?.subject || '',
        targetAudienceDescription: initialData?.targetAudienceDescription || '',
        contentPreview: initialData?.contentPreview || '',
        scheduledSendDateTime: initialData?.scheduledSendDateTime || initialScheduledDateTime,
        status: initialData?.status || EmailCampaignStatus.BORRADOR,
    };
  });
  
  const [scheduledDate, setScheduledDate] = useState<string>(
    new Date(formData.scheduledSendDateTime).toISOString().split('T')[0]
  );
  const [scheduledTime, setScheduledTime] = useState<string>(
    new Date(formData.scheduledSendDateTime).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
  );

  React.useEffect(() => {
    try {
        const [hours, minutes] = scheduledTime.split(':').map(Number);
        if (!isNaN(hours) && !isNaN(minutes)) {
            const newDateTime = new Date(scheduledDate);
            newDateTime.setHours(hours, minutes, 0, 0);
            setFormData(prev => ({ ...prev, scheduledSendDateTime: newDateTime.toISOString() }));
        }
    } catch (error) {
        console.error("Error parsing time for email campaign:", error);
    }
  }, [scheduledDate, scheduledTime]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.subject || !formData.targetAudienceDescription || !formData.scheduledSendDateTime) {
        alert("Nombre, asunto, público objetivo y fecha/hora de envío son obligatorios.");
        return;
    }
    onSave({ id: initialData?.id, ...formData });
  };
  
  const campaignOptions = [{value: '', label: 'Ninguna (Campaña Email Independiente)'}, ...campaigns.map(c => ({ value: c.id, label: c.name }))];


  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <SelectInput label="Campaña de Marketing General Asociada (Opcional)" name="campaignId" value={formData.campaignId} onChange={handleChange} options={campaignOptions} />
      <TextInput label="Nombre de esta Campaña de Email*" name="name" value={formData.name} onChange={handleChange} required placeholder="Ej: Newsletter Julio, Oferta Especial Verano"/>
      <TextInput label="Asunto del Email*" name="subject" value={formData.subject} onChange={handleChange} required />
      <TextInput label="Público Objetivo (Descripción)*" name="targetAudienceDescription" value={formData.targetAudienceDescription} onChange={handleChange} required placeholder="Ej: Clientes que reservaron en Verano 2023"/>
      <TextareaInput label="Vista Previa/Resumen del Contenido del Email*" name="contentPreview" value={formData.contentPreview} onChange={handleChange} rows={3} required placeholder="Un breve resumen o las primeras líneas del email."/>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Envío Programada*" name="scheduledDate" value={scheduledDate} onChange={(e) => setScheduledDate(e.target.value)} required />
        <TextInput label="Hora de Envío Programada*" name="scheduledTime" type="time" value={scheduledTime} onChange={(e) => setScheduledTime(e.target.value)} required />
      </div>

      <SelectInput label="Estado de la Campaña de Email*" name="status" value={formData.status} onChange={handleChange} options={statusOptions} required />
      
      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Campaña Email' : 'Crear Campaña Email'}</Button>
      </div>
    </form>
  );
};

export default EmailCampaignForm;

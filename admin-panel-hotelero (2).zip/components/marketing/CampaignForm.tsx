
import React, { useState } from 'react';
import { MarketingCampaign, MarketingCampaignStatus } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';

interface CampaignFormProps {
  initialData: MarketingCampaign | null;
  onSave: (data: Omit<MarketingCampaign, 'id' | 'createdAt' | 'updatedAt'> & { id?: string, associatedCost?: number }) => void;
  onCancel: () => void;
  statusOptions: { value: string; label: string }[];
}

const CampaignForm: React.FC<CampaignFormProps> = ({ initialData, onSave, onCancel, statusOptions }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    description: initialData?.description || '',
    startDate: initialData?.startDate || new Date().toISOString().split('T')[0],
    endDate: initialData?.endDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Default to 30 days from now
    budget: initialData?.budget || undefined,
    goals: initialData?.goals || '',
    targetAudience: initialData?.targetAudience || '',
    channels: initialData?.channels || [],
    status: initialData?.status || MarketingCampaignStatus.PLANIFICADA,
  });
  const [channelsInput, setChannelsInput] = useState(initialData?.channels?.join(', ') || '');
  const [associatedCost, setAssociatedCost] = useState<number | undefined>(undefined);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'budget' ? (value === '' ? undefined : parseFloat(value)) : value,
    }));
  };
  
  const handleChannelsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setChannelsInput(e.target.value);
    setFormData(prev => ({
        ...prev,
        channels: e.target.value.split(',').map(ch => ch.trim()).filter(ch => ch)
    }));
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.startDate || !formData.endDate) {
        alert("Nombre de campaña, fecha de inicio y fecha de fin son obligatorios.");
        return;
    }
    if (new Date(formData.endDate) < new Date(formData.startDate)) {
        alert("La fecha de fin no puede ser anterior a la fecha de inicio.");
        return;
    }
    onSave({ id: initialData?.id, ...formData, associatedCost });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <TextInput label="Nombre de la Campaña*" name="name" value={formData.name} onChange={handleChange} required />
      <TextareaInput label="Descripción" name="description" value={formData.description} onChange={handleChange} rows={3} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Inicio*" name="startDate" value={formData.startDate} onChange={handleChange} required />
        <DateInput label="Fecha de Fin*" name="endDate" value={formData.endDate} onChange={handleChange} required />
      </div>
      <TextInput label="Presupuesto Total ($) (Opcional)" name="budget" type="number" value={formData.budget?.toString() || ''} onChange={handleChange} min="0" step="0.01" />
      
      {!initialData?.id && ( // Only show for new campaigns
        <TextInput 
            label="Gasto Inicial Asociado a esta Campaña ($) (Opcional)" 
            type="number" 
            value={associatedCost?.toString() || ''} 
            onChange={(e) => setAssociatedCost(e.target.value === '' ? undefined : parseFloat(e.target.value))} 
            min="0" 
            step="0.01"
            helperText="Si se ingresa, se creará un asiento de gasto en contabilidad."
        />
      )}

      <TextareaInput label="Objetivos de la Campaña" name="goals" value={formData.goals} onChange={handleChange} rows={2} placeholder="Ej: Aumentar reservas, Incrementar seguidores..." />
      <TextInput label="Público Objetivo" name="targetAudience" value={formData.targetAudience} onChange={handleChange} placeholder="Ej: Familias, Parejas jóvenes, Viajeros de negocios" />
      <TextInput label="Canales Principales (separados por coma)" name="channelsInput" value={channelsInput} onChange={handleChannelsChange} placeholder="Ej: Redes Sociales, Email, Anuncios Google" />
      <SelectInput label="Estado de la Campaña*" name="status" value={formData.status} onChange={handleChange} options={statusOptions} required />
      
      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Campaña' : 'Crear Campaña'}</Button>
      </div>
    </form>
  );
};

export default CampaignForm;


import React, { useState, useEffect } from 'react';
import { SocialMediaPost, SocialMediaPlatform, SocialMediaPostStatus, MarketingCampaign } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Icon from '../common/Icon';

interface SocialPostFormProps {
  initialData: SocialMediaPost | null;
  campaigns: MarketingCampaign[];
  platformOptions: { value: string; label: string }[];
  statusOptions: { value: string; label: string }[];
  onSave: (data: Omit<SocialMediaPost, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  onCancel: () => void;
  prefillDate?: string; // YYYY-MM-DD for prefilling scheduledDateTime date part
}

const SocialPostForm: React.FC<SocialPostFormProps> = ({
  initialData,
  campaigns,
  platformOptions,
  statusOptions,
  onSave,
  onCancel,
  prefillDate,
}) => {
  const [formData, setFormData] = useState(() => {
    const now = new Date();
    // If prefillDate is provided, use it. Otherwise, use current date for new posts.
    const initialScheduledDate = prefillDate ? new Date(prefillDate + 'T00:00:00') : new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1, 0, 0); // Default to next hour if no prefill

    return {
        campaignId: initialData?.campaignId || '',
        platform: initialData?.platform || SocialMediaPlatform.FACEBOOK,
        content: initialData?.content || '',
        imageUrl: initialData?.imageUrl || '',
        videoUrl: initialData?.videoUrl || '',
        scheduledDateTime: initialData?.scheduledDateTime || initialScheduledDate.toISOString(),
        status: initialData?.status || SocialMediaPostStatus.BORRADOR,
        notes: initialData?.notes || '',
    };
  });
  
  const [scheduledDate, setScheduledDate] = useState<string>(
    new Date(formData.scheduledDateTime).toISOString().split('T')[0]
  );
  const [scheduledTime, setScheduledTime] = useState<string>(
    new Date(formData.scheduledDateTime).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
  );


  useEffect(() => {
    try {
        const [hours, minutes] = scheduledTime.split(':').map(Number);
        if (!isNaN(hours) && !isNaN(minutes)) {
            const newDateTime = new Date(scheduledDate);
            newDateTime.setHours(hours, minutes, 0, 0);
            setFormData(prev => ({ ...prev, scheduledDateTime: newDateTime.toISOString() }));
        }
    } catch (error) {
        console.error("Error parsing time for social post:", error);
        // Potentially keep old scheduledDateTime or handle error
    }
  }, [scheduledDate, scheduledTime]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string, videoUrl: '' })); // Clear video if image is uploaded
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleVideoUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, videoUrl: e.target.value, imageUrl: '' })); // Clear image if video URL is provided
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.platform || !formData.content || !formData.scheduledDateTime) {
        alert("Plataforma, contenido y fecha/hora de programación son obligatorios.");
        return;
    }
    onSave({ id: initialData?.id, ...formData });
  };
  
  const campaignOptions = [{value: '', label: 'Ninguna (Publicación Independiente)'}, ...campaigns.map(c => ({ value: c.id, label: c.name }))];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <SelectInput label="Campaña Asociada (Opcional)" name="campaignId" value={formData.campaignId} onChange={handleChange} options={campaignOptions} />
      <SelectInput label="Plataforma*" name="platform" value={formData.platform} onChange={handleChange} options={platformOptions} required />
      <TextareaInput label="Contenido de la Publicación*" name="content" value={formData.content} onChange={handleChange} rows={4} required />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DateInput label="Fecha de Programación*" name="scheduledDate" value={scheduledDate} onChange={(e) => setScheduledDate(e.target.value)} required />
        <TextInput label="Hora de Programación*" name="scheduledTime" type="time" value={scheduledTime} onChange={(e) => setScheduledTime(e.target.value)} required />
      </div>

      <div>
        <label htmlFor="socialPostImageUpload" className="block text-sm font-medium text-muted-foreground mb-1">
          Imagen (Opcional)
        </label>
        <div className="mt-1 flex items-center space-x-3">
            <label htmlFor="socialPostImageUpload" className="inline-flex items-center px-4 py-2 bg-primary/10 text-primary text-sm font-medium rounded-md cursor-pointer hover:bg-primary/20 transition-colors">
                <Icon name="upload" className="w-4 h-4 mr-2"/>
                Subir Imagen
            </label>
            <input 
                id="socialPostImageUpload"
                type="file" 
                accept="image/*" 
                onChange={handlePhotoUpload} 
                className="hidden"
            />
            {formData.imageUrl && (
                <Icon name="check" className="w-5 h-5 text-success"/>
            )}
        </div>
        {formData.imageUrl && (
         <div className="mt-3 p-2 border border-border-color rounded-md inline-block bg-background">
            <img src={formData.imageUrl} alt="Previsualización" className="max-h-24 max-w-xs object-contain rounded"/>
         </div>
       )}
      </div>
      <TextInput label="O URL de Video (Opcional)" name="videoUrl" value={formData.videoUrl} onChange={handleVideoUrlChange} placeholder="Ej: https://youtube.com/watch?v=..." />

      <SelectInput label="Estado de la Publicación*" name="status" value={formData.status} onChange={handleChange} options={statusOptions} required />
      <TextareaInput label="Notas Internas (Opcional)" name="notes" value={formData.notes} onChange={handleChange} rows={2} />

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Publicación' : 'Crear Publicación'}</Button>
      </div>
    </form>
  );
};

export default SocialPostForm;

import React, { useState, useEffect } from 'react';
import { AccountingEntry, AccountingEntryType, AccountingExpenseCategory, AccountingIncomeCategory } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import SelectInput from '../common/SelectInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import { ACCOUNTING_INCOME_CATEGORY_OPTIONS, ACCOUNTING_EXPENSE_CATEGORY_OPTIONS } from '../../constants'; // Import new options

interface AccountingEntryFormProps {
  initialData: AccountingEntry | Partial<Pick<AccountingEntry, 'type'>> | null;
  onSave: (data: Omit<AccountingEntry, 'id' | 'createdAt'> & { id?: string }) => void;
  onCancel: () => void;
  entryTypeOptions: { value: string; label: string }[];
}

interface FormDataState {
  date: string;
  type: AccountingEntryType;
  category: AccountingExpenseCategory | AccountingIncomeCategory;
  description: string;
  amount: number;
}

const AccountingEntryForm: React.FC<AccountingEntryFormProps> = ({ 
    initialData, 
    onSave, 
    onCancel, 
    entryTypeOptions,
}) => {
  const [formData, setFormData] = useState<FormDataState>(() => {
    const defaults = {
        date: new Date().toISOString().split('T')[0],
        type: AccountingEntryType.INCOME,
        category: ACCOUNTING_INCOME_CATEGORY_OPTIONS[0]?.value as AccountingIncomeCategory || AccountingIncomeCategory.HOSPEDAJE,
        description: '',
        amount: 0,
    };

    if (!initialData) return defaults;

    const type = (initialData && 'type' in initialData && initialData.type) ? initialData.type : defaults.type;
    let category;

    if (initialData && 'category' in initialData && initialData.category) {
        category = initialData.category as AccountingExpenseCategory | AccountingIncomeCategory;
    } else {
        category = type === AccountingEntryType.INCOME 
            ? (ACCOUNTING_INCOME_CATEGORY_OPTIONS[0]?.value as AccountingIncomeCategory || AccountingIncomeCategory.HOSPEDAJE)
            : (ACCOUNTING_EXPENSE_CATEGORY_OPTIONS[0]?.value as AccountingExpenseCategory || AccountingExpenseCategory.OPERATIONAL);
    }
    
    // Ensure the category is valid for the type
    if (type === AccountingEntryType.INCOME && !ACCOUNTING_INCOME_CATEGORY_OPTIONS.some(opt => opt.value === category)) {
        category = ACCOUNTING_INCOME_CATEGORY_OPTIONS[0]?.value as AccountingIncomeCategory || AccountingIncomeCategory.HOSPEDAJE;
    } else if (type === AccountingEntryType.EXPENSE && !ACCOUNTING_EXPENSE_CATEGORY_OPTIONS.some(opt => opt.value === category)) {
        category = ACCOUNTING_EXPENSE_CATEGORY_OPTIONS[0]?.value as AccountingExpenseCategory || AccountingExpenseCategory.OPERATIONAL;
    }

    return {
        date: (initialData && 'date' in initialData && initialData.date) ? initialData.date : defaults.date,
        type: type,
        category: category,
        description: (initialData && 'description' in initialData && initialData.description) ? initialData.description : defaults.description,
        amount: (initialData && 'amount' in initialData && initialData.amount !== undefined) ? initialData.amount : defaults.amount,
    };
  });

  const [currentCategoryOptions, setCurrentCategoryOptions] = useState(
    formData.type === AccountingEntryType.INCOME ? ACCOUNTING_INCOME_CATEGORY_OPTIONS : ACCOUNTING_EXPENSE_CATEGORY_OPTIONS
  );

  useEffect(() => {
    // This effect ensures category options are updated when type changes,
    // and also attempts to reset category if it becomes invalid for the new type.
    setFormData(prev => {
      let newCategory = prev.category;
      let newCurrentCategoryOptions = prev.type === AccountingEntryType.INCOME ? ACCOUNTING_INCOME_CATEGORY_OPTIONS : ACCOUNTING_EXPENSE_CATEGORY_OPTIONS;
      
      if (prev.type === AccountingEntryType.INCOME) {
        newCurrentCategoryOptions = ACCOUNTING_INCOME_CATEGORY_OPTIONS;
        if (!newCurrentCategoryOptions.some(opt => opt.value === prev.category)) {
          newCategory = newCurrentCategoryOptions[0]?.value as AccountingIncomeCategory || AccountingIncomeCategory.HOSPEDAJE;
        }
      } else { // Expense
        newCurrentCategoryOptions = ACCOUNTING_EXPENSE_CATEGORY_OPTIONS;
        if (!newCurrentCategoryOptions.some(opt => opt.value === prev.category)) {
          newCategory = newCurrentCategoryOptions[0]?.value as AccountingExpenseCategory || AccountingExpenseCategory.OPERATIONAL;
        }
      }
      
      setCurrentCategoryOptions(newCurrentCategoryOptions);

      if (newCategory !== prev.category) {
        return {...prev, category: newCategory };
      }
      return prev; // No change needed in formData if category is still valid
    });
  }, [formData.type]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    setFormData(prev => {
        if (name === "type") {
            const newType = value as AccountingEntryType;
            const defaultCategoryForNewType = newType === AccountingEntryType.INCOME 
                ? (ACCOUNTING_INCOME_CATEGORY_OPTIONS[0]?.value as AccountingIncomeCategory || AccountingIncomeCategory.HOSPEDAJE)
                : (ACCOUNTING_EXPENSE_CATEGORY_OPTIONS[0]?.value as AccountingExpenseCategory || AccountingExpenseCategory.OPERATIONAL);
            return {
                ...prev,
                type: newType,
                category: defaultCategoryForNewType,
            };
        } else {
            return {
                ...prev,
                [name]: name === 'amount' ? parseFloat(value) || 0 : value
            };
        }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.date || !formData.description || formData.amount <= 0) {
        alert("Fecha, descripción y monto (mayor a 0) son obligatorios.");
        return;
    }
    const idToSave = (initialData && 'id' in initialData) ? initialData.id : undefined;
    onSave({ id: idToSave, ...formData });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <DateInput
        label="Fecha*"
        name="date"
        value={formData.date}
        onChange={handleChange}
        required
      />
      <SelectInput
        label="Tipo de Asiento*"
        name="type"
        value={formData.type}
        onChange={handleChange}
        options={entryTypeOptions}
        required
      />
      <SelectInput
        label="Categoría*"
        name="category"
        value={formData.category}
        onChange={handleChange}
        options={currentCategoryOptions}
        required
      />
      <TextareaInput
        label="Descripción*"
        name="description"
        value={formData.description}
        onChange={handleChange}
        rows={3}
        required
      />
      <TextInput
        label="Monto ($)*"
        name="amount"
        type="number"
        value={formData.amount.toString()}
        onChange={handleChange}
        min="0.01"
        step="0.01"
        required
      />
      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {(initialData && 'id' in initialData) ? 'Actualizar Asiento' : 'Crear Asiento'}
        </Button>
      </div>
    </form>
  );
};

export default AccountingEntryForm;
import React, { useRef, useState } from 'react'; 
import html2canvas from 'html2canvas'; 
import { AccountingEntry, ReportSummary, AccountingEntryType, AppSettings } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import Table from '../common/Table';
import { APP_NAME, APP_SETTINGS_KEY } from '../../constants';

interface AccountingReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: AccountingEntry[];
  summary: ReportSummary;
}

const formatDateToDMesAño = (dateString: string): string => {
  // Handles both 'YYYY-MM-DD' and ISO strings by ensuring it's parsed as local
  const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
  if (isNaN(dateObj.getTime())) {
    return "Fecha Inválida";
  }
  const day = dateObj.getDate();
  const month = dateObj.toLocaleDateString('es-ES', { month: 'short' }).replace('.', ''); 
  const year = dateObj.getFullYear();
  return `${day}/${month}/${year}`;
};


const AccountingReportModal: React.FC<AccountingReportModalProps> = ({ isOpen, onClose, entries, summary }) => {
  const reportContentRef = useRef<HTMLDivElement>(null); 
  const [isDownloadingImage, setIsDownloadingImage] = useState(false);
  
  let appSettings: AppSettings = { 
    appName: APP_NAME, 
    logoUrl: '', 
    hotelEmail: '', 
    responsiblePerson: '', 
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
  };
  try {
    const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
    if (settingsStr) {
      const parsed = JSON.parse(settingsStr);
      appSettings = { ...appSettings, ...parsed };
    }
  } catch (e) { /* ignore */ }
  
  const reportTitle = `Reporte Financiero - ${summary.periodTypeLabel}`;

  const columns: { header: string; accessor: keyof AccountingEntry | ((item: AccountingEntry) => React.ReactNode); className?: string }[] = [
    { header: 'Categoría', accessor: 'category' },
    { header: 'Descripción', accessor: 'description', className: 'truncate max-w-xs' },
    { 
      header: 'Monto', 
      accessor: (item: AccountingEntry) => (
        <span className={`font-semibold ${item.type === AccountingEntryType.INCOME ? 'text-success' : 'text-danger'}`}>
          {`${item.type === AccountingEntryType.EXPENSE ? '-' : ''}$${item.amount.toFixed(2)}`}
        </span>
      ),
      className: 'text-right' 
    },
  ];
  
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadImage = async () => {
    if (!reportContentRef.current) return;
    setIsDownloadingImage(true);
    try {
      const canvas = await html2canvas(reportContentRef.current, {
        scale: 2, 
        useCORS: true, 
        backgroundColor: '#ffffff', 
        onclone: (document) => {
          // You can modify the cloned document here if needed before capture
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `reporte_financiero_${formatDateToDMesAño(summary.startDate).replace(/\//g, '-')}_${formatDateToDMesAño(summary.endDate).replace(/\//g, '-')}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating image:", error);
      alert("Hubo un error al generar la imagen del reporte.");
    } finally {
      setIsDownloadingImage(false);
    }
  };


  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Vista Previa del Reporte" size="xl" footer={
      <>
        <Button variant="outline" size="sm" onClick={onClose} className="mr-auto">Cerrar</Button>
        <Button 
            variant="secondary" 
            size="sm"
            onClick={handleDownloadImage} 
            leftIcon={<Icon name="image" className="w-4 h-4"/>}
            isLoading={isDownloadingImage}
            disabled={isDownloadingImage}
            className="mr-2"
        >
            {isDownloadingImage ? 'Generando...' : 'Descargar Imagen'}
        </Button>
        <Button variant="primary" size="sm" onClick={handlePrint} leftIcon={<Icon name="download" className="w-4 h-4"/>}>
            Imprimir/PDF
        </Button>
      </>
    }>
      <div ref={reportContentRef} className="printable-report-area space-y-6 bg-surface p-4 sm:p-6"> 
        <header className="text-center mb-6 print:mb-4">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-20 mx-auto mb-3 object-contain print:max-h-16"/>
          )}
          {appSettings.reportCustomHeaderText && (
            <p className="text-sm text-muted-foreground mb-2 print:text-xs whitespace-pre-line">{appSettings.reportCustomHeaderText}</p>
          )}
          <h2 className="text-2xl font-bold text-primary print:text-xl">{appSettings.appName}</h2>
          <h3 className="text-xl font-semibold text-foreground print:text-lg">{reportTitle}</h3>
          {appSettings.responsiblePerson && (
            <p className="text-sm text-muted-foreground mt-1 print:text-xs">Responsable: {appSettings.responsiblePerson}</p>
          )}
          <p className="text-sm text-muted-foreground print:text-xs">
            Periodo: {formatDateToDMesAño(summary.startDate)} al {formatDateToDMesAño(summary.endDate)}
          </p>
          <p className="text-sm text-muted-foreground print:text-xs">
            Generado el: {formatDateToDMesAño(summary.generatedAt)}
          </p>
        </header>

        <section className="p-4 bg-background rounded-lg shadow print:shadow-none print:p-0">
          <h4 className="text-lg font-semibold text-foreground mb-3 print:text-base">Resumen del Periodo</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center sm:text-left">
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Ingresos Totales:</p>
              <p className="text-xl font-bold text-success print:text-lg">${summary.totalIncome.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Gastos Totales:</p>
              <p className="text-xl font-bold text-danger print:text-lg">${summary.totalExpenses.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-surface rounded shadow print:border print:border-border-color">
              <p className="text-sm text-muted-foreground">Balance Neto:</p>
              <p className={`text-xl font-bold print:text-lg ${summary.balance >= 0 ? 'text-primary' : 'text-danger'}`}>
                ${summary.balance.toFixed(2)}
              </p>
            </div>
          </div>
        </section>

        <section>
          <h4 className="text-lg font-semibold text-foreground mb-3 print:text-base">Detalle de Movimientos</h4>
          {entries.length > 0 ? (
            <Table columns={columns} data={entries} emptyMessage="No hay movimientos en este periodo."/>
          ) : (
            <p className="text-muted-foreground italic p-4 text-center">No se encontraron movimientos para el periodo seleccionado.</p>
          )}
        </section>
        
        <footer className="text-center text-xs text-muted-foreground pt-6 border-t border-border-color mt-6 print:mt-4 print:pt-2">
            {appSettings.reportCustomFooterText && (
                <p className="mb-2 print:mb-1 whitespace-pre-line">{appSettings.reportCustomFooterText}</p>
            )}
            Reporte generado por {appSettings.appName}.
            {appSettings.phone && <span className="print:block"> Contacto: {appSettings.phone}</span>}
            {appSettings.hotelEmail && <span className="print:block"> Email: {appSettings.hotelEmail}</span>}
        </footer>
      </div>

      <style>
        {`
          @media print {
            body * {
              visibility: hidden;
            }
            .printable-report-area, .printable-report-area * {
              visibility: visible;
            }
            .printable-report-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              margin: 0;
              padding: 20px !important; 
              font-size: 10pt; 
              background-color: #ffffff !important; 
              -webkit-print-color-adjust: exact; 
              print-color-adjust: exact;
            }
            .modal-footer-print-hidden { 
                 display: none !important;
            }
             .bg-surface { background-color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .text-primary { color: hsl(215, 60%, 50%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-success { color: hsl(145, 63%, 42%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-danger { color: hsl(0, 72%, 51%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-foreground { color: hsl(220, 25%, 25%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .text-muted-foreground { color: hsl(220, 15%, 55%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .border-border-color { border-color: hsl(220, 20%, 85%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .bg-background { background-color: hsl(220, 60%, 96%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact;}
            .shadow, .shadow-md, .shadow-lg { box-shadow: none !important; }
            .rounded, .rounded-lg, .rounded-md, .rounded-full { border-radius: 0 !important; } 
            .print\\:text-xs { font-size: 0.7rem !important; line-height: 1rem !important; }
            .print\\:text-sm { font-size: 0.8rem !important; line-height: 1.1rem !important; }
            .print\\:text-base { font-size: 0.9rem !important; line-height: 1.2rem !important; }
            .print\\:text-lg { font-size: 1rem !important; line-height: 1.3rem !important; }
            .print\\:text-xl { font-size: 1.2rem !important; line-height: 1.4rem !important; }
            .print\\:max-h-16 { max-height: 4rem !important; }
            .print\\:mb-4 { margin-bottom: 1rem !important; }
            .print\\:p-0 { padding: 0 !important; }
            .print\\:border { border-width: 1px !important; }
            .print\\:shadow-none { box-shadow: none !important; }
            .printable-report-area table { width: 100% !important; border-collapse: collapse !important; }
            .printable-report-area th, .printable-report-area td { border: 1px solid hsl(220, 20%, 85%) !important; padding: 4px 6px !important; }
            .printable-report-area th { background-color: hsl(220, 60%, 96%) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area,
            .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area * {
                visibility: visible !important;
            }
            .fixed.inset-0 > div > div:first-child button {
                display: none !important;
            }
            .whitespace-pre-line { white-space: pre-line !important; }
          }
        `}
      </style>
    </Modal>
  );
};

export default AccountingReportModal;
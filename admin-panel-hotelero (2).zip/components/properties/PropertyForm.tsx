
import React, { useState } from 'react';
import { Property, MaintenanceLogEntry, RoomCleaningStatus } from '../../types'; // Added RoomCleaningStatus
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Icon from '../common/Icon';
import DateInput from '../common/DateInput';
import { ROOM_CLEANING_STATUS_OPTIONS, AMENITY_OPTIONS } from '../../constants'; // Import options

interface PropertyFormProps {
  initialData: Property | null;
  onSave: (data: Omit<Property, 'id' | 'createdAt' | 'maintenanceLog'> & { id?: string, maintenanceLog?: MaintenanceLogEntry[] }) => void;
  onCancel: () => void;
  colorOptions: { name: string; class: string }[];
}

const PropertyForm: React.FC<PropertyFormProps> = ({ initialData, onSave, onCancel, colorOptions }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    description: initialData?.description || '',
    maxCapacity: initialData?.maxCapacity || 1,
    bedConfiguration: initialData?.bedConfiguration || '',
    pricePerNight: initialData?.pricePerNight || 0,
    photoUrls: initialData?.photoUrls || [], 
    calendarColor: initialData?.calendarColor || colorOptions[0]?.class || 'bg-primary text-white',
    currentCleaningStatus: initialData?.currentCleaningStatus || RoomCleaningStatus.LIMPIA, // Default to LIMPIA for new
    lastCleanedDate: initialData?.lastCleanedDate || undefined,
    amenities: initialData?.amenities || [], // Added amenities
  });
  const [maintenanceLog, setMaintenanceLog] = useState<MaintenanceLogEntry[]>(initialData?.maintenanceLog || []);
  const [newLogEntry, setNewLogEntry] = useState<Omit<MaintenanceLogEntry, 'id'>>({ date: '', description: '', cost: undefined });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: (name === 'maxCapacity' || name === 'pricePerNight') ? parseFloat(value) || 0 : value }));
  };
  
  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const newPhotoDataUrls: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (reader.result) {
            newPhotoDataUrls.push(reader.result as string);
            if (newPhotoDataUrls.length === files.length) {
                 setFormData(prev => ({ ...prev, photoUrls: [...prev.photoUrls, ...newPhotoDataUrls] }));
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };


  const handleRemovePhotoUrl = (urlToRemove: string) => {
    setFormData(prev => ({ ...prev, photoUrls: prev.photoUrls.filter(url => url !== urlToRemove) }));
  };

  const handleLogChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => { 
    const { name, value } = e.target;
    setNewLogEntry(prev => ({ ...prev, [name]: name === 'cost' ? (value === '' ? undefined : parseFloat(value)) : value }));
  };

  const handleAddLogEntry = () => {
    if (newLogEntry.date && newLogEntry.description) {
        setMaintenanceLog(prev => [...prev, { ...newLogEntry, id: `log-${Date.now()}`, cost: newLogEntry.cost ?? undefined }]);
        setNewLogEntry({ date: '', description: '', cost: undefined });
    } else {
        alert("Fecha y descripción son requeridas para el registro de mantenimiento.");
    }
  };

  const handleRemoveLogEntry = (id: string) => {
    setMaintenanceLog(prev => prev.filter(entry => entry.id !== id));
  };

  const handleAmenityChange = (amenity: string) => {
    setFormData(prev => {
      const newAmenities = prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity];
      return { ...prev, amenities: newAmenities };
    });
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || formData.maxCapacity <=0 || formData.pricePerNight < 0) {
        alert("Nombre de la propiedad, capacidad máxima (mayor a 0) y precio por noche (no negativo) son obligatorios.");
        return;
    }
    // If status is set to LIMPIA or INSPECCIONADA and lastCleanedDate is not set or different from today, update it.
    let updatedLastCleanedDate = formData.lastCleanedDate;
    if ((formData.currentCleaningStatus === RoomCleaningStatus.LIMPIA || formData.currentCleaningStatus === RoomCleaningStatus.INSPECCIONADA)) {
        const todayISO = new Date().toISOString().split('T')[0];
        if (formData.lastCleanedDate !== todayISO) {
            updatedLastCleanedDate = todayISO;
        }
    }

    onSave({ 
        id: initialData?.id, 
        ...formData, 
        maintenanceLog,
        lastCleanedDate: updatedLastCleanedDate 
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <TextInput label="Nombre de la Propiedad*" name="name" value={formData.name} onChange={handleChange} required />
          <TextareaInput label="Descripción" name="description" value={formData.description} onChange={handleChange} rows={4} />
          <TextInput label="Configuración de Camas" name="bedConfiguration" value={formData.bedConfiguration} onChange={handleChange} placeholder="Ej: 1 Queen, 2 Twin"/>
        </div>
        <div>
          <TextInput label="Capacidad Máxima*" name="maxCapacity" type="number" value={formData.maxCapacity.toString()} onChange={handleChange} min="1" required />
          <TextInput label="Precio por Noche ($)*" name="pricePerNight" type="number" value={formData.pricePerNight.toString()} onChange={handleChange} min="0" step="0.01" required />
          <SelectInput
            label="Color para Calendario*"
            name="calendarColor"
            value={formData.calendarColor}
            onChange={handleChange}
            options={colorOptions.map(c => ({ value: c.class, label: c.name }))}
            required
          />
           <div className={`mt-2 p-3 rounded text-center font-semibold ${formData.calendarColor}`}>Color de Muestra</div>
           <SelectInput
            label="Estado de Limpieza Actual*"
            name="currentCleaningStatus"
            value={formData.currentCleaningStatus}
            onChange={handleChange}
            options={ROOM_CLEANING_STATUS_OPTIONS}
            required
            containerClassName="mt-4"
          />
        </div>
      </div>

      <div>
        <h4 className="text-md font-semibold text-muted-foreground mb-2">Amenidades</h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 p-3 border border-border-color rounded bg-background">
          {AMENITY_OPTIONS.map(amenity => (
            <label key={amenity} className="flex items-center space-x-2 text-sm cursor-pointer hover:text-primary">
              <input
                type="checkbox"
                checked={formData.amenities.includes(amenity)}
                onChange={() => handleAmenityChange(amenity)}
                className="form-checkbox h-4 w-4 text-primary rounded focus:ring-primary"
              />
              <span>{amenity}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-md font-semibold text-muted-foreground mb-1">Galería de Fotos</h4>
        <label htmlFor="photoUpload" className="inline-flex items-center px-4 py-2 bg-primary/10 text-primary text-sm font-medium rounded-md cursor-pointer hover:bg-primary/20 transition-colors">
            <Icon name="upload" className="w-4 h-4 mr-2"/>
            Subir Fotos
        </label>
        <input 
            id="photoUpload"
            type="file" 
            multiple 
            accept="image/*" 
            onChange={handlePhotoUpload} 
            className="hidden"
        />
        
        {formData.photoUrls.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mt-3 max-h-60 overflow-y-auto p-2 border border-border-color rounded bg-background">
            {formData.photoUrls.map((url, index) => (
                <div key={index} className="relative group aspect-w-1 aspect-h-1">
                <img src={url} alt={`Foto ${index + 1}`} className="w-full h-full object-cover rounded shadow-md"/>
                <button 
                    type="button" 
                    onClick={() => handleRemovePhotoUrl(url)}
                    className="absolute top-1 right-1 bg-danger/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-danger focus:opacity-100"
                    aria-label={`Eliminar foto ${index+1}`}
                >
                    <Icon name="xMark" className="w-3 h-3"/>
                </button>
                </div>
            ))}
            </div>
        )}
      </div>
      
      {initialData && (
        <div>
            <h4 className="text-md font-semibold text-muted-foreground mb-2">Historial de Mantenimiento</h4>
            <div className="space-y-3 max-h-60 overflow-y-auto p-3 border border-border-color rounded mb-3 bg-background">
                {maintenanceLog.length > 0 ? maintenanceLog.map(log => (
                    <div key={log.id} className="p-3 bg-surface rounded shadow text-sm flex justify-between items-start">
                        <div>
                            <p><strong>Fecha:</strong> {new Date(log.date).toLocaleDateString()}</p>
                            <p className="whitespace-pre-wrap"><strong>Descripción:</strong> {log.description}</p>
                            {log.cost !== undefined && <p><strong>Costo:</strong> ${log.cost.toFixed(2)}</p>}
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={() => handleRemoveLogEntry(log.id)} className="text-danger" aria-label="Eliminar registro de mantenimiento">
                            <Icon name="trash" className="w-4 h-4"/>
                        </Button>
                    </div>
                )) : <p className="text-muted-foreground text-sm italic">No hay registros de mantenimiento.</p>}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end p-4 border border-border-color rounded bg-background">
                <DateInput label="Fecha Log*" name="date" value={newLogEntry.date} onChange={handleLogChange} containerClassName="mb-0"/>
                <TextareaInput label="Descripción Log*" name="description" value={newLogEntry.description} onChange={handleLogChange} containerClassName="mb-0" rows={2}/>
                <div className="flex space-x-2 items-end sm:col-span-3 md:col-span-1">
                     <TextInput label="Costo Log ($)" type="number" name="cost" value={newLogEntry.cost?.toString() || ''} onChange={handleLogChange} containerClassName="mb-0 flex-grow" placeholder="Opcional" step="0.01"/>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddLogEntry} leftIcon={<Icon name="plus" className="w-4 h-4"/>} className="self-end mb-px">Añadir Log</Button>
                </div>
            </div>
        </div>
      )}

      <div className="flex justify-end space-x-3 pt-6">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {initialData ? 'Actualizar Propiedad' : 'Crear Propiedad'}
        </Button>
      </div>
    </form>
  );
};

export default PropertyForm;
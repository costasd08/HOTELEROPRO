import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { MenuItem, MenuItemCostAnalysis, AppSettings, InventoryItem, RecipeIngredient } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';

interface MenuItemCostReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  menuItem: MenuItem;
  costAnalysis: MenuItemCostAnalysis;
  appSettings: AppSettings;
  inventoryItems: InventoryItem[];
}

const formatDate = (dateString: string | undefined): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }).replace('.', '');
};

const MenuItemCostReceiptModal: React.FC<MenuItemCostReceiptModalProps> = ({
  isOpen,
  onClose,
  menuItem,
  costAnalysis,
  appSettings,
  inventoryItems,
}) => {
  const receiptContentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadImage = async () => {
    if (!receiptContentRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(receiptContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        onclone: (document) => {
            // Hide buttons for capture
            const elementsToHide = document.querySelectorAll('.hide-on-capture');
            elementsToHide.forEach(el => (el as HTMLElement).style.display = 'none');
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `ficha_costo_${menuItem.name.replace(/\s+/g, '_')}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating cost receipt image:", error);
      alert("Hubo un error al generar la imagen de la ficha de costo.");
    } finally {
      setIsDownloading(false);
    }
  };
  
  const getIngredientName = (ingredient: RecipeIngredient): string => {
    if (ingredient.manualIngredientName) return ingredient.manualIngredientName;
    const inventoryItem = inventoryItems.find(item => item.id === ingredient.inventoryItemId);
    return inventoryItem?.name || 'Ingrediente Desconocido';
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Ficha de Costo: ${menuItem.name}`}
      size="lg" // Adjusted size
      footer={
        <div className="flex justify-between w-full items-center hide-on-capture">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cerrar
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleDownloadImage}
            leftIcon={<Icon name="image" className="w-4 h-4" />}
            isLoading={isDownloading}
            disabled={isDownloading}
          >
            {isDownloading ? 'Descargando...' : 'Descargar Imagen'}
          </Button>
        </div>
      }
    >
      <div ref={receiptContentRef} className="printable-cost-receipt bg-surface p-4 sm:p-6 text-sm">
        <header className="text-center mb-4 border-b-2 border-primary pb-3">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-16 mx-auto mb-2 object-contain" />
          )}
          <h1 className="text-xl font-bold text-primary">{appSettings.appName}</h1>
          <p className="text-md font-semibold text-foreground">FICHA DE COSTO DE PLATILLO</p>
          <p className="text-xs text-muted-foreground">Generado: {new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}</p>
        </header>

        <section className="mb-4 text-center">
          {menuItem.photoUrl && (
            <img src={menuItem.photoUrl} alt={menuItem.name} className="w-40 h-32 object-cover rounded-md mx-auto mb-2 shadow-md" />
          )}
          <h2 className="text-lg font-bold text-accent">{menuItem.name}</h2>
          <p className="text-xs text-muted-foreground">Categoría: {menuItem.category}</p>
        </section>

        {/* Cost Breakdown Sections */}
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-muted-foreground border-b border-border-color mb-1">Ingredientes Directos (Materia Prima)</h3>
            {costAnalysis.recipeIngredients.length > 0 ? (
              <table className="w-full text-xs mb-1">
                <thead>
                  <tr className="text-left text-muted-foreground">
                    <th>Ingrediente</th>
                    <th className="text-center">Cant.</th>
                    <th className="text-right">Costo/U</th>
                    <th className="text-center">Rend.</th>
                    <th className="text-right">Costo Calc.</th>
                  </tr>
                </thead>
                <tbody>
                  {costAnalysis.recipeIngredients.map(ing => (
                    <tr key={ing.id} className="border-b border-border-color/50">
                      <td className="py-0.5 truncate" title={getIngredientName(ing)}>{getIngredientName(ing)}</td>
                      <td className="py-0.5 text-center">{ing.quantityInRecipe} {ing.unitInRecipe}</td>
                      <td className="py-0.5 text-right">${ing.costPerRecipeUnit.toFixed(2)}</td>
                      <td className="py-0.5 text-center">{(ing.yieldFactor * 100).toFixed(0)}%</td>
                      <td className="py-0.5 text-right font-medium">${ing.calculatedCost.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : <p className="text-xs text-muted-foreground italic">No hay ingredientes detallados.</p>}
            <p className="text-xs text-right font-semibold">Total Ingredientes: ${costAnalysis.calculatedDirectMaterialCost?.toFixed(2) || '0.00'}</p>
          </div>

          <div>
            <h3 className="font-semibold text-muted-foreground border-b border-border-color mb-1">Mano de Obra Directa</h3>
            <div className="flex justify-between text-xs">
              <span>Tiempo: {costAnalysis.directLaborTimeMinutes} min @ ${costAnalysis.directLaborHourlyRate.toFixed(2)}/hr</span>
              <span className="font-semibold">Total Mano de Obra: ${costAnalysis.calculatedDirectLaborCost?.toFixed(2) || '0.00'}</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-muted-foreground border-b border-border-color mb-1">Costos Indirectos de Fabricación (CIF)</h3>
            <div className="flex justify-between text-xs">
              <span>Tasa Aplicada: {(costAnalysis.kitchenOverheadRate * 100).toFixed(1)}%</span>
              <span className="font-semibold">Total CIF: ${costAnalysis.calculatedKitchenOverheadCost?.toFixed(2) || '0.00'}</span>
            </div>
          </div>

          <p className="text-right font-bold text-md text-primary border-t border-primary pt-1">
            COSTO TOTAL DE PRODUCCIÓN: ${costAnalysis.totalProductionCost?.toFixed(2) || '0.00'}
          </p>

           <div>
            <h3 className="font-semibold text-muted-foreground border-b border-border-color mb-1">Gastos Administrativos y de Venta (GAV)</h3>
            <div className="flex justify-between text-xs">
              <span>Tasa Aplicada: {(costAnalysis.adminSalesOverheadRate * 100).toFixed(1)}%</span>
              <span className="font-semibold">Total GAV: ${costAnalysis.calculatedAdminSalesCost?.toFixed(2) || '0.00'}</span>
            </div>
          </div>
           <p className="text-right font-bold text-md text-accent border-t border-accent pt-1">
            COSTO TOTAL (ANTES DE GANANCIA): ${costAnalysis.totalCostBeforeProfit?.toFixed(2) || '0.00'}
          </p>
        </div>

        <section className="mt-3 pt-2 border-t-2 border-primary">
          <h3 className="text-md font-bold text-center text-foreground mb-1">PRECIO DE VENTA SUGERIDO</h3>
          <div className="text-center">
            <p className="text-xs">Margen de Ganancia Deseado: <span className="font-semibold">{(costAnalysis.desiredProfitMarginRate * 100).toFixed(1)}%</span> (Monto: <span className="font-semibold">${costAnalysis.calculatedProfitAmount?.toFixed(2) || '0.00'}</span>)</p>
            <p className="text-xl font-extrabold text-success mt-1">${costAnalysis.suggestedSellingPrice?.toFixed(2) || '0.00'}</p>
          </div>
           <div className="text-xs text-center mt-1 text-muted-foreground">
            <span>Precio Actual: ${menuItem.sellingPrice.toFixed(2)}</span>
            <span className="mx-1">|</span>
            <span className={((costAnalysis.suggestedSellingPrice || 0) - menuItem.sellingPrice) >= 0 ? 'text-success' : 'text-danger'}>
                Varianza: ${(((costAnalysis.suggestedSellingPrice || 0) - menuItem.sellingPrice)).toFixed(2)}
            </span>
          </div>
        </section>
        
        {costAnalysis.notes && (
            <section className="mt-3 pt-2 border-t border-border-color">
                <h4 className="text-xs font-semibold text-muted-foreground mb-0.5">Notas del Análisis:</h4>
                <p className="text-xs text-muted-foreground italic whitespace-pre-line">{costAnalysis.notes}</p>
            </section>
        )}

        <footer className="text-center text-xs text-muted-foreground pt-3 mt-3 border-t border-border-color">
          <p>Análisis calculado el: {formatDate(costAnalysis.lastCalculated)}</p>
          <p>{appSettings.appName}{appSettings.responsiblePerson ? ` - Responsable: ${appSettings.responsiblePerson}` : ''}</p>
        </footer>
      </div>
       <style>{`
        @media print { 
          .hide-on-capture { display: none !important; }
          body * { visibility: hidden; }
          .printable-cost-receipt, .printable-cost-receipt * { visibility: visible; }
          .printable-cost-receipt { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 15px !important; font-size: 9pt; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>
    </Modal>
  );
};

export default MenuItemCostReceiptModal;
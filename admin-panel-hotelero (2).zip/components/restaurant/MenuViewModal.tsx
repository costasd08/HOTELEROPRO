import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { MenuItem, MenuItemCategory, AppSettings } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';

interface MenuViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  menuItems: MenuItem[]; // Expect pre-filtered (isAvailable: true) items
  appSettings: AppSettings;
}

const MenuViewModal: React.FC<MenuViewModalProps> = ({ isOpen, onClose, menuItems, appSettings }) => {
  const menuContentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const groupedMenuItems = menuItems.reduce((acc, item) => {
    const category = item.category || MenuItemCategory.OTRO;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {} as Record<MenuItemCategory, MenuItem[]>);

  // Order categories for display
  const orderedCategories = Object.values(MenuItemCategory).filter(cat => groupedMenuItems[cat] && groupedMenuItems[cat].length > 0);


  const handleDownloadImage = async () => {
    if (!menuContentRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(menuContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff', // Explicit background for capture
        onclone: (document) => {
          // You can hide elements for capture if needed, like scrollbars
          // For example, if the content itself has a specific scrollbar
          const contentElement = document.querySelector('.menu-content-for-capture');
          if (contentElement) {
             // (contentElement as HTMLElement).style.overflow = 'visible'; // May help capture all content
          }
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `menu_${appSettings.appName.replace(/\s+/g, '_') || 'restaurante'}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating menu image:", error);
      alert("Hubo un error al generar la imagen del menú.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Menú del Restaurante"
      size="xl" // Larger modal for menu view
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} className="mr-auto">
            Cerrar
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleDownloadImage}
            leftIcon={<Icon name="download" className="w-4 h-4" />}
            isLoading={isDownloading}
            disabled={isDownloading}
          >
            {isDownloading ? 'Descargando...' : 'Descargar Menú'}
          </Button>
        </>
      }
    >
      <div ref={menuContentRef} className="printable-menu-area bg-surface p-4 sm:p-6 menu-content-for-capture">
        <header className="text-center mb-6 border-b-2 border-primary pb-4">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-24 mx-auto mb-3 object-contain" />
          )}
          <h1 className="text-3xl font-bold text-primary">{appSettings.appName}</h1>
          <p className="text-lg text-muted-foreground">Nuestro Menú</p>
          {appSettings.phone && <p className="text-sm text-muted-foreground">Tel: {appSettings.phone}</p>}
        </header>

        <div className="space-y-8">
          {orderedCategories.map(category => (
            <section key={category}>
              <h2 className="text-2xl font-semibold text-accent mb-3 border-b border-accent/50 pb-1 capitalize">{category}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                {groupedMenuItems[category].map(item => (
                  <div key={item.id} className="py-2">
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-lg font-medium text-foreground">{item.name}</h3>
                      <p className="text-lg font-semibold text-primary">${item.sellingPrice.toFixed(2)}</p>
                    </div>
                    {item.description && (
                      <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <footer className="text-center text-xs text-muted-foreground pt-8 mt-8 border-t border-border-color">
          <p>Precios en MXN. IVA incluido. ¡Buen provecho!</p>
          {appSettings.responsiblePerson && <p>Atendido por: {appSettings.responsiblePerson}</p>}
        </footer>
      </div>
      <style>{`
        @media print { /* Basic print styles, can be expanded */
          body * { visibility: hidden; }
          .printable-menu-area, .printable-menu-area * { visibility: visible; }
          .printable-menu-area { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 20px !important; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .modal-footer-print-hidden { display: none !important; } /* Hides modal footer on print */
        }
      `}</style>
    </Modal>
  );
};

export default MenuViewModal;
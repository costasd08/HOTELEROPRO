import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { RestaurantReportSummary, AppSettings } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import { APP_NAME, APP_SETTINGS_KEY } from '../../constants';

interface RestaurantReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: RestaurantReportSummary;
}

const formatDateToDMesAño = (dateString: string): string => {
  const dateObj = dateString.includes('T') ? new Date(dateString) : new Date(dateString + 'T00:00:00');
  if (isNaN(dateObj.getTime())) return "Fecha Inválida";
  const day = dateObj.getDate();
  const month = dateObj.toLocaleDateString('es-ES', { month: 'short' }).replace('.', '');
  const year = dateObj.getFullYear();
  return `${day}/${month}/${year}`;
};

const RestaurantReportModal: React.FC<RestaurantReportModalProps> = ({ isOpen, onClose, summary }) => {
  const reportContentRef = useRef<HTMLDivElement>(null);
  const [isDownloadingImage, setIsDownloadingImage] = useState(false);

  let appSettings: AppSettings = { 
    appName: APP_NAME, 
    logoUrl: '', 
    hotelEmail: '', 
    responsiblePerson: '', 
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
    defaultCheckInTime: '14:00',
    defaultCheckOutTime: '12:00',
    reservationPolicies: '',
    cancellationPolicies: '',
    generalObservations: '',
    otherPolicies: '',
  };
  try {
    const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
    if (settingsStr) {
      const parsed = JSON.parse(settingsStr);
      appSettings = { ...appSettings, ...parsed };
    }
  } catch (e) { /* ignore */ }
  
  const reportTitle = `Reporte de Ventas del Restaurante - ${summary.periodTypeLabel}`;

  const handlePrint = () => { window.print(); };

  const handleDownloadImage = async () => {
    if (!reportContentRef.current) return;
    setIsDownloadingImage(true);
    try {
      const canvas = await html2canvas(reportContentRef.current, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `reporte_restaurante_${formatDateToDMesAño(summary.startDate).replace(/\//g, '-')}_${formatDateToDMesAño(summary.endDate).replace(/\//g, '-')}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating image:", error);
      alert("Hubo un error al generar la imagen del reporte.");
    } finally {
      setIsDownloadingImage(false);
    }
  };
  
  const summaryItems = [
    { label: "Total Órdenes Pagadas", value: summary.totalOrders, color: "text-primary" },
    { label: "Ingresos Totales", value: `$${summary.totalRevenue.toFixed(2)}`, color: "text-success" },
    { label: "Costo de Producción Estimado", value: `$${summary.totalProductionCost.toFixed(2)}`, color: "text-warning" },
    { label: "Ganancia Neta Estimada", value: `$${summary.netProfit.toFixed(2)}`, color: summary.netProfit >= 0 ? "text-success" : "text-danger", isBold: true },
    { label: "Valor Promedio por Orden", value: `$${summary.averageOrderValue.toFixed(2)}`, color: "text-accent" },
    { label: "Platillo Más Vendido", value: summary.mostSoldItem ? `${summary.mostSoldItem.name} (${summary.mostSoldItem.quantity} uds)` : 'N/A', color: "text-info" },
  ];


  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Vista Previa del Reporte de Restaurante" size="lg" footer={
      <>
        <Button variant="outline" size="sm" onClick={onClose} className="mr-auto">Cerrar</Button>
        <Button variant="secondary" size="sm" onClick={handleDownloadImage} leftIcon={<Icon name="image" />} isLoading={isDownloadingImage} disabled={isDownloadingImage} className="mr-2">
            {isDownloadingImage ? 'Generando...' : 'Descargar Imagen'}
        </Button>
        <Button variant="primary" size="sm" onClick={handlePrint} leftIcon={<Icon name="download" />}>
            Imprimir/PDF
        </Button>
      </>
    }>
      <div ref={reportContentRef} className="printable-report-area space-y-6 bg-surface p-4 sm:p-6">
        <header className="text-center mb-6 print:mb-4">
          {appSettings.logoUrl && <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-20 mx-auto mb-3 object-contain print:max-h-16"/>}
          {appSettings.reportCustomHeaderText && <p className="text-sm text-muted-foreground mb-2 print:text-xs whitespace-pre-line">{appSettings.reportCustomHeaderText}</p>}
          <h2 className="text-2xl font-bold text-primary print:text-xl">{appSettings.appName}</h2>
          <h3 className="text-xl font-semibold text-foreground print:text-lg">{reportTitle}</h3>
          {appSettings.responsiblePerson && (
            <p className="text-sm text-muted-foreground mt-1 print:text-xs">Responsable: {appSettings.responsiblePerson}</p>
          )}
          <p className="text-sm text-muted-foreground print:text-xs">Periodo: {formatDateToDMesAño(summary.startDate)} al {formatDateToDMesAño(summary.endDate)}</p>
          <p className="text-sm text-muted-foreground print:text-xs">Generado el: {formatDateToDMesAño(summary.generatedAt)}</p>
        </header>

        <section className="p-4 bg-background rounded-lg shadow print:shadow-none print:p-0">
          <h4 className="text-lg font-semibold text-foreground mb-3 print:text-base">Resumen del Restaurante</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {summaryItems.map(item => (
              <div key={item.label} className="p-3 bg-surface rounded shadow print:border print:border-border-color">
                <p className="text-sm text-muted-foreground">{item.label}:</p>
                <p className={`text-xl ${item.isBold ? 'font-bold' : 'font-semibold'} ${item.color} print:text-lg`}>{item.value}</p>
              </div>
            ))}
          </div>
        </section>
        
        <footer className="text-center text-xs text-muted-foreground pt-6 border-t border-border-color mt-6 print:mt-4 print:pt-2">
            {appSettings.reportCustomFooterText && <p className="mb-2 print:mb-1 whitespace-pre-line">{appSettings.reportCustomFooterText}</p>}
            Reporte generado por {appSettings.appName}.
            {appSettings.phone && <span className="print:block"> Contacto: {appSettings.phone}</span>}
            {appSettings.hotelEmail && <span className="print:block"> Email: {appSettings.hotelEmail}</span>}
        </footer>
      </div>
      <style>{`
          @media print {
            body * { visibility: hidden; }
            .printable-report-area, .printable-report-area * { visibility: visible; }
            .printable-report-area { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 20px !important; font-size: 10pt; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .bg-surface { background-color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .text-primary { color: hsl(215, 60%, 50%) !important; } .text-success { color: hsl(145, 63%, 42%) !important; }
            .text-danger { color: hsl(0, 72%, 51%) !important; } .text-warning { color: hsl(45, 100%, 51%) !important; }
            .text-info { color: hsl(190, 70%, 55%) !important; } .text-accent { color: hsl(210, 65%, 60%) !important; }
            .text-foreground { color: hsl(220, 25%, 25%) !important; } .text-muted-foreground { color: hsl(220, 15%, 55%) !important; }
            .border-border-color { border-color: hsl(220, 20%, 85%) !important; } .bg-background { background-color: hsl(220, 60%, 96%) !important; }
            .shadow, .shadow-md, .shadow-lg { box-shadow: none !important; }
            .print\\:text-xs { font-size: 0.7rem !important; } .print\\:text-lg { font-size: 1rem !important; } .print\\:text-xl { font-size: 1.2rem !important; }
            .print\\:max-h-16 { max-height: 4rem !important; } .print\\:p-0 { padding: 0 !important; } .print\\:border { border-width: 1px !important; }
            .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area, .fixed.inset-0 > div > div:nth-child(2) > .printable-report-area * { visibility: visible !important; }
            .fixed.inset-0 > div > div:first-child button { display: none !important; }
            .whitespace-pre-line { white-space: pre-line !important; }
          }
      `}</style>
    </Modal>
  );
};

export default RestaurantReportModal;
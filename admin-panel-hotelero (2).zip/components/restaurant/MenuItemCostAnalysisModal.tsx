
import React, { useState, useEffect, useCallback } from 'react';
// import html2canvas from 'html2canvas'; // Removed
import { MenuItem, MenuItemCostAnalysis, RecipeIngredient, InventoryItem, AppSettings } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Card from '../common/Card';
import { RECIPE_UNIT_OPTIONS } from '../../constants';

interface MenuItemCostAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  menuItem: MenuItem;
  initialAnalysisData: MenuItemCostAnalysis | null;
  inventoryItems: InventoryItem[];
  appSettings: AppSettings;
  onSave: (analysisData: MenuItemCostAnalysis) => void;
}

const MenuItemCostAnalysisModal: React.FC<MenuItemCostAnalysisModalProps> = ({
  isOpen,
  onClose,
  menuItem,
  initialAnalysisData,
  inventoryItems,
  appSettings,
  onSave,
}) => {
  // const analysisReportRef = useRef<HTMLFormElement>(null); // Removed
  // const [isDownloadingReportImage, setIsDownloadingReportImage] = useState(false); // Removed

  const [analysisData, setAnalysisData] = useState<MenuItemCostAnalysis>(() => {
    const defaults: MenuItemCostAnalysis = {
      id: menuItem.id, 
      menuItemId: menuItem.id,
      recipeIngredients: [],
      directLaborTimeMinutes: 0,
      directLaborHourlyRate: 0,
      kitchenOverheadRate: appSettings.defaultKitchenOverheadRate || 0.10, 
      adminSalesOverheadRate: appSettings.defaultAdminSalesOverheadRate || 0.15, 
      desiredProfitMarginRate: 0.30, 
      lastCalculated: new Date().toISOString(),
    };
    return initialAnalysisData ? { ...defaults, ...initialAnalysisData } : defaults;
  });

  const [newIngredientInventoryId, setNewIngredientInventoryId] = useState<string>('');
  const [newIngredientManualName, setNewIngredientManualName] = useState<string>('');
  const [newIngredientQuantity, setNewIngredientQuantity] = useState<number>(0);
  const [newIngredientUnit, setNewIngredientUnit] = useState<string>(RECIPE_UNIT_OPTIONS[0]?.value || 'g');
  const [newIngredientCostPerUnit, setNewIngredientCostPerUnit] = useState<number>(0);
  const [newIngredientYield, setNewIngredientYield] = useState<number>(1);


  const calculateCosts = useCallback(() => {
    const materialCost = analysisData.recipeIngredients.reduce((sum, ing) => sum + ing.calculatedCost, 0);
    const laborCost = (analysisData.directLaborTimeMinutes / 60) * analysisData.directLaborHourlyRate;
    const kitchenOverhead = (materialCost + laborCost) * analysisData.kitchenOverheadRate;
    const productionCost = materialCost + laborCost + kitchenOverhead;
    const adminSalesCost = productionCost * analysisData.adminSalesOverheadRate;
    const costBeforeProfit = productionCost + adminSalesCost;
    const profitAmount = costBeforeProfit * analysisData.desiredProfitMarginRate;
    const suggestedPrice = costBeforeProfit + profitAmount;

    setAnalysisData(prev => ({
      ...prev,
      calculatedDirectMaterialCost: materialCost,
      calculatedDirectLaborCost: laborCost,
      calculatedKitchenOverheadCost: kitchenOverhead,
      totalProductionCost: productionCost,
      calculatedAdminSalesCost: adminSalesCost,
      totalCostBeforeProfit: costBeforeProfit,
      calculatedProfitAmount: profitAmount,
      suggestedSellingPrice: suggestedPrice,
      lastCalculated: new Date().toISOString(),
    }));

  }, [analysisData.recipeIngredients, analysisData.directLaborTimeMinutes, analysisData.directLaborHourlyRate, analysisData.kitchenOverheadRate, analysisData.adminSalesOverheadRate, analysisData.desiredProfitMarginRate]);

  useEffect(() => {
    calculateCosts();
  }, [calculateCosts]); 

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let numericValue = parseFloat(value);
    
    if (name === 'kitchenOverheadRate' || name === 'adminSalesOverheadRate' || name === 'desiredProfitMarginRate') {
        numericValue = (parseFloat(value) || 0) / 100;
         setAnalysisData(prev => ({ ...prev, [name]: numericValue }));
    } else {
        setAnalysisData(prev => ({
        ...prev,
        [name]: (name === 'directLaborTimeMinutes' || name === 'directLaborHourlyRate') ? (parseFloat(value) || 0) : value,
        }));
    }
  };

  const handleAddRecipeIngredient = () => {
    if ((!newIngredientInventoryId && !newIngredientManualName) || newIngredientQuantity <= 0 || newIngredientCostPerUnit <= 0 || newIngredientYield <= 0) {
        alert("Por favor, complete los campos del ingrediente (nombre o item de inventario, cantidad, costo/unidad y rendimiento).");
        return;
    }
    
    const calculatedIngredientCost = (newIngredientCostPerUnit / newIngredientYield) * newIngredientQuantity;

    const newIngredient: RecipeIngredient = {
        id: `recipe-ing-${Date.now()}`,
        inventoryItemId: newIngredientInventoryId || undefined,
        manualIngredientName: newIngredientInventoryId ? undefined : newIngredientManualName,
        quantityInRecipe: newIngredientQuantity,
        unitInRecipe: newIngredientUnit,
        costPerRecipeUnit: newIngredientCostPerUnit,
        yieldFactor: newIngredientYield,
        calculatedCost: calculatedIngredientCost,
    };

    setAnalysisData(prev => ({
        ...prev,
        recipeIngredients: [...prev.recipeIngredients, newIngredient],
    }));

    setNewIngredientInventoryId('');
    setNewIngredientManualName('');
    setNewIngredientQuantity(0);
    setNewIngredientUnit(RECIPE_UNIT_OPTIONS[0]?.value || 'g');
    setNewIngredientCostPerUnit(0);
    setNewIngredientYield(1);
  };

  const handleRemoveRecipeIngredient = (ingredientId: string) => {
    setAnalysisData(prev => ({
        ...prev,
        recipeIngredients: prev.recipeIngredients.filter(ing => ing.id !== ingredientId),
    }));
  };
  
  useEffect(() => {
    if (newIngredientInventoryId) {
        const item = inventoryItems.find(i => i.id === newIngredientInventoryId);
        if (item) {
            setNewIngredientManualName(item.name); 
            if (item.purchasePrice && item.unit) {
                const recipeUnitOption = RECIPE_UNIT_OPTIONS.find(opt => opt.value === item.unit);
                if (recipeUnitOption) {
                    setNewIngredientUnit(item.unit);
                    setNewIngredientCostPerUnit(item.purchasePrice);
                } else {
                    setNewIngredientCostPerUnit(0); 
                }
            }
        }
    }
  }, [newIngredientInventoryId, inventoryItems]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(analysisData);
  };

  // handleDownloadReportImage function removed
  
  const inventoryItemOptions = [{value: '', label: 'Seleccionar de Inventario...'}, ...inventoryItems.map(item => ({ value: item.id, label: `${item.name} (${item.quantity} ${item.unit} en stock)`}))];

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title={`Análisis de Costo: ${menuItem.name}`} 
      size="xl"
      footer={
        <div className="flex justify-end w-full items-center"> {/* Changed justify-between to justify-end */}
            {/* Download button removed */}
            <div>
                <Button type="button" variant="ghost" onClick={onClose} className="mr-2">
                    Cerrar
                </Button>
                <Button type="submit" form="costAnalysisForm" variant="primary" leftIcon={<Icon name="check"/>}>
                    Guardar Análisis
                </Button>
            </div>
        </div>
      }
    >
      {/* Assigning ref to form instead of div. Form id "costAnalysisForm" used for submit button. */}
      <form id="costAnalysisForm" onSubmit={handleSubmit} className="space-y-6 bg-surface p-1 printable-cost-analysis-area">
        
        <Card title="1. Ingredientes Directos (Materia Prima)">
          <div className="space-y-4 max-h-72 overflow-y-auto mb-4 p-2 border border-border-color rounded-md">
            {analysisData.recipeIngredients.length > 0 ? (
              analysisData.recipeIngredients.map(ing => (
                <div key={ing.id} className="grid grid-cols-6 gap-2 items-center text-sm p-2 bg-background rounded">
                  <span className="col-span-2 truncate" title={ing.manualIngredientName || inventoryItems.find(i=>i.id===ing.inventoryItemId)?.name}>{ing.manualIngredientName || inventoryItems.find(i=>i.id===ing.inventoryItemId)?.name}</span>
                  <span>{ing.quantityInRecipe} {ing.unitInRecipe}</span>
                  <span>${ing.costPerRecipeUnit.toFixed(2)}</span>
                  <span>{(ing.yieldFactor * 100).toFixed(0)}%</span>
                  <div className="flex justify-between items-center">
                    <span>${ing.calculatedCost.toFixed(2)}</span>
                    <Button type="button" variant="ghost" size="sm" onClick={() => handleRemoveRecipeIngredient(ing.id)} className="text-danger p-1">
                        <Icon name="xMark" className="w-3 h-3"/>
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground italic text-center py-4">No hay ingredientes añadidos.</p>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 border border-accent/30 rounded-md">
            <SelectInput label="Ingrediente de Inventario" options={inventoryItemOptions} value={newIngredientInventoryId} onChange={e => { setNewIngredientInventoryId(e.target.value); if(e.target.value) setNewIngredientManualName('');}} containerClassName="mb-0"/>
            <TextInput label="O Nombre Manual" placeholder="Si no está en inventario" value={newIngredientManualName} onChange={e => { setNewIngredientManualName(e.target.value); if(e.target.value) setNewIngredientInventoryId(''); }} containerClassName="mb-0" disabled={!!newIngredientInventoryId}/>
            <TextInput label="Cantidad (Receta)*" type="number" value={newIngredientQuantity.toString()} onChange={e => setNewIngredientQuantity(parseFloat(e.target.value) || 0)} min="0.001" step="any" containerClassName="mb-0"/>
            <SelectInput label="Unidad (Receta)*" options={RECIPE_UNIT_OPTIONS} value={newIngredientUnit} onChange={e => setNewIngredientUnit(e.target.value)} containerClassName="mb-0"/>
            <TextInput label="Costo/Unidad (Receta)*" type="number" placeholder="Costo por la unidad de receta" value={newIngredientCostPerUnit.toString()} onChange={e => setNewIngredientCostPerUnit(parseFloat(e.target.value) || 0)} min="0" step="any" containerClassName="mb-0"/>
            <TextInput label="Rendimiento (%)*" type="number" value={(newIngredientYield * 100).toString()} onChange={e => setNewIngredientYield((parseFloat(e.target.value) || 100) / 100)} min="1" max="100" step="1" containerClassName="mb-0"/>
            <Button type="button" onClick={handleAddRecipeIngredient} leftIcon={<Icon name="plus"/>} variant="outline" className="md:col-span-3 mt-2">Añadir Ingrediente</Button>
          </div>
          <p className="text-right font-semibold mt-3">Costo Total de Ingredientes: ${analysisData.calculatedDirectMaterialCost?.toFixed(2) || '0.00'}</p>
        </Card>

        <Card title="2. Mano de Obra Directa">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <TextInput
              label="Tiempo Total de Preparación (minutos)"
              name="directLaborTimeMinutes"
              type="number"
              value={analysisData.directLaborTimeMinutes.toString()}
              onChange={handleInputChange}
              min="0"
            />
            <TextInput
              label="Costo Promedio Hora Personal Cocina ($)"
              name="directLaborHourlyRate"
              type="number"
              value={analysisData.directLaborHourlyRate.toString()}
              onChange={handleInputChange}
              min="0"
              step="0.01"
            />
          </div>
          <p className="text-right font-semibold mt-3">Costo Total de Mano de Obra Directa: ${analysisData.calculatedDirectLaborCost?.toFixed(2) || '0.00'}</p>
        </Card>

        <Card title="3. Costos Indirectos y Administrativos">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <TextInput
              label="Tasa Gastos Generales Cocina (%)"
              name="kitchenOverheadRate"
              type="number"
              value={(analysisData.kitchenOverheadRate * 100).toString()}
              onChange={handleInputChange}
              min="0"
              step="0.1"
              helperText={`Predeterminado: ${(appSettings.defaultKitchenOverheadRate || 0.1) * 100}%`}
            />
            <p className="text-sm text-muted-foreground md:mt-8">Costo Indirecto Cocina Calculado: <span className="font-semibold">${analysisData.calculatedKitchenOverheadCost?.toFixed(2) || '0.00'}</span></p>
          </div>
          <p className="text-right font-semibold my-2 text-primary">Costo Total de Producción (A+B+Indirecto Cocina): ${analysisData.totalProductionCost?.toFixed(2) || '0.00'}</p>
          <hr className="my-3"/>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <TextInput
              label="Tasa Gastos Admin. y Ventas (%)"
              name="adminSalesOverheadRate"
              type="number"
              value={(analysisData.adminSalesOverheadRate * 100).toString()}
              onChange={handleInputChange}
              min="0"
              step="0.1"
              helperText={`Predeterminado: ${(appSettings.defaultAdminSalesOverheadRate || 0.15) * 100}%`}
            />
            <p className="text-sm text-muted-foreground md:mt-8">Costo Admin/Ventas Calculado: <span className="font-semibold">${analysisData.calculatedAdminSalesCost?.toFixed(2) || '0.00'}</span></p>
          </div>
        </Card>

        <Card title="4. Resumen y Precio de Venta Sugerido" className="bg-primary/5">
          <p className="font-semibold">Costo Total Antes de Ganancia: <span className="text-lg">${analysisData.totalCostBeforeProfit?.toFixed(2) || '0.00'}</span></p>
          <TextInput
            label="Margen de Ganancia Deseado (%)"
            name="desiredProfitMarginRate"
            type="number"
            value={(analysisData.desiredProfitMarginRate * 100).toString()}
            onChange={handleInputChange}
            min="0"
            step="1"
            containerClassName="my-3"
          />
          <p className="font-semibold">Monto de Ganancia Calculado: <span className="text-lg">${analysisData.calculatedProfitAmount?.toFixed(2) || '0.00'}</span></p>
          <hr className="my-3"/>
          <p className="font-bold text-xl text-success">Precio de Venta Sugerido: ${analysisData.suggestedSellingPrice?.toFixed(2) || '0.00'}</p>
          <p className="text-sm mt-1">Precio de Venta Actual: <span className="font-semibold">${menuItem.sellingPrice.toFixed(2)}</span></p>
          <p className={`text-sm ${((analysisData.suggestedSellingPrice || 0) - menuItem.sellingPrice) >= 0 ? 'text-success' : 'text-danger'}`}>
            Varianza: ${(((analysisData.suggestedSellingPrice || 0) - menuItem.sellingPrice)).toFixed(2)}
          </p>
          <TextareaInput label="Notas del Análisis" name="notes" value={analysisData.notes || ''} onChange={handleInputChange} rows={2} containerClassName="mt-3"/>
        </Card>
      </form>
      <style>{`
        @media print { /* Hides elements not meant for image capture if print is attempted */
            .modal-footer-print-hidden { display: none !important; }
        }
        .printable-cost-analysis-area { /* Styles for content to be captured */
            /* Ensures all content is rendered for capture if it overflows visually */
        }
      `}</style>
    </Modal>
  );
};

export default MenuItemCostAnalysisModal;


import React, { useState } from 'react';
import { MenuItem, MenuItemCategory } from '../../types';
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Icon from '../common/Icon';

interface MenuItemFormProps {
  initialData: MenuItem | null;
  onSave: (data: Omit<MenuItem, 'id' | 'createdAt'> & { id?: string }) => void;
  onCancel: () => void;
  categoryOptions: { value: string; label: string }[];
}

const MenuItemForm: React.FC<MenuItemFormProps> = ({ initialData, onSave, onCancel, categoryOptions }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    description: initialData?.description || '',
    category: initialData?.category || categoryOptions[0]?.value as MenuItemCategory || MenuItemCategory.OTRO,
    productionCost: initialData?.productionCost || 0,
    sellingPrice: initialData?.sellingPrice || 0,
    photoUrl: initialData?.photoUrl || '',
    isAvailable: initialData?.isAvailable !== undefined ? initialData.isAvailable : true,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ 
        ...prev, 
        [name]: (name === 'productionCost' || name === 'sellingPrice') ? parseFloat(value) || 0 : value 
      }));
    }
  };
  
  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || formData.sellingPrice <= 0 || formData.productionCost < 0) {
        alert("Nombre del platillo, precio de venta (mayor a 0) y costo de producción (no negativo) son obligatorios.");
        return;
    }
    onSave({ id: initialData?.id, ...formData });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <TextInput label="Nombre del Platillo*" name="name" value={formData.name} onChange={handleChange} required />
      <TextareaInput label="Descripción (Opcional)" name="description" value={formData.description} onChange={handleChange} rows={3} />
      <SelectInput label="Categoría*" name="category" value={formData.category} onChange={handleChange} options={categoryOptions} required />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TextInput label="Costo de Producción ($)*" name="productionCost" type="number" value={formData.productionCost.toString()} onChange={handleChange} min="0" step="0.01" required />
        <TextInput label="Precio de Venta ($)*" name="sellingPrice" type="number" value={formData.sellingPrice.toString()} onChange={handleChange} min="0.01" step="0.01" required />
      </div>

      <div>
        <label htmlFor="photoUploadMenuItem" className="block text-sm font-medium text-muted-foreground mb-1">
          Foto del Platillo (Opcional)
        </label>
        <div className="mt-1 flex items-center space-x-3">
            <label htmlFor="photoUploadMenuItem" className="inline-flex items-center px-4 py-2 bg-primary/10 text-primary text-sm font-medium rounded-md cursor-pointer hover:bg-primary/20 transition-colors">
                <Icon name="upload" className="w-4 h-4 mr-2"/>
                Subir Foto
            </label>
            <input 
                id="photoUploadMenuItem"
                type="file" 
                accept="image/*" 
                onChange={handlePhotoUpload} 
                className="hidden"
            />
            {formData.photoUrl && (
                <Icon name="check" className="w-5 h-5 text-success"/>
            )}
        </div>
        {formData.photoUrl && (
         <div className="mt-3 p-2 border border-border-color rounded-md inline-block bg-background">
            <img src={formData.photoUrl} alt="Previsualización" className="max-h-24 max-w-xs object-contain rounded"/>
         </div>
       )}
      </div>


      <div className="flex items-center">
        <input
          id="isAvailable"
          name="isAvailable"
          type="checkbox"
          checked={formData.isAvailable}
          onChange={handleChange}
          className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
        />
        <label htmlFor="isAvailable" className="ml-2 block text-sm text-muted-foreground">
          Disponible en el menú
        </label>
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Platillo' : 'Crear Platillo'}</Button>
      </div>
    </form>
  );
};

export default MenuItemForm;

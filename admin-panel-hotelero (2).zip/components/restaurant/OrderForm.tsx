
import React, { useState, useEffect, useCallback } from 'react';
import { Order, OrderItem, MenuItem, OrderStatus, PaymentMethod, Reservation, Customer, Property, ReservationStatus } from '../../types';
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import SelectInput from '../common/SelectInput';
import TextareaInput from '../common/TextareaInput';
import Icon from '../common/Icon';
import Card from '../common/Card'; 
import DateInput from '../common/DateInput';

interface OrderFormProps {
  initialData: Order | null;
  menuItems: MenuItem[]; 
  onSave: (data: Omit<Order, 'id' | 'totalAmount' | 'accountingEntryId'> & { id?: string; status?: OrderStatus }) => void;
  onCancel: () => void;
  paymentMethodOptions: { value: string; label: string }[];
  reservations: Reservation[];
  customers: Customer[];
  properties: Property[];
}

type ServiceType = 'DINE_IN' | 'TAKE_AWAY' | 'GUEST_RESERVATION';

const OrderForm: React.FC<OrderFormProps> = ({ 
    initialData, menuItems, onSave, onCancel, paymentMethodOptions,
    reservations, customers, properties
}) => {
  const [formData, setFormData] = useState(() => {
    const defaults = {
        tableNumber: '',
        customerName: '',
        items: [] as OrderItem[],
        paymentMethod: PaymentMethod.CASH,
        notes: '',
        reservationId: '',
        isTakeAway: false,
        createdAt: new Date().toISOString().split('T')[0], // Default to today for new orders
    };
    if (initialData) {
        return {
            tableNumber: initialData.tableNumber || defaults.tableNumber,
            customerName: initialData.customerName || defaults.customerName,
            items: initialData.items || defaults.items,
            paymentMethod: initialData.paymentMethod || defaults.paymentMethod,
            notes: initialData.notes || defaults.notes,
            reservationId: initialData.reservationId || defaults.reservationId,
            isTakeAway: initialData.isTakeAway || defaults.isTakeAway,
            // Use existing createdAt if editing, otherwise default (already set for new)
            createdAt: initialData.createdAt ? initialData.createdAt.split('T')[0] : defaults.createdAt,
        };
    }
    return defaults;
  });

  const [serviceType, setServiceType] = useState<ServiceType>('DINE_IN');
  const [selectedReservationIdToLink, setSelectedReservationIdToLink] = useState<string>('');

  const [currentItemId, setCurrentItemId] = useState<string>('');
  const [currentItemQuantity, setCurrentItemQuantity] = useState<number>(1);
  const [currentItemNotes, setCurrentItemNotes] = useState<string>('');
  const [calculatedTotal, setCalculatedTotal] = useState<number>(0);

  useEffect(() => {
    if (initialData && initialData.id) { 
        if (initialData.isTakeAway) {
            setServiceType('TAKE_AWAY');
        } else if (initialData.reservationId) {
            setServiceType('GUEST_RESERVATION');
            setSelectedReservationIdToLink(initialData.reservationId);
        } else {
            setServiceType('DINE_IN');
        }
         // Ensure createdAt is correctly populated for editing
        setFormData(prev => ({ ...prev, createdAt: initialData.createdAt ? initialData.createdAt.split('T')[0] : new Date().toISOString().split('T')[0] }));
    } else { 
        setServiceType('DINE_IN'); 
        setSelectedReservationIdToLink(''); 
        setFormData(prev => ({ ...prev, createdAt: prev.createdAt || new Date().toISOString().split('T')[0] }));
    }
  }, [initialData]);

  useEffect(() => {
    if (serviceType === 'DINE_IN') {
        setFormData(prev => ({ ...prev, isTakeAway: false, customerName: initialData?.id && initialData.tableNumber ? prev.customerName : '', reservationId: '' }));
        setSelectedReservationIdToLink('');
    } else if (serviceType === 'TAKE_AWAY') {
        setFormData(prev => ({ ...prev, isTakeAway: true, tableNumber: '', reservationId: '' }));
        setSelectedReservationIdToLink('');
    } else if (serviceType === 'GUEST_RESERVATION') {
        setFormData(prev => ({ ...prev, isTakeAway: false, tableNumber: '' }));
    }
  }, [serviceType, initialData]);

  useEffect(() => {
    if (serviceType === 'GUEST_RESERVATION' && selectedReservationIdToLink) {
        const reservationDetails = reservations.find(r => r.id === selectedReservationIdToLink);
        if (reservationDetails) {
            const customerDetails = customers.find(c => c.id === reservationDetails.customerId);
            setFormData(prev => ({ 
                ...prev, 
                customerName: customerDetails?.fullName || 'Cliente de Reserva',
                reservationId: selectedReservationIdToLink
            }));
        }
    }
  }, [selectedReservationIdToLink, serviceType, reservations, customers]);


  const calculateOrderTotal = useCallback((items: OrderItem[]): number => {
    return items.reduce((sum, item) => sum + (item.sellingPriceAtOrderTime * item.quantity), 0);
  }, []);

  useEffect(() => {
    setCalculatedTotal(calculateOrderTotal(formData.items));
  }, [formData.items, calculateOrderTotal]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleServiceTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newServiceType = e.target.value as ServiceType;
    setServiceType(newServiceType);
    if (newServiceType !== 'GUEST_RESERVATION') setSelectedReservationIdToLink('');
    if (newServiceType !== 'DINE_IN') setFormData(prev => ({ ...prev, tableNumber: '' }));
    if (newServiceType !== 'TAKE_AWAY' && newServiceType !== 'GUEST_RESERVATION') {
       if (!(initialData?.id && formData.customerName && (serviceType === 'TAKE_AWAY' || serviceType === 'GUEST_RESERVATION'))) {
            setFormData(prev => ({ ...prev, customerName: ''}));
       }
    }
  };

  const handleAddItemToOrder = () => {
    if (!currentItemId || currentItemQuantity <= 0) {
      alert("Seleccione un platillo y una cantidad válida.");
      return;
    }
    const menuItem = menuItems.find(mi => mi.id === currentItemId);
    if (!menuItem) {
      alert("Platillo no encontrado.");
      return;
    }

    const newItem: OrderItem = {
      menuItemId: menuItem.id,
      menuItemName: menuItem.name, 
      quantity: currentItemQuantity,
      sellingPriceAtOrderTime: menuItem.sellingPrice,
      notes: currentItemNotes,
    };

    setFormData(prev => ({ ...prev, items: [...prev.items, newItem] }));
    setCurrentItemId('');
    setCurrentItemQuantity(1);
    setCurrentItemNotes('');
  };

  const handleRemoveItemFromOrder = (index: number) => {
    setFormData(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== index) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.items.length === 0) {
        alert("La comanda debe tener al menos un platillo.");
        return;
    }
    
    const baseDataToSave = {
        tableNumber: formData.tableNumber,
        customerName: formData.customerName,
        items: formData.items,
        paymentMethod: formData.paymentMethod,
        notes: formData.notes,
        reservationId: formData.reservationId,
        isTakeAway: formData.isTakeAway,
        createdAt: formData.createdAt.split('T')[0], // Ensure only date part is sent
    };

    // For editing existing orders, we pass the original status.
    // For new orders, the status will be set to PENDIENTE by the parent (RestaurantPage).
    const dataToSave: Omit<Order, 'id' | 'totalAmount' | 'accountingEntryId'> & { id?: string; status?: OrderStatus } = {
        ...baseDataToSave,
        id: initialData?.id, // Will be undefined for new orders
        status: initialData?.status, // Pass existing status for edits; undefined for new (parent handles default)
    };
    
    if (serviceType === 'DINE_IN') {
        dataToSave.customerName = ''; 
        dataToSave.reservationId = '';
        dataToSave.isTakeAway = false;
    } else if (serviceType === 'TAKE_AWAY') {
        dataToSave.tableNumber = '';
        dataToSave.reservationId = '';
        dataToSave.isTakeAway = true;
    } else if (serviceType === 'GUEST_RESERVATION') {
        dataToSave.tableNumber = '';
        dataToSave.isTakeAway = false;
    }

    onSave(dataToSave);
  };
  
  const menuItemOptions = menuItems.map(mi => ({ value: mi.id, label: `${mi.name} ($${mi.sellingPrice.toFixed(2)})`}));
  
  const serviceTypeOptions = [
      { value: 'DINE_IN', label: 'Mesa Local' },
      { value: 'TAKE_AWAY', label: 'Cliente para Llevar/Domicilio' },
      { value: 'GUEST_RESERVATION', label: 'Huésped con Reserva (Cabaña/Habitación)' },
  ];

  const activeReservations = reservations.filter(r => r.status !== ReservationStatus.CANCELLED) 
    .map(r => {
        const customer = customers.find(c => c.id === r.customerId);
        const property = properties.find(p => p.id === r.propertyId);
        return {
            value: r.id,
            label: `ID: ${r.id.slice(-6)} - ${customer?.fullName || 'Cliente desc.'} - ${property?.name || 'Prop. desc.'} (${new Date(r.checkInDate).toLocaleDateString()})`
        };
    });


  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <DateInput
        label="Fecha de la Comanda*"
        name="createdAt" 
        value={formData.createdAt} 
        onChange={handleChange}
        required
      />
      <SelectInput 
        label="Servir Para:*"
        options={serviceTypeOptions}
        value={serviceType}
        onChange={handleServiceTypeChange}
      />

      {serviceType === 'DINE_IN' && (
        <TextInput label="Número de Mesa*" name="tableNumber" value={formData.tableNumber} onChange={handleChange} required={serviceType === 'DINE_IN'}/>
      )}
      {serviceType === 'TAKE_AWAY' && (
        <TextInput label="Nombre del Cliente (para llevar)*" name="customerName" value={formData.customerName} onChange={handleChange} required={serviceType === 'TAKE_AWAY'}/>
      )}
      {serviceType === 'GUEST_RESERVATION' && (
        <>
            <SelectInput 
                label="Seleccionar Reserva Activa*"
                options={activeReservations}
                value={selectedReservationIdToLink}
                onChange={(e) => setSelectedReservationIdToLink(e.target.value)}
                required={serviceType === 'GUEST_RESERVATION'}
            />
            <TextInput label="Nombre del Cliente (auto)" name="customerName" value={formData.customerName} onChange={handleChange} disabled />
        </>
      )}
      
      <Card title="Añadir Platillos a la Comanda" className="bg-background">
        <div className="space-y-3 p-1">
            <SelectInput label="Seleccionar Platillo*" options={menuItemOptions} value={currentItemId} onChange={(e) => setCurrentItemId(e.target.value)} containerClassName="mb-0"/>
            <TextInput label="Cantidad*" type="number" value={currentItemQuantity.toString()} onChange={(e) => setCurrentItemQuantity(parseInt(e.target.value) || 1)} min="1" containerClassName="mb-0"/>
            <TextInput label="Notas para este Platillo (Opcional)" value={currentItemNotes} onChange={(e) => setCurrentItemNotes(e.target.value)} placeholder="Ej: Sin cebolla" containerClassName="mb-0"/>
            <Button type="button" onClick={handleAddItemToOrder} leftIcon={<Icon name="plus"/>} variant="outline" size="sm">Añadir a Comanda</Button>
        </div>
      </Card>

      {formData.items.length > 0 && (
        <Card title="Platillos en esta Comanda" className="max-h-60 overflow-y-auto">
            <ul className="divide-y divide-border-color">
                {formData.items.map((item, index) => {
                    const menuItemDetail = menuItems.find(mi => mi.id === item.menuItemId);
                    return (
                        <li key={index} className="py-2.5 px-1 flex justify-between items-start">
                           <div>
                                <p className="font-medium text-foreground">{item.quantity}x {menuItemDetail?.name || item.menuItemId}</p>
                                <p className="text-xs text-muted-foreground">${item.sellingPriceAtOrderTime.toFixed(2)} c/u</p>
                                {item.notes && <p className="text-xs text-info italic">Nota: {item.notes}</p>}
                           </div>
                            <Button type="button" variant="ghost" size="sm" onClick={() => handleRemoveItemFromOrder(index)} className="text-danger">
                                <Icon name="xMark" className="w-4 h-4"/>
                            </Button>
                        </li>
                    );
                })}
            </ul>
        </Card>
      )}

      <div className="p-3 bg-primary/10 rounded-md text-right">
        <p className="text-lg font-bold text-primary">Total Comanda: ${calculatedTotal.toFixed(2)}</p>
      </div>
      
      {/* Only show payment method if editing an already paid order */}
      {initialData?.status === OrderStatus.PAGADO && (
         <SelectInput 
            label="Método de Pago*" 
            name="paymentMethod" 
            value={formData.paymentMethod} 
            onChange={handleChange} 
            options={paymentMethodOptions} 
            required={initialData?.status === OrderStatus.PAGADO}
            disabled={initialData?.status !== OrderStatus.PAGADO} // Disable if not paid, though it shouldn't be shown
        />
      )}

      <TextareaInput label="Notas Generales de la Comanda" name="notes" value={formData.notes} onChange={handleChange} rows={2}/>

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Comanda' : 'Crear Comanda'}</Button>
      </div>
    </form>
  );
};

export default OrderForm;

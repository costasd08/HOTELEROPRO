import React, { useState, useEffect, useMemo } from 'react';
import { GuestFeedback, FeedbackType, FeedbackSource, FeedbackStatus, Customer, Reservation, Employee } from '../../types';
import Button from '../common/Button';
import DateInput from '../common/DateInput';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import Icon from '../common/Icon';
import Card from '../common/Card'; // Imported Card
import { FEEDBACK_TYPE_OPTIONS, FEEDBACK_SOURCE_OPTIONS, FEEDBACK_STATUS_OPTIONS } from '../../constants';

interface FeedbackFormProps {
  initialData: GuestFeedback | null;
  onSave: (data: Omit<GuestFeedback, 'id' | 'createdAt' | 'updatedAt' | 'aiSummary'> & { id?: string }) => void;
  onCancel: () => void;
  customers: Customer[];
  reservations: Reservation[];
  employees: Employee[];
  onGenerateAiSummary: () => void;
  aiSummaryResult: string;
  aiSummaryLoading: boolean;
}

const FeedbackForm: React.FC<FeedbackFormProps> = ({
  initialData,
  onSave,
  onCancel,
  customers,
  reservations,
  employees,
  onGenerateAiSummary,
  aiSummaryResult,
  aiSummaryLoading,
}) => {
  const [formData, setFormData] = useState(() => {
    const defaults = {
      dateReceived: new Date().toISOString().split('T')[0],
      customerId: '',
      reservationId: '',
      guestNameManual: '',
      type: FeedbackType.COMENTARIO,
      source: FeedbackSource.VERBAL_PERSONAL,
      details: '',
      departmentToInform: '',
      actionTaken: '',
      status: FeedbackStatus.NUEVO,
      employeeHandlingId: '',
      aiSummary: '', // Added aiSummary to formData
    };
    return initialData ? { ...defaults, ...initialData, aiSummary: initialData.aiSummary || '' } : defaults;
  });

  useEffect(() => {
    // If initialData is provided and it has an aiSummary, update formData.
    // This is primarily for viewing, as onSave does not include aiSummary.
    if (initialData && initialData.aiSummary) {
      setFormData(prev => ({ ...prev, aiSummary: initialData.aiSummary }));
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.dateReceived || !formData.type || !formData.source || !formData.details || !formData.status) {
      alert('Fecha, Tipo, Fuente, Detalles y Estado son obligatorios.');
      return;
    }
    if (!formData.customerId && !formData.reservationId && !formData.guestNameManual) {
        alert('Debe especificar un Cliente, Reserva o ingresar un Nombre de Huésped manualmente.')
        return;
    }
    // aiSummary is handled separately and not part of the core save data for the feedback entry itself directly through this form's onSave
    const { aiSummary, ...dataToSave } = formData;
    onSave({ id: initialData?.id, ...dataToSave });
  };
  
  const customerOptions = [{ value: '', label: 'Seleccionar Cliente (Opcional)' }, ...customers.map(c => ({ value: c.id, label: c.fullName }))];
  // Filter reservations based on selected customer if a customer is selected
  const reservationOptions = useMemo(() => {
    const baseOptions = [{ value: '', label: 'Seleccionar Reserva (Opcional)' }];
    let filteredReservations = reservations;
    if (formData.customerId) {
        filteredReservations = reservations.filter(r => r.customerId === formData.customerId);
    }
    return [...baseOptions, ...filteredReservations.map(r => ({ value: r.id, label: `ID: ${r.id.slice(-6)} (Prop: ${r.propertyId}, Check-in: ${new Date(r.checkInDate).toLocaleDateString()})` }))];
  }, [reservations, formData.customerId]);

  const employeeOptions = [{ value: '', label: 'Seleccionar Empleado (Opcional)' }, ...employees.map(e => ({ value: e.id, label: e.fullName }))];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DateInput label="Fecha Recibido*" name="dateReceived" value={formData.dateReceived} onChange={handleChange} required />
        <TextInput label="Nombre Huésped (Manual)" name="guestNameManual" value={formData.guestNameManual || ''} onChange={handleChange} placeholder="Si no se enlaza Cliente/Reserva" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SelectInput label="Cliente Asociado" name="customerId" value={formData.customerId} onChange={handleChange} options={customerOptions} />
        <SelectInput label="Reserva Asociada" name="reservationId" value={formData.reservationId} onChange={handleChange} options={reservationOptions} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <SelectInput label="Tipo de Feedback*" name="type" value={formData.type} onChange={handleChange} options={FEEDBACK_TYPE_OPTIONS} required />
        <SelectInput label="Fuente del Feedback*" name="source" value={formData.source} onChange={handleChange} options={FEEDBACK_SOURCE_OPTIONS} required />
        <SelectInput label="Estado del Feedback*" name="status" value={formData.status} onChange={handleChange} options={FEEDBACK_STATUS_OPTIONS} required />
      </div>

      <TextareaInput label="Detalles del Feedback*" name="details" value={formData.details} onChange={handleChange} rows={4} required />
      
      {initialData && formData.details && ( // Show AI summary section only when editing and details exist
        <Card title="Resumen con IA (Opcional)" className="bg-background">
             <Button 
                type="button" 
                onClick={onGenerateAiSummary} 
                isLoading={aiSummaryLoading}
                disabled={aiSummaryLoading || !formData.details}
                leftIcon={<Icon name="sparkles" className="w-4 h-4"/>}
                variant="accent"
                size="sm"
                className="mb-3"
            >
                {aiSummaryLoading ? "Generando Resumen..." : "Generar Resumen de este Feedback"}
            </Button>
            {aiSummaryResult && (
                <div className={`p-3 rounded-md border text-sm ${aiSummaryResult.startsWith("Error:") ? 'bg-danger/10 border-danger text-danger' : 'bg-primary/10 border-primary/30 text-primary'}`}>
                    <p className="whitespace-pre-wrap">{aiSummaryResult}</p>
                </div>
            )}
            {formData.aiSummary && !aiSummaryResult && ( // Display stored AI summary if not actively generating
                 <div className="p-3 rounded-md border text-sm bg-gray-100 border-gray-300">
                    <p className="font-medium text-muted-foreground mb-1">Resumen IA Previo:</p>
                    <p className="whitespace-pre-wrap">{formData.aiSummary}</p>
                </div>
            )}
        </Card>
      )}


      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <TextInput label="Departamento a Informar" name="departmentToInform" value={formData.departmentToInform || ''} onChange={handleChange} placeholder="Ej: Recepción, Mantenimiento"/>
        <SelectInput label="Empleado que Atiende/Resuelve" name="employeeHandlingId" value={formData.employeeHandlingId} onChange={handleChange} options={employeeOptions} />
      </div>
      <TextareaInput label="Acción Tomada/Resolución" name="actionTaken" value={formData.actionTaken || ''} onChange={handleChange} rows={3} />

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-6">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Feedback' : 'Guardar Feedback'}</Button>
      </div>
    </form>
  );
};

export default FeedbackForm;
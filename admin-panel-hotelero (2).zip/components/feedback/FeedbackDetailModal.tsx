import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { EnrichedGuestFeedback, AppSettings, Property, FeedbackStatus } from '../../types'; // Added FeedbackStatus
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';

interface FeedbackDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  feedbackData: EnrichedGuestFeedback;
  appSettings: AppSettings;
}

const formatDate = (dateString: string | undefined): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString.includes('T') ? dateString : dateString + 'T00:00:00');
  return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
};

const FeedbackDetailModal: React.FC<FeedbackDetailModalProps> = ({
  isOpen,
  onClose,
  feedbackData,
  appSettings,
}) => {
  const detailContentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const {
    id, dateReceived, customer, reservation, guestNameManual, type, source, details,
    departmentToInform, actionTaken, status, employeeHandling, aiSummary
  } = feedbackData;

  const handleDownloadImage = async () => {
    if (!detailContentRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(detailContentRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff', // Ensure a background for the capture
        onclone: (document) => {
          // Hide buttons specifically for image capture if they are inside detailContentRef
           const elementsToHide = document.querySelectorAll('.hide-on-capture');
           elementsToHide.forEach(el => (el as HTMLElement).style.display = 'none');
        }
      });
      const image = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `feedback_detalle_${id.slice(-6)}.png`;
      link.href = image;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error generating feedback detail image:", error);
      alert("Hubo un error al generar la imagen del detalle.");
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShareWhatsApp = () => {
    let message = `*Detalle de Feedback - ${appSettings.appName}*\n\n`;
    message += `ID Feedback: ${id.slice(-6)}\n`;
    message += `Fecha Recibido: ${formatDate(dateReceived)}\n`;
    message += `Tipo: ${type}\n`;
    message += `Fuente: ${source}\n`;
    message += `Estado: ${status}\n`;
    if (customer) message += `Cliente: ${customer.fullName}\n`;
    else if (guestNameManual) message += `Huésped: ${guestNameManual}\n`;
    if (reservation) message += `Reserva ID: ${reservation.id.slice(-6)} (Propiedad: ${(reservation.property as Property)?.name || reservation.propertyId})\n`;
    message += `\n*Detalles del Feedback:*\n${details}\n`;
    if (aiSummary) message += `\n*Resumen IA:*\n${aiSummary}\n`;
    if (departmentToInform) message += `\nDepto. a Informar: ${departmentToInform}\n`;
    if (actionTaken) message += `Acción Tomada: ${actionTaken}\n`;
    if (employeeHandling) message += `Atendido por: ${employeeHandling.fullName}\n`;

    const customerPhone = customer?.phone?.replace(/\D/g, '');
    // If customer phone available, prefill. Otherwise, generic share.
    const whatsappUrl = customerPhone 
        ? `https://wa.me/${customerPhone}?text=${encodeURIComponent(message)}`
        : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };
  
  const getStatusColorClass = (statusValue: FeedbackStatus) => {
    switch(statusValue) {
        case FeedbackStatus.NUEVO: return 'text-blue-700 border-blue-700';
        case FeedbackStatus.EN_REVISION: return 'text-yellow-700 border-yellow-700';
        case FeedbackStatus.ACCION_REQUERIDA: return 'text-orange-700 border-orange-700';
        case FeedbackStatus.RESUELTO: return 'text-green-700 border-green-700';
        case FeedbackStatus.CERRADO: return 'text-gray-700 border-gray-700';
        default: return 'text-gray-600 border-gray-600';
    }
  };


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detalle de Feedback - ID: ${id.slice(-6)}`}
      size="lg"
      footer={
        <div className="flex justify-between w-full items-center hide-on-capture">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cerrar
          </Button>
          <div className="flex space-x-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={handleShareWhatsApp}
              leftIcon={<Icon name="whatsapp" className="w-4 h-4 text-green-500" />}
            >
              Compartir
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleDownloadImage}
              leftIcon={<Icon name="image" className="w-4 h-4" />}
              isLoading={isDownloading}
              disabled={isDownloading}
            >
              {isDownloading ? 'Descargando...' : 'Descargar Imagen'}
            </Button>
          </div>
        </div>
      }
    >
      <div ref={detailContentRef} className="printable-feedback-detail bg-surface p-4 sm:p-6 text-sm">
        <header className="text-center mb-4 border-b-2 border-primary pb-3">
          {appSettings.logoUrl && (
            <img src={appSettings.logoUrl} alt={`${appSettings.appName} Logo`} className="max-h-16 mx-auto mb-2 object-contain" />
          )}
          <h1 className="text-xl font-bold text-primary">{appSettings.appName}</h1>
          <p className="text-md font-semibold text-foreground">DETALLE DE FEEDBACK DE HUÉSPED</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 mb-3">
          <p><strong>ID Feedback:</strong> <span className="font-mono text-xs">{id}</span></p>
          <p><strong>Fecha Recibido:</strong> {formatDate(dateReceived)}</p>
          <p><strong>Tipo:</strong> {type}</p>
          <p><strong>Fuente:</strong> {source}</p>
          <p><strong>Estado:</strong> <span className={`font-semibold px-1 border rounded-sm text-xs ${getStatusColorClass(status)}`}>{status}</span></p>
          {customer && <p><strong>Cliente:</strong> {customer.fullName} ({customer.phone})</p>}
          {guestNameManual && !customer && <p><strong>Huésped (Manual):</strong> {guestNameManual}</p>}
          {reservation && <p className="md:col-span-2"><strong>Reserva ID:</strong> {reservation.id.slice(-6)} (Prop: {(reservation.property as Property)?.name || reservation.propertyId}, Check-in: {formatDate(reservation.checkInDate)})</p>}
        </div>

        <div className="mb-3 p-2 border border-border-color rounded-md bg-background">
          <h3 className="font-semibold text-muted-foreground mb-0.5">Detalles del Feedback:</h3>
          <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50 min-h-[50px]">{details}</p>
        </div>
        
        {aiSummary && (
             <div className="mb-3 p-2 border border-accent/30 rounded-md bg-accent/5">
                <h3 className="font-semibold text-accent mb-0.5">Resumen con IA:</h3>
                <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50">{aiSummary}</p>
            </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 mb-3">
            {departmentToInform && <p><strong>Departamento a Informar:</strong> {departmentToInform}</p>}
            {employeeHandling && <p><strong>Atendido por:</strong> {employeeHandling.fullName}</p>}
        </div>
        
        {actionTaken && (
            <div className="mb-3 p-2 border border-border-color rounded-md bg-background">
                <h3 className="font-semibold text-muted-foreground mb-0.5">Acción Tomada / Resolución:</h3>
                <p className="whitespace-pre-line p-1 bg-surface rounded text-xs border border-border-color/50 min-h-[40px]">{actionTaken}</p>
            </div>
        )}

        <footer className="text-center text-xs text-muted-foreground pt-3 mt-3 border-t border-border-color">
          <p>Gracias por su feedback. Trabajamos para mejorar continuamente.</p>
          <p>{appSettings.appName}{appSettings.responsiblePerson ? ` - Responsable: ${appSettings.responsiblePerson}` : ''} - {appSettings.phone || appSettings.hotelEmail}</p>
        </footer>
      </div>
      <style>{`
        @media print { 
          .hide-on-capture { display: none !important; } /* Also hide for print */
          body * { visibility: hidden; }
          .printable-feedback-detail, .printable-feedback-detail * { visibility: visible; }
          .printable-feedback-detail { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 15px !important; font-size: 9pt; background-color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>
    </Modal>
  );
};

export default FeedbackDetailModal;
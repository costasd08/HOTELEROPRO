import React from 'react';

interface PageTitleProps {
  title: string;
  actionButton?: React.ReactNode;
}

const PageTitle: React.FC<PageTitleProps> = ({ title, actionButton }) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
      <h2 className="text-3xl font-bold text-foreground mb-2 sm:mb-0">{title}</h2>
      {actionButton && <div className="shrink-0">{actionButton}</div>}
    </div>
  );
};

export default PageTitle;
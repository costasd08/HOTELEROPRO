import React, { useEffect, useRef } from 'react';

declare global {
  interface Window {
    __weatherwidget_init?: () => void;
  }
}

interface WeatherWidgetProps {
  href: string;
  dataLabel1: string;
  dataLabel2?: string;
  theme?: string;
}

const WeatherWidget: React.FC<WeatherWidgetProps> = ({
  href = "https://forecast7.com/es/19d43n99d13/mexico-city/", // Default to Mexico City
  dataLabel1 = "CIUDAD DE MÉXICO",
  dataLabel2 = "PRONÓSTICO",
  theme = "original" // Common themes: original, pure, dark, chill, responsive
}) => {
  const widgetRef = useRef<HTMLAnchorElement>(null);
  const scriptId = 'weatherwidget-io-js';

  useEffect(() => {
    const loadScript = () => {
      // If script is already present, just re-initialize
      if (document.getElementById(scriptId)) {
        if (window.__weatherwidget_init) {
          window.__weatherwidget_init();
        }
        return;
      }

      const script = document.createElement('script');
      script.id = scriptId;
      script.src = 'https://weatherwidget.io/js/widget.min.js';
      script.async = true;
      script.onload = () => {
        // Ensure the init function is called after the script is loaded
        if (window.__weatherwidget_init) {
          window.__weatherwidget_init();
        }
      };
      // Append to head to ensure it's processed early
      document.head.appendChild(script);
    };

    loadScript();

    // Optional: Cleanup script on component unmount, though weatherwidget.io's script
    // is generally designed to be loaded once. This might cause issues if other
    // instances of the widget expect the script to remain. For a single-page app
    // context where the widget might be removed and re-added, this is less critical
    // as the re-initialization logic should handle it.
    // return () => {
    //   const existingScript = document.getElementById(scriptId);
    //   if (existingScript && existingScript.parentNode) {
    //     // existingScript.parentNode.removeChild(existingScript);
    //   }
    // };
  }, []); // Run once on mount

  // This effect attempts to re-initialize the widget if its core props change.
  // The weatherwidget.io script scans for <a> tags with its class, so changes
  // to props of an existing <a> tag might require this explicit re-init.
  useEffect(() => {
    if (window.__weatherwidget_init) {
      window.__weatherwidget_init();
    }
  }, [href, dataLabel1, dataLabel2, theme]);

  return (
    <a
      ref={widgetRef}
      className="weatherwidget-io"
      href={href}
      data-label_1={dataLabel1}
      data-label_2={dataLabel2}
      data-theme={theme}
      data-font="PT Sans" // Match existing font used in the app
      // Basic styling to make it visible, might need adjustment based on modal content area
      style={{ display: 'block', position: 'relative', minHeight: '150px', width: '100%', textDecoration: 'none', color: '#333' }}
    >
      {dataLabel1} {dataLabel2}
    </a>
  );
};

export default WeatherWidget;
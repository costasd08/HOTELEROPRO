import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  titleAction?: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ title, children, className = '', titleAction }) => {
  return (
    <div className={`bg-surface shadow-lg rounded-xl overflow-hidden ${className}`}>
      {title && (
        <div className="px-6 py-4 border-b border-border-color flex justify-between items-center">
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          {titleAction}
        </div>
      )}
      <div className="p-6 text-foreground">
        {children}
      </div>
    </div>
  );
};

export default Card;
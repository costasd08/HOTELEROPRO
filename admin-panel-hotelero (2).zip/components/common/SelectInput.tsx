import React from 'react';

interface SelectOption {
  value: string | number;
  label: string;
}

interface SelectInputProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: SelectOption[];
  error?: string;
  containerClassName?: string;
}

const SelectInput: React.FC<SelectInputProps> = ({ label, id, options, error, containerClassName = 'mb-4', className, ...props }) => {
  const selectId = id || `select-input-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className={containerClassName}>
      <label htmlFor={selectId} className="block text-sm font-medium text-muted-foreground mb-1">
        {label}
      </label>
      <select
        id={selectId}
        className={`mt-1 block w-full px-3 py-2 border ${error ? 'border-danger' : 'border-border-color'} bg-surface text-foreground rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm ${className}`}
        {...props}
      >
        <option value="">Seleccione...</option>
        {options.map(option => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <p className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
};

export default SelectInput;
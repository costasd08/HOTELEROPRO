import React, { useState, useEffect } from 'react';
import Icon from './Icon'; // Assuming Icon component can render a 'clock' icon

const ClockWidget: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timerId = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timerId);
    };
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      // second: '2-digit', // Optionally include seconds
    });
  };

  return (
    <div className="flex items-center text-sm text-foreground" title="Hora Actual">
      <Icon name="calendar" className="w-4 h-4 mr-1.5 text-muted-foreground opacity-80" /> {/* Using calendar as a generic time icon, replace if 'clock' is available */}
      <span>{formatTime(currentTime)}</span>
    </div>
  );
};

export default ClockWidget;

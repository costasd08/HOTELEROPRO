import React from 'react';

interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  containerClassName?: string;
  helperText?: string; // Added helperText prop
}

const TextInput: React.FC<TextInputProps> = ({ label, id, error, helperText, containerClassName = 'mb-4', className, ...props }) => {
  const inputId = id || `text-input-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className={containerClassName}>
      <label htmlFor={inputId} className="block text-sm font-medium text-muted-foreground mb-1">
        {label}
      </label>
      <input
        id={inputId}
        className={`mt-1 block w-full px-3 py-2 border ${error ? 'border-danger' : 'border-border-color'} rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-surface text-foreground ${className}`}
        {...props}
      />
      {error && <p className="mt-1 text-sm text-danger">{error}</p>}
      {helperText && !error && <p className="mt-1 text-xs text-muted-foreground">{helperText}</p>}
    </div>
  );
};

export default TextInput;
import React from 'react';

// Added 'presentationChartLine' for Analytics, ensured 'sparkles' exists for AI
// Added 'clock' for the new ClockWidget
type IconName = 'home' | 'calendar' | 'book' | 'building' | 'users' | 'cash' | 'menu' | 'userCircle' | 'plus' | 'edit' | 'trash' | 'eye' | 'search' | 'filter' | 'download' | 'mail' | 'check' | 'xMark' | 'arrowLeft' | 'arrowRight' | 'sun' | 'moon' | 'star' | 'documentText' | 'receipt' | 'sparkles' | 'warning' | 'infoCircle' | 'cog' | 'calculator' | 'chartBar' | 'whatsapp' | 'upload' | 'image' | 'briefcase' | 'identification' | 'banknotes' | 'mapPin' | 'utensils' | 'clipboardList' | 'bookOpen' | 'chartPie' | 'wrenchScrewdriver' | 'bullhorn' | 'chatBubbleLeftRight' | 'presentationChartLine' | 'clock';

interface IconProps {
  name: IconName;
  className?: string;
  strokeWidth?: number;
}

const Icon: React.FC<IconProps> = ({ name, className = 'w-6 h-6', strokeWidth = 1.5 }) => {
  const SvgIcon = (): JSX.Element => {
    switch (name) {
      case 'home':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955a.75.75 0 011.06 0l8.955 8.955M3.75 11.25V21h6V15h3.75v6h6V11.25M12 2.25V5.25" />;
      case 'calendar': // Also used by ClockWidget as fallback
        return <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25m10.5-2.25v2.25M3 10.5h18M3.75 7.5h16.5c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125H3.75A1.125 1.125 0 012.625 19.875V8.625c0-.621.504-1.125 1.125-1.125z" />;
      case 'clock':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
      case 'book':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6-2.292m0 0v14.25" />;
      case 'building': 
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21V5.25A2.25 2.25 0 016 3h12a2.25 2.25 0 012.25 2.25V21M3.75 21H20.25M9 9.75h6.75m-6.75 4.5h6.75m-6.75 4.5h6.75M6.75 21v-2.25a2.25 2.25 0 012.25-2.25h6a2.25 2.25 0 012.25 2.25V21" />;
      case 'users':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.101c1.206-1.085 2.578-1.92 4.026-2.458C6.195 16.335 6 15.19 6 14.032c0-1.933.816-3.666 2.131-4.908M15 19.128c-.464.061-.93.097-1.396.128m-5.34-5.992a3.375 3.375 0 116.75 0 3.375 3.375 0 01-6.75 0z" />;
      case 'cash': 
        return <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6H2.25m0 0v1.5M2.25 6a49.495 49.495 0 0115.797-2.101c.727-.198 1.453.342 1.453 1.096V4.5M3.75 16.5v.75c0 .414-.336.75-.75.75h-.75m0 0v1.5m.75-1.5a49.495 49.495 0 0015.797 2.101c.727.198 1.453-.342 1.453-1.096V16.5m-16.5-12C3.75 3.403 3.403 3 3 3h-.75m0 0v1.5m.75-1.5C3.75 3.403 3.403 3 3 3h-.75m6.375 13.5H9m0 0V4.5m1.125 13.5H12m0 0V4.5m2.625 13.5h1.125m0 0V4.5M16.125 4.5v13.5M18.75 10.5h.75c.414 0 .75.336.75.75V13.5c0 .414-.336.75-.75.75h-.75M18.75 10.5h.75c.414 0 .75-.336.75-.75V8.25c0-.414-.336.75-.75.75h-.75M18.75 4.5v.75c0 .414.336.75.75.75h.75M18.75 4.5v.75c0 .414.336.75.75.75h.75" />;
      case 'banknotes': 
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3M3.75 3H20.25M3.75 3A2.25 2.25 0 001.5 5.25v13.5A2.25 2.25 0 003.75 21h16.5A2.25 2.25 0 0022.5 18.75v-13.5A2.25 2.25 0 0020.25 3M9 6.75h6.75M9 11.25h6.75" />;
      case 'menu':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />;
      case 'userCircle':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />;
      case 'plus':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />;
      case 'edit':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />;
      case 'trash':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c1.153 0 2.24.085 3.233.239m9.326-1.58c-.438-.344-.94-.63-1.486-.865a5.34 5.34 0 00-5.006 0c-.546.235-1.048.52-1.486.865M11.93 3.245A2.25 2.25 0 0010.5 3h-3A2.25 2.25 0 005.25 5.25v.491L11.93 3.245z" />;
      case 'eye':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.487 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />;
      case 'search':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />;
      case 'filter':
         return <path strokeLinecap="round" strokeLinejoin="round" d="M10.125 6.375h3.75M10.125 12.75h3.75M3.375 6.375h17.25M6.375 12.75H21M3.375 6.375H6.375m11.25 0h2.25m-4.5 6.375H12m9 0h-2.25m-4.5 0H6.375" />; 
      case 'download':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />;
      case 'mail':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />;
      case 'check':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />;
      case 'xMark':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />;
      case 'arrowLeft':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />;
      case 'arrowRight':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />;
      case 'sun':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.364l-1.591 1.591M21 12h-2.25m-.364 6.364l-1.591-1.591M12 18.75V21m-6.364-.364l1.591-1.591M3 12h2.25m.364-6.364l1.591 1.591M12 12a4.5 4.5 0 110-9 4.5 4.5 0 010 9z" />;
      case 'moon':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25c0 5.385 4.365 9.75 9.75 9.75 2.138 0 4.123-.693 5.752-1.848z" />;
      case 'star':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.324l5.58.813a.563.563 0 01.31.956l-4.036 3.935a.563.563 0 00-.162.53l.953 5.556a.563.563 0 01-.815.594l-5.002-2.63a.563.563 0 00-.52 0l-5.002 2.63a.563.563 0 01-.815-.594l.953-5.556a.563.563 0 00-.162-.53L.31 10.693a.563.563 0 01.31-.956l5.58-.813a.563.563 0 00.475-.324L11.48 3.5z" />;
      case 'documentText':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />;
      case 'receipt':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 6v.75m0 3v.75m0 3v.75m0 3V18m-9-1.5h5.25m-5.25 0h3M3 17.25a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 17.25v1.5H3v-1.5zM3 9.75a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 9.75v1.5H3v-1.5zM3 6a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 6v1.5H3V6z" />;
      case 'sparkles':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 7.5l1.5-1.5-1.5-1.5-1.5 1.5 1.5 1.5zM18.25 16.5l1.5-1.5-1.5-1.5-1.5 1.5 1.5 1.5z" />
      case 'warning':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />;
      case 'infoCircle':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />;
      case 'cog': 
        return <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />;
      case 'calculator':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5V2.25A2.25 2.25 0 0011.25 0H5.25A2.25 2.25 0 003 2.25v13.5A2.25 2.25 0 005.25 18H10.5m3-13.5H18A2.25 2.25 0 0120.25 6.75V10.5A2.25 2.25 0 0118 12.75h-4.5m3-13.5V6.75m0 6V15m1.5-6.75h.008v.008H18V10.5m-3 0h.008v.008H15V10.5m0-3h.008v.008H15V7.5M7.5 7.5h.008v.008H7.5V7.5m0 3h.008v.008H7.5V10.5m0 3h.008v.008H7.5V13.5m3-6h.008v.008H10.5V7.5m0 3h.008v.008H10.5V10.5m0 3h.008v.008H10.5V13.5M6 19.5h12M6 21.75h12" />; 
      case 'chartBar':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.5h2.25m2.25 0H9m2.25 0h2.25m2.25 0H18m2.25 0h.75M3 3v10.5m2.25-4.5v4.5m2.25-8.25v8.25m2.25-1.5V13.5m2.25-4.5v4.5m2.25-6.75v6.75M3 3h18v10.5H3V3z" />;
      case 'chartPie':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 107.5 7.5h-7.5V6z" /><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0013.5 3v7.5z" />;
      case 'whatsapp':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12.001 2.002c-5.522 0-9.998 4.478-9.998 10.002 0 1.778.464 3.447 1.28 4.922L2.002 22l5.228-1.348a9.91 9.91 0 004.772 1.228h.008c5.522 0 9.998-4.478 9.998-10.002S17.522 2.002 12.001 2.002zm0 0V2zm4.364 12.828c-.14-.246-.513-.39-.75-.412-.238-.022-.601-.002-1.018-.182-.416-.18-.95-.588-1.077-.738-.127-.15-.253-.298-.127-.546.126-.247.601-.762.727-.912.126-.15.19-.247.063-.494-.127-.247-.601-1.442-.828-1.937-.227-.494-.454-.422-.601-.422-.148 0-.275 0-.401.022s-.31 .074-.527.322c-.216.247-.828.815-1.004 1.16-.176.346-.352.69-.176 1.117.175.428.828 1.418 1.803 2.324.975.907 1.752 1.258 2.403 1.467.65.21 1.103.188 1.402.048.299-.14.828-.564.954-.787.127-.223.127-.424.063-.546z" />;
      case 'upload':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v12" />;
      case 'image':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />;
      case 'briefcase':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.25L21 12V7.5A2.25 2.25 0 0018.75 5.25h-2.25V3a.75.75 0 00-.75-.75H8.25a.75.75 0 00-.75.75v2.25H5.25A2.25 2.25 0 003 7.5v4.5l.75 2.25M20.25 14.25H3.75M20.25 14.25v2.25c0 .621-.504 1.125-1.125 1.125H4.875A1.125 1.125 0 013.75 16.5V14.25m12-5.25c.621 0 1.125.504 1.125 1.125v.75c0 .621-.504 1.125-1.125 1.125h-1.5c-.621 0-1.125-.504-1.125-1.125v-.75c0 .621.504-1.125 1.125-1.125h1.5z" />;
      case 'identification':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zM8.25 9.75h.008v.008H8.25V9.75zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-.375 2.25h.008v.008H8.25V12zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-.375 2.25h.008v.008H8.25V14.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />;
      case 'mapPin':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />;
      case 'utensils':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.033A12.022 12.022 0 007.5 2.25C6.186 2.25 5 3.436 5 4.75v14.5c0 .553.224 1.053.586 1.414.362.362.861.586 1.414.586h8c.553 0 1.053-.224 1.414-.586.362-.362.586-.861.586-1.414V4.75c0-1.314-1.186-2.5-2.5-2.5a12.022 12.022 0 00-5.25.783zm0 0V9.75m0 0H7.5m5.25 0H18M4.5 9.75H2.25m19.5 0H19.5m-15 4.5H2.25m19.5 0H19.5m-15 4.5H2.25m19.5 0H19.5" />;
      case 'clipboardList':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />;
      case 'bookOpen':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.166V6.022a1.5 1.5 0 011.5-1.5h16.5a1.5 1.5 0 011.5 1.5v6.144m-19.5 0CM2.25 15.06 5.5 17.25 9 17.25s6.75-2.19 6.75-5.084M2.25 12.166L9 17.25m0 0L15.75 12.166M9 17.25V3.75m0 0h-.375c-1.036 0-1.875.84-1.875 1.875v11.25c0 1.036.84 1.875 1.875 1.875h.375m0-15h.375c1.036 0 1.875.84 1.875 1.875v11.25c0 1.036-.84 1.875-1.875 1.875h-.375" />
      case 'wrenchScrewdriver':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 2.276a2.25 2.25 0 013.161 0l1.888 1.888a2.25 2.25 0 010 3.161l-6.274 6.274a2.25 2.25 0 01-3.161 0L5.146 11.76a2.25 2.25 0 010-3.161L11.42 2.276zm1.06-1.06L4.092 9.603a3.75 3.75 0 000 5.304l1.888 1.888a3.75 3.75 0 005.304 0l8.388-8.388a3.75 3.75 0 000-5.304L12.48.216zm-3.182 8.485a.75.75 0 10-1.06 1.06l-2.64 2.64a.75.75 0 001.06 1.06l2.64-2.64a.75.75 0 00-1.06-1.06zm3.536 3.535L6.75 17.25l-1.5-1.5 6.015-6.015 1.5 1.5zm6.178-8.678a.75.75 0 10-1.06-1.06L15.75 6l1.06 1.06-2.152 2.152zM21.75 12a9.75 9.75 0 11-19.5 0 9.75 9.75 0 0119.5 0z" clipRule="evenodd" />
      case 'bullhorn':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M10.34 3.263A2.25 2.25 0 0112.563 1h3.124a2.25 2.25 0 012.25 2.25v2.625c0 .578-.215 1.116-.586 1.537L16.5 9.75h.75c.621 0 1.125.504 1.125 1.125V15c0 .621-.504 1.125-1.125 1.125h-.75l.849 2.338a2.25 2.25 0 01-2.03 2.963H8.03a2.25 2.25 0 01-2.03-2.963L6.849 15h-.75A2.25 2.25 0 013.85 12.75v-1.875c0-.621.504-1.125 1.125-1.125h.75L4.876 7.413A2.25 2.25 0 014.29 5.875V3.25A2.25 2.25 0 016.541 1h3.8c.92 0 1.73.552 2.086 1.358L13.5 5.25m0 0L12.75 3M13.5 5.25V9.75m0 0H9.75m3.75 0H15m-3.75-1.5a.375.375 0 100-.75.375.375 0 000 .75z" />
      case 'chatBubbleLeftRight':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.685-3.091c-.945-.794-2.033-1.252-3.225-1.252H9.75A2.25 2.25 0 017.5 15V11.097c0-.97.616-1.813 1.5-2.097m11.25 0c-.246-.036-.499-.062-.762-.079V6.109c0-1.136-.847-2.1-1.98-2.193C16.329 3.89 16 3.863 15.651 3.836V.745L12.056 3.836C10.748 4.77 9.405 5.25 8 5.25H4.5A2.25 2.25 0 002.25 7.5v8.25c0 .97.616 1.813 1.5 2.097C5.39 18.102 6.744 18.5 8 18.5h.541l3.685 3.091V18.5c.34.02.68.044 1.02.071.884.283 1.5 1.127 1.5 2.097v1.874m0-15.854C20.25 3.889 19.755 3 19 3H6.75A2.25 2.25 0 004.5 5.25v.253" />;
      case 'presentationChartLine':
        return <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3M3.75 14.25V21M3.75 3h16.5m-16.5 0V6.75M3.75 6.75h16.5m-16.5 0V9M3.75 9h16.5m-10.5 3.75h.008v.008h-.008v-.008zm0 0H12m3 0h.008v.008h-.008v-.008zm0 0H15M3 3h.008v.008H3V3z" />
      default:
        return <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />; // Default clock icon
    }
  };

  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={strokeWidth} stroke="currentColor" className={className}>
      <SvgIcon />
    </svg>
  );
};

export default Icon;

import React from 'react';

interface TextareaInputProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
  containerClassName?: string;
}

const TextareaInput: React.FC<TextareaInputProps> = ({ label, id, error, containerClassName = 'mb-4', className, ...props }) => {
  const textareaId = id || `textarea-input-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className={containerClassName}>
      <label htmlFor={textareaId} className="block text-sm font-medium text-muted-foreground mb-1">
        {label}
      </label>
      <textarea
        id={textareaId}
        rows={3}
        className={`mt-1 block w-full px-3 py-2 border ${error ? 'border-danger' : 'border-border-color'} rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-surface text-foreground ${className}`}
        {...props}
      />
      {error && <p className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
};

export default TextareaInput;
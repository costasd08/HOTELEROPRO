import React, { useState } from 'react';
import Button from './Button';
import Icon from './Icon';

type CalculatorMode = 'simple' | 'scientific';

const CalculatorWidget: React.FC = () => {
  const [display, setDisplay] = useState<string>('0');
  const [currentValue, setCurrentValue] = useState<string | null>(null);
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [mode, setMode] = useState<CalculatorMode>('simple');
  const [waitingForOperand, setWaitingForOperand] = useState(true);

  const handleNumberClick = (numStr: string) => {
    if (waitingForOperand) {
      setDisplay(numStr);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? numStr : display + numStr);
    }
  };

  const handleDecimalClick = () => {
    if (waitingForOperand) {
        setDisplay('0.');
        setWaitingForOperand(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperatorClick = (op: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null && !waitingForOperand) { // First operation or after AC
        setPreviousValue(display);
    } else if (operator && !waitingForOperand) { // Subsequent operation
        const prev = parseFloat(previousValue!);
        const current = inputValue;
        let result = 0;
        switch (operator) {
            case '+': result = prev + current; break;
            case '-': result = prev - current; break;
            case '*': result = prev * current; break;
            case '/': result = prev / current; break;
            default: return;
        }
        setDisplay(String(result));
        setPreviousValue(String(result));
    }
    
    setWaitingForOperand(true);
    setOperator(op);
  };
  
  const handleEqualsClick = () => {
    if (!operator || previousValue === null || waitingForOperand) return; // if equals is pressed without a full operation ready

    const prev = parseFloat(previousValue);
    const current = parseFloat(display);
    let result = 0;

    switch (operator) {
      case '+': result = prev + current; break;
      case '-': result = prev - current; break;
      case '*': result = prev * current; break;
      case '/': 
        if (current === 0) {
            setDisplay('Error');
            resetCalculatorState();
            return;
        }
        result = prev / current; 
        break;
      default: return;
    }
    setDisplay(String(result));
    setPreviousValue(null); // Ready for a new calculation chain starting with the result
    setOperator(null);
    setWaitingForOperand(true); // After equals, next number starts a new display
  };
  
  const resetCalculatorState = () => {
    setCurrentValue(null);
    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(true);
  }

  const handleClearEntryClick = () => {
    setDisplay('0');
    setWaitingForOperand(true);
  };

  const handleAllClearClick = () => {
    setDisplay('0');
    resetCalculatorState();
  };

  const handleScientificOperation = (sciOp: string) => {
    const val = parseFloat(display);
    if (isNaN(val) && sciOp !== 'toggle_sign') { // Allow toggle sign on Error or 0
        setDisplay('Error');
        resetCalculatorState();
        return;
    }
    let result = 0;
    try {
        switch (sciOp) {
        case 'sqrt':
            if (val < 0) throw new Error("Sqrt neg");
            result = Math.sqrt(val);
            break;
        case 'sqr':
            result = val * val;
            break;
        case 'sin':
            result = Math.sin(val * Math.PI / 180); // Assuming degrees
            break;
        case 'cos':
            result = Math.cos(val * Math.PI / 180); // Assuming degrees
            break;
        case 'tan':
            result = Math.tan(val * Math.PI / 180); // Assuming degrees
            break;
        case 'log': // log10
             if (val <= 0) throw new Error("Log <= 0");
            result = Math.log10(val);
            break;
        case 'ln': // natural log
            if (val <= 0) throw new Error("Ln <= 0");
            result = Math.log(val);
            break;
        case 'toggle_sign':
            result = val * -1;
            break;
        default: return;
        }
        const resultStr = Number.isFinite(result) ? String(parseFloat(result.toPrecision(10))) : "Error";
        setDisplay(resultStr);

    } catch (e) {
         setDisplay('Error');
    }
    setWaitingForOperand(true); // Most scientific ops are unary and complete an action
    // Previous value and operator should ideally be cleared or handled depending on desired calculator logic (chaining vs. immediate)
    // For simplicity here, we'll make them complete the current number entry.
  };

  const buttonsLayout = {
    simple: [
      ['AC', 'CE', '%', '/'],
      ['7', '8', '9', '*'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['0', '.', '=']
    ],
    scientific: [
      ['sin', 'cos', 'tan', 'log'],
      ['ln', '√', 'x²', '±'],
      ['AC', 'CE', '%', '/'],
      ['7', '8', '9', '*'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['0', '.', '=']
    ]
  };
  
  const currentLayout = buttonsLayout[mode];

  const renderButton = (btn: string) => {
    const isOperator = ['/', '*', '-', '+', '%'].includes(btn);
    const isEquals = btn === '=';
    const isZero = btn === '0';
    const isScientificOp = ['sin', 'cos', 'tan', 'log', 'ln', '√', 'x²', '±'].includes(btn);

    let action = () => {};
    if (/\d/.test(btn)) action = () => handleNumberClick(btn);
    else if (btn === '.') action = handleDecimalClick;
    else if (isOperator) action = () => handleOperatorClick(btn);
    else if (isEquals) action = handleEqualsClick;
    else if (btn === 'AC') action = handleAllClearClick;
    else if (btn === 'CE') action = handleClearEntryClick;
    else if (isScientificOp) action = () => handleScientificOperation(btn === '√' ? 'sqrt' : btn === 'x²' ? 'sqr' : btn === '±' ? 'toggle_sign' : btn.toLowerCase());

    return (
      <Button
        key={btn}
        onClick={action}
        variant={isOperator || isEquals ? 'accent' : (btn === 'AC' || btn === 'CE') ? 'secondary' : 'outline'}
        className={`text-lg font-medium h-14 ${isZero ? 'col-span-2' : ''} ${isScientificOp ? 'text-sm' : ''}`}
        aria-label={btn}
      >
        {btn === '√' ? <>&radic;</> : btn === 'x²' ? <>x<sup>2</sup></> : btn === '±' ? <>&plusmn;</> : btn}
      </Button>
    );
  };


  return (
    <div className="w-full max-w-xs mx-auto p-2 bg-background rounded-lg shadow-md">
      <div className="mb-2">
        <Button onClick={() => setMode(mode === 'simple' ? 'scientific' : 'simple')} variant="ghost" size="sm">
          {mode === 'simple' ? 'Científica Básica' : 'Simple'} <Icon name={mode === 'simple' ? 'sparkles' : 'calculator'} className="w-4 h-4 ml-2"/>
        </Button>
      </div>
      <div className="bg-surface text-foreground text-right text-3xl p-4 rounded mb-3 shadow-inner overflow-x-auto" aria-live="polite">
        {display}
      </div>
      <div className={`grid gap-2 ${mode === 'simple' ? 'grid-cols-4' : 'grid-cols-4'}`}>
        {currentLayout.flat().map(btn => renderButton(btn))}
      </div>
    </div>
  );
};

export default CalculatorWidget;
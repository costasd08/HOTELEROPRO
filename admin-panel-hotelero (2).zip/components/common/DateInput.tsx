import React from 'react';

interface DateInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  containerClassName?: string;
}

const DateInput: React.FC<DateInputProps> = ({ label, id, error, containerClassName = 'mb-4', className, ...props }) => {
  const inputId = id || `date-input-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className={containerClassName}>
      <label htmlFor={inputId} className="block text-sm font-medium text-muted-foreground mb-1">
        {label}
      </label>
      <input
        type="date"
        id={inputId}
        className={`mt-1 block w-full px-3 py-2 border ${error ? 'border-danger' : 'border-border-color'} rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-surface text-foreground ${className}`}
        // Apply color-scheme to help browser style date picker icon
        style={{colorScheme: 'light'}}
        {...props}
      />
      {error && <p className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
};

export default DateInput;
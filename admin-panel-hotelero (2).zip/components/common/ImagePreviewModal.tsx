
import React from 'react';
import Modal from './Modal';
import Icon from './Icon';

interface ImagePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl?: string;
  title: string;
}

const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({ isOpen, onClose, imageUrl, title }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Vista Previa: ${title}`} size="lg">
      <div className="flex justify-center items-center p-4 min-h-[300px] bg-background rounded">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={title} 
            className="max-w-full max-h-[70vh] object-contain rounded shadow-md" 
          />
        ) : (
          <div className="text-center text-muted-foreground">
            <Icon name="image" className="w-24 h-24 mx-auto mb-4 opacity-30" />
            <p>No hay imagen disponible para "{title}".</p>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default ImagePreviewModal;

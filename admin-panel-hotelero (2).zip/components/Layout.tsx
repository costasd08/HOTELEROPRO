
import React, { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { NAVIGATION_LINKS, APP_NAME, APP_SETTINGS_KEY, MOCK_MENU_ITEMS_DATA_KEY } from '../constants';
import Icon from './common/Icon';
import Modal from './common/Modal';
import CalculatorWidget from './common/CalculatorWidget'; 
import WeatherWidget from './common/WeatherWidget';
import ClockWidget from './common/ClockWidget'; // Import ClockWidget
import MenuViewModal from './restaurant/MenuViewModal';
import { AppSettings, MenuItem } from '../types';
import useMockData from '../hooks/useMockData';
import AiAssistantFab from './ai/AiAssistantFab'; 
import AiAssistantChatModal from './ai/AiAssistantChatModal'; 

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false); 
  const [isWeatherModalOpen, setIsWeatherModalOpen] = useState(false); 
  const [isMenuViewModalOpen, setIsMenuViewModalOpen] = useState(false);
  const [isAiAssistantModalOpen, setIsAiAssistantModalOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate(); 
  
  const initialAppSettings: AppSettings = {
    appName: APP_NAME,
    logoUrl: '',
    hotelEmail: '',
    responsiblePerson: '',
    phone: '',
    reportCustomHeaderText: '',
    reportCustomFooterText: '',
    defaultCheckInTime: '14:00',
    defaultCheckOutTime: '12:00',
    weatherWidgetEnabled: false, 
    weatherWidgetHref: 'https://forecast7.com/es/19d43n99d13/mexico-city/', 
    weatherWidgetDataLabel: 'CIUDAD DE MÉXICO',
    defaultKitchenOverheadRate: 0.10, 
    defaultAdminSalesOverheadRate: 0.15,
    aiAssistantEnabled: false, // Default AI assistant to disabled
  };
  const [appSettings, setAppSettings] = useState<AppSettings>(initialAppSettings);
  const [weatherWidgetKey, setWeatherWidgetKey] = useState(Date.now()); 

  const [menuItems] = useMockData<MenuItem>(MOCK_MENU_ITEMS_DATA_KEY, []);


  const loadSettings = () => {
    try {
      const settingsStr = localStorage.getItem(APP_SETTINGS_KEY);
      if (settingsStr) {
        const parsedSettings = JSON.parse(settingsStr) as AppSettings;
        const mergedSettings = { 
            ...initialAppSettings, 
            ...parsedSettings, 
            weatherWidgetEnabled: parsedSettings.weatherWidgetEnabled !== undefined ? parsedSettings.weatherWidgetEnabled : initialAppSettings.weatherWidgetEnabled,
            defaultKitchenOverheadRate: parsedSettings.defaultKitchenOverheadRate !== undefined ? parsedSettings.defaultKitchenOverheadRate : initialAppSettings.defaultKitchenOverheadRate,
            defaultAdminSalesOverheadRate: parsedSettings.defaultAdminSalesOverheadRate !== undefined ? parsedSettings.defaultAdminSalesOverheadRate : initialAppSettings.defaultAdminSalesOverheadRate,
            aiAssistantEnabled: parsedSettings.aiAssistantEnabled !== undefined ? parsedSettings.aiAssistantEnabled : initialAppSettings.aiAssistantEnabled,
        };
        setAppSettings(mergedSettings);
        
        if (parsedSettings.weatherWidgetHref && parsedSettings.weatherWidgetHref !== appSettings.weatherWidgetHref) {
            setWeatherWidgetKey(Date.now());
        }
      } else {
        setAppSettings(initialAppSettings); 
      }
    } catch (e) {
      console.error("Could not parse app settings", e);
      setAppSettings(initialAppSettings); 
    }
  };

  useEffect(() => {
    loadSettings(); 
    window.addEventListener('storage', loadSettings); 
    return () => {
      window.removeEventListener('storage', loadSettings);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 
  
  const currentPageLabel = 
    NAVIGATION_LINKS.find(link => link.path === location.pathname)?.label || 
    (location.pathname === '/settings' ? 'Configuración' : appSettings.appName);


  return (
    <div className="flex h-screen bg-background">
      {/* Backdrop for mobile sidebar */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-primary text-white transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:flex md:flex-col shadow-lg`}
      >
        <div className="flex items-center justify-center h-20 border-b border-primary-hover px-4">
          {appSettings.logoUrl ? (
            <img src={appSettings.logoUrl} alt="Logo" className="h-10 mr-2 object-contain"/>
          ) : (
            <Icon name="building" className="w-8 h-8 mr-2 text-accent" />
          )}
          <span className="text-xl font-semibold truncate" title={appSettings.appName}>{appSettings.appName}</span>
        </div>
        <nav className="flex-grow p-4 space-y-2">
          {NAVIGATION_LINKS.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `flex items-center px-4 py-2.5 rounded-lg transition-colors duration-200 hover:bg-primary-hover ${
                  isActive ? 'bg-primary-hover font-medium ring-2 ring-accent' : ''
                }`
              }
              onClick={() => sidebarOpen && setSidebarOpen(false)} // Close sidebar on mobile after click
            >
              <Icon name={link.icon as any} className="w-5 h-5 mr-3" /> 
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-primary-hover">
          <p className="text-xs text-center text-blue-200">&copy; {new Date().getFullYear()} Hotel Admin</p>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex items-center justify-between h-16 px-6 bg-surface border-b border-border-color shadow-sm">
          <div className="flex items-center">
            <button
              onClick={() => setSidebarOpen(true)}
              className="text-muted-foreground md:hidden focus:outline-none focus:text-foreground"
              aria-label="Abrir menú lateral"
            >
              <Icon name="menu" className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-semibold text-foreground ml-2 md:ml-0">{currentPageLabel}</h1>
          </div>
          <div className="flex items-center space-x-3"> {/* Adjusted space-x for new clock widget */}
             <ClockWidget /> {/* Added ClockWidget here */}
             <button
                onClick={() => navigate('/calendar')}
                className="p-2 text-muted-foreground hover:text-accent focus:outline-none focus:ring-2 focus:ring-accent rounded-full"
                aria-label="Abrir calendario de reservas"
                title="Calendario"
            >
                <Icon name="calendar" className="w-6 h-6" />
            </button>
            {appSettings.weatherWidgetEnabled && (
                 <button
                    onClick={() => setIsWeatherModalOpen(true)}
                    className="p-2 text-muted-foreground hover:text-accent focus:outline-none focus:ring-2 focus:ring-accent rounded-full"
                    aria-label="Abrir pronóstico del clima"
                    title="Ver Clima"
                >
                    <Icon name="sun" className="w-6 h-6" />
                </button>
            )}
            <button
                onClick={() => setIsMenuViewModalOpen(true)}
                className="p-2 text-muted-foreground hover:text-accent focus:outline-none focus:ring-2 focus:ring-accent rounded-full"
                aria-label="Ver Menú del Restaurante"
                title="Ver Menú"
            >
                <Icon name="bookOpen" className="w-6 h-6" /> 
            </button>
            <button
                onClick={() => setIsCalculatorOpen(true)}
                className="p-2 text-muted-foreground hover:text-accent focus:outline-none focus:ring-2 focus:ring-accent rounded-full"
                aria-label="Abrir calculadora"
                title="Calculadora"
            >
                <Icon name="calculator" className="w-6 h-6" />
            </button>
            <button 
                onClick={() => navigate('/settings')}
                className="p-2 text-muted-foreground hover:text-accent focus:outline-none focus:ring-2 focus:ring-accent rounded-full"
                aria-label="Abrir configuración"
                title="Configuración"
            >
                <Icon name="cog" className="w-6 h-6" />
            </button>
            <div className="relative">
                 <Icon name="userCircle" className="w-8 h-8 text-muted-foreground cursor-pointer" />
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-x-hidden overflow-y-auto bg-background">
          {children}
        </main>
      </div>
      
      {/* Modals & FABs */}
      <Modal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        title="Calculadora"
        size="sm"
      >
        <CalculatorWidget />
      </Modal>

      {appSettings.weatherWidgetEnabled && (
        <Modal
            isOpen={isWeatherModalOpen}
            onClose={() => setIsWeatherModalOpen(false)}
            title="Pronóstico del Clima"
            size="md" 
        >
            <div key={weatherWidgetKey} className="min-h-[200px]"> 
                <WeatherWidget
                    href={appSettings.weatherWidgetHref || initialAppSettings.weatherWidgetHref!}
                    dataLabel1={appSettings.weatherWidgetDataLabel || initialAppSettings.weatherWidgetDataLabel!}
                />
            </div>
        </Modal>
      )}
      
      {isMenuViewModalOpen && (
        <MenuViewModal
          isOpen={isMenuViewModalOpen}
          onClose={() => setIsMenuViewModalOpen(false)}
          menuItems={menuItems.filter(item => item.isAvailable)}
          appSettings={appSettings}
        />
      )}

      {appSettings.aiAssistantEnabled && <AiAssistantFab onOpenChat={() => setIsAiAssistantModalOpen(true)} />}
      {appSettings.aiAssistantEnabled && isAiAssistantModalOpen && (
        <AiAssistantChatModal
          isOpen={isAiAssistantModalOpen}
          onClose={() => setIsAiAssistantModalOpen(false)}
        />
      )}
    </div>
  );
};

export default Layout;

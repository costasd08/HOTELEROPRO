import React from 'react';
import { Customer, Reservation, ReservationStatus, GuestFeedback, FeedbackStatus } from '../../types';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import Card from '../common/Card';

interface CustomerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer;
  bookingHistory: Reservation[];
  feedbackHistory: GuestFeedback[];
}

const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  isOpen,
  onClose,
  customer,
  bookingHistory,
  feedbackHistory,
}) => {

  const getReservationStatusColorClasses = (status: ReservationStatus) => {
    switch (status) {
        case ReservationStatus.FULLY_PAID: return 'bg-success/20 text-success';
        case ReservationStatus.ADVANCE_PAID: return 'bg-warning/20 text-yellow-700';
        case ReservationStatus.PENDING: return 'bg-info/20 text-info';
        case ReservationStatus.CANCELLED: return 'bg-danger/20 text-danger';
        default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getFeedbackStatusColorClasses = (status: FeedbackStatus) => { 
    switch(status) {
        case FeedbackStatus.NUEVO: return 'bg-blue-100 text-blue-700';
        case FeedbackStatus.EN_REVISION: return 'bg-yellow-100 text-yellow-700';
        case FeedbackStatus.ACCION_REQUERIDA: return 'bg-orange-100 text-orange-700';
        case FeedbackStatus.RESUELTO: return 'bg-green-100 text-green-700';
        case FeedbackStatus.CERRADO: return 'bg-gray-200 text-gray-700';
        default: return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detalles de Cliente: ${customer.fullName}`}
      size="xl"
      footer={<Button onClick={onClose}>Cerrar</Button>}
    >
      <div className="space-y-6">
        <Card title="Información de Contacto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 text-sm">
            <p><strong>Nombre Completo:</strong> {customer.fullName}</p>
            <p><strong>Teléfono:</strong> {customer.phone}</p>
            <p><strong>Email:</strong> {customer.email || <span className="italic text-muted-foreground">No especificado</span>}</p>
            <p><strong>Origen:</strong> {customer.origin || <span className="italic text-muted-foreground">No especificado</span>}</p>
            <p className="md:col-span-2"><strong>Registrado el:</strong> {new Date(customer.createdAt).toLocaleDateString()}</p>
          </div>
        </Card>

        {customer.notes && (
            <Card title="Anotaciones del Cliente">
                <p className="text-sm text-muted-foreground whitespace-pre-line p-2 bg-background rounded-md">{customer.notes}</p>
            </Card>
        )}

        <Card title="Historial de Reservas">
          {bookingHistory.length > 0 ? (
            <div className="max-h-60 overflow-y-auto space-y-3 p-1">
              {bookingHistory.map(res => (
                <div key={res.id} className="p-3 bg-background rounded-md text-sm shadow">
                  <p><strong>ID Reserva:</strong> {res.id} - <strong>Propiedad ID:</strong> {res.propertyId}</p>
                  <p><strong>Fechas:</strong> {new Date(res.checkInDate).toLocaleDateString()} - {new Date(res.checkOutDate).toLocaleDateString()}</p>
                  <p><strong>Estado:</strong> <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getReservationStatusColorClasses(res.status)}`}>{res.status}</span> - <strong>Total:</strong> ${res.totalPrice.toFixed(2)}</p>
                  {res.notes && <p className="mt-1 text-xs italic text-muted-foreground">Nota Reserva: {res.notes}</p>}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground italic">Este cliente no tiene historial de reservas.</p>
          )}
        </Card>

        <Card title="Historial de Feedback del Cliente">
          {feedbackHistory.length > 0 ? (
            <div className="max-h-60 overflow-y-auto space-y-4 p-1">
              {feedbackHistory.map(fb => (
                <div key={fb.id} className="p-3 bg-background rounded-md text-sm shadow">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-xs text-muted-foreground">
                      <strong>Fecha:</strong> {new Date(fb.dateReceived).toLocaleDateString()}
                    </p>
                    <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getFeedbackStatusColorClasses(fb.status)}`}>
                      {fb.status}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-1.5"><strong>Tipo:</strong> {fb.type}</p>
                  <p className="whitespace-pre-line text-foreground text-xs leading-relaxed border-t border-border-color pt-2 mt-2">
                    {fb.details}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground italic">Este cliente no tiene historial de feedback.</p>
          )}
        </Card>
      </div>
    </Modal>
  );
};

export default CustomerDetailModal;
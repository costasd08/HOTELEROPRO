import React, { useState } from 'react';
import { Customer, Reservation, ReservationStatus, GuestFeedback, FeedbackStatus } from '../../types'; // Added GuestFeedback, FeedbackStatus
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import Icon from '../common/Icon';
import Card from '../common/Card';

interface CustomerFormProps {
  initialData: Customer | null;
  onSave: (data: Omit<Customer, 'id' | 'createdAt'> & { id?: string }) => void;
  onCancel: () => void;
  bookingHistory: Reservation[];
  feedbackHistory?: GuestFeedback[]; 
  onGenerateSmartNotes: () => void;
  smartNotes: string;
  smartNotesLoading: boolean;
  // onViewFeedbackDetail prop is removed as feedback details are now shown inline
}

const CustomerForm: React.FC<CustomerFormProps> = ({ 
    initialData, 
    onSave, 
    onCancel, 
    bookingHistory, 
    feedbackHistory = [], 
    onGenerateSmartNotes, 
    smartNotes, 
    smartNotesLoading,
}) => {
  const [formData, setFormData] = useState({
    fullName: initialData?.fullName || '',
    phone: initialData?.phone || '',
    email: initialData?.email || '',
    origin: initialData?.origin || '',
    notes: initialData?.notes || '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
     if (!formData.fullName || !formData.phone) {
        alert("Nombre completo y teléfono son obligatorios.");
        return;
    }
    onSave({ id: initialData?.id, ...formData });
  };

  const getReservationStatusColorClasses = (status: ReservationStatus) => {
    switch (status) {
        case ReservationStatus.FULLY_PAID: return 'bg-success/20 text-success';
        case ReservationStatus.ADVANCE_PAID: return 'bg-warning/20 text-yellow-700';
        case ReservationStatus.PENDING: return 'bg-info/20 text-info';
        case ReservationStatus.CANCELLED: return 'bg-danger/20 text-danger';
        default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getFeedbackStatusColorClasses = (status: FeedbackStatus) => { 
    switch(status) {
        case FeedbackStatus.NUEVO: return 'bg-blue-100 text-blue-700';
        case FeedbackStatus.EN_REVISION: return 'bg-yellow-100 text-yellow-700';
        case FeedbackStatus.ACCION_REQUERIDA: return 'bg-orange-100 text-orange-700';
        case FeedbackStatus.RESUELTO: return 'bg-green-100 text-green-700';
        case FeedbackStatus.CERRADO: return 'bg-gray-200 text-gray-700';
        default: return 'bg-gray-100 text-gray-600';
    }
  };


  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <TextInput label="Nombre Completo*" name="fullName" value={formData.fullName} onChange={handleChange} required />
        <TextInput label="Número de Teléfono*" name="phone" value={formData.phone} onChange={handleChange} required />
        <TextInput label="Correo Electrónico" name="email" type="email" value={formData.email} onChange={handleChange} />
        <TextInput label="Origen del Cliente" name="origin" value={formData.origin} onChange={handleChange} placeholder="Ej: Redes Sociales, Referido" />
      </div>
      
      <TextareaInput label="Notas Internas sobre el Cliente" name="notes" value={formData.notes} onChange={handleChange} rows={3} placeholder="Preferencias, historial, alergias, etc."/>

      {initialData && (
        <div className="space-y-6">
        <Card title="Historial de Reservas">
            {bookingHistory.length > 0 ? (
                <div className="max-h-48 overflow-y-auto space-y-3 p-1">
                {bookingHistory.map(res => (
                    <div key={res.id} className="p-3 bg-background rounded-md text-sm shadow">
                    <p><strong>ID:</strong> {res.id} - <strong>Propiedad ID:</strong> {res.propertyId}</p>
                    <p><strong>Fechas:</strong> {new Date(res.checkInDate).toLocaleDateString()} - {new Date(res.checkOutDate).toLocaleDateString()}</p>
                    <p><strong>Estado:</strong> <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getReservationStatusColorClasses(res.status)}`}>{res.status}</span> - <strong>Total:</strong> ${res.totalPrice.toFixed(2)}</p>
                    {res.notes && <p className="mt-1 text-xs italic text-muted-foreground">Nota Reserva: {res.notes}</p>}
                    </div>
                ))}
                </div>
            ) : (
                <p className="text-muted-foreground italic">Este cliente no tiene historial de reservas.</p>
            )}
        </Card>

        <Card title="Historial de Feedback del Cliente">
            {feedbackHistory.length > 0 ? (
                 <div className="max-h-60 overflow-y-auto space-y-4 p-1">
                    {feedbackHistory.map(fb => (
                        <div key={fb.id} className="p-3 bg-background rounded-md text-sm shadow">
                            <div className="flex justify-between items-start mb-1">
                                <p className="text-xs text-muted-foreground">
                                    <strong>Fecha:</strong> {new Date(fb.dateReceived).toLocaleDateString()}
                                </p>
                                <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getFeedbackStatusColorClasses(fb.status)}`}>
                                    {fb.status}
                                </span>
                            </div>
                            <p className="text-xs text-muted-foreground mb-1.5"><strong>Tipo:</strong> {fb.type}</p>
                            <p className="whitespace-pre-line text-foreground text-xs leading-relaxed border-t border-border-color pt-2 mt-2">
                                {fb.details}
                            </p>
                        </div>
                    ))}
                 </div>
            ) : (
                <p className="text-muted-foreground italic">Este cliente no tiene historial de feedback.</p>
            )}
        </Card>

        <Card title="Notas Inteligentes del Cliente (IA)">
          <div className="flex flex-col space-y-3">
            <Button 
                type="button" 
                onClick={onGenerateSmartNotes} 
                isLoading={smartNotesLoading}
                disabled={smartNotesLoading}
                leftIcon={<Icon name="sparkles" className="w-4 h-4"/>}
                variant="accent"
                className="self-start"
            >
                {smartNotesLoading ? "Generando..." : "Generar Notas/Sugerencias con IA"}
            </Button>
            {smartNotes && (
            <div className={`p-4 rounded-md border ${smartNotes.startsWith("Error:") ? 'bg-danger/10 border-danger text-danger' : 'bg-primary/10 border-primary/30 text-primary'}`}>
                <p className="text-sm whitespace-pre-wrap">{smartNotes}</p>
            </div>
            )}
            </div>
        </Card>
        </div>
      )}

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-6">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" variant="primary">
          {initialData ? 'Actualizar Cliente' : 'Crear Cliente'}
        </Button>
      </div>
    </form>
  );
};

export default CustomerForm;
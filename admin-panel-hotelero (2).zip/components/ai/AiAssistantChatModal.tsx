import React, { useState, useEffect, useRef } from 'react';
import Modal from '../common/Modal';
import Button from '../common/Button';
import Icon from '../common/Icon';
import TextareaInput from '../common/TextareaInput';
import { ChatMessage, ApplicationDataContext, Reservation, Customer, Property, AccountingEntry, Employee, Order, MenuItem, InventoryItem, GuestFeedback, AppSettings } from '../../types';
import { generateAssistantResponse, getAiInstance } from '../../services/geminiService';
import useMockData from '../../hooks/useMockData';
import { 
    MOCK_RESERVATIONS_DATA_KEY, MOCK_CUSTOMERS_DATA_KEY, MOCK_PROPERTIES_DATA_KEY, 
    MOCK_ACCOUNTING_ENTRIES_DATA_KEY, MOCK_EMPLOYEES_DATA_KEY, MOCK_ORDERS_DATA_KEY, 
    MOCK_MENU_ITEMS_DATA_KEY, MOCK_INVENTORY_ITEMS_DATA_KEY, MOCK_GUEST_FEEDBACK_DATA_KEY,
    APP_SETTINGS_KEY, APP_NAME
} from '../../constants';

interface AiAssistantChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AiAssistantChatModal: React.FC<AiAssistantChatModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatDisplayRef = useRef<HTMLDivElement>(null);
  const isAiAvailable = !!getAiInstance();

  // Load all necessary data for context
  const [reservations] = useMockData<Reservation>(MOCK_RESERVATIONS_DATA_KEY, []);
  const [customers] = useMockData<Customer>(MOCK_CUSTOMERS_DATA_KEY, []);
  const [properties] = useMockData<Property>(MOCK_PROPERTIES_DATA_KEY, []);
  const [accountingEntries] = useMockData<AccountingEntry>(MOCK_ACCOUNTING_ENTRIES_DATA_KEY, []);
  const [employees] = useMockData<Employee>(MOCK_EMPLOYEES_DATA_KEY, []);
  const [orders] = useMockData<Order>(MOCK_ORDERS_DATA_KEY, []);
  const [menuItems] = useMockData<MenuItem>(MOCK_MENU_ITEMS_DATA_KEY, []);
  const [inventoryItems] = useMockData<InventoryItem>(MOCK_INVENTORY_ITEMS_DATA_KEY, []);
  const [guestFeedback] = useMockData<GuestFeedback>(MOCK_GUEST_FEEDBACK_DATA_KEY, []);
  
  const [appSettings, setAppSettings] = useState<AppSettings>({
    appName: APP_NAME, logoUrl: '', hotelEmail: '', responsiblePerson: '', phone: '',
    defaultCheckInTime: '14:00', defaultCheckOutTime: '12:00', reportCustomHeaderText: '',
    reportCustomFooterText: '', reservationPolicies: '', cancellationPolicies: '',
    generalObservations: '', otherPolicies: '', weatherWidgetEnabled: false,
    weatherWidgetHref: '', googleCalendarConnected: false, googleCalendarId: '',
    defaultKitchenOverheadRate: 0.1, defaultAdminSalesOverheadRate: 0.15
  });

  useEffect(() => {
    const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
    if (storedSettings) {
      setAppSettings(JSON.parse(storedSettings));
    }
  }, []);


  useEffect(() => {
    if (isOpen) {
      setMessages([
        {
          id: 'system-initial',
          text: isAiAvailable ? `¡Hola! Soy tu asistente AI. ¿Cómo puedo ayudarte con los datos de ${appSettings.appName} hoy?` : "El Asistente AI no está disponible. Por favor, configure la clave API de Gemini.",
          sender: 'system',
          timestamp: new Date().toISOString(),
        },
      ]);
      setError(null);
    }
  }, [isOpen, isAiAvailable, appSettings.appName]);

  useEffect(() => {
    if (chatDisplayRef.current) {
      chatDisplayRef.current.scrollTop = chatDisplayRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !isAiAvailable) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      text: inputValue,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setError(null);

    // Prepare conversation history for context (simple approach: last N messages)
    // Gemini's model.generateContent expects an array of Content objects.
    // For a chat, this means alternating user and model (AI) roles.
    const conversationHistoryForApi = messages
      .filter(msg => msg.sender === 'user' || msg.sender === 'ai') // Exclude system messages for API history
      .slice(-4) // Take last 4 messages for context (2 user, 2 AI ideally)
      .map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model', // Gemini uses 'model' for AI responses
        parts: [{ text: msg.text }],
      }));
    
    const currentAppData: ApplicationDataContext = {
        reservations, customers, properties, accountingEntries, employees, 
        orders, menuItems, inventoryItems, guestFeedback, appSettings
    };

    try {
      const aiResponseText = await generateAssistantResponse(userMessage.text, currentAppData, conversationHistoryForApi);
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        text: aiResponseText,
        sender: 'ai',
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (e: any) {
      console.error("Error getting AI response:", e);
      const errorMessageText = e.message || "Hubo un error al procesar tu solicitud.";
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        text: `Error: ${errorMessageText}`,
        sender: 'system',
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
      setError(errorMessageText);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Asistente AI" size="lg" footer={null}>
      <div className="flex flex-col h-[70vh]">
        <div ref={chatDisplayRef} className="flex-grow overflow-y-auto p-4 space-y-3 bg-background rounded-t-md">
          {messages.map(msg => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[70%] p-3 rounded-xl shadow ${
                  msg.sender === 'user'
                    ? 'bg-primary text-white'
                    : msg.sender === 'ai'
                    ? 'bg-surface text-foreground border border-border-color'
                    : 'bg-warning/20 text-yellow-700 w-full text-center' // System/Error messages
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                {msg.sender !== 'system' && (
                    <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-blue-200' : 'text-muted-foreground'}`}>
                        {new Date(msg.timestamp).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="max-w-[70%] p-3 rounded-lg shadow bg-surface text-foreground border border-border-color">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse delay-75"></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse delay-150"></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse delay-300"></div>
                   <span className="text-sm text-muted-foreground">Pensando...</span>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="p-4 border-t border-border-color bg-surface rounded-b-md">
          {error && <p className="text-xs text-danger mb-2 text-center">{error}</p>}
          <div className="flex items-center space-x-2">
            <TextareaInput
              label=""
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={isAiAvailable ? "Escribe tu pregunta..." : "Asistente AI no disponible."}
              rows={1}
              className="flex-grow resize-none py-2 leading-tight"
              containerClassName="flex-grow mb-0"
              disabled={!isAiAvailable || isLoading}
            />
            <Button onClick={handleSendMessage} disabled={!isAiAvailable || isLoading || !inputValue.trim()} aria-label="Enviar mensaje">
              <Icon name="arrowRight" className="w-5 h-5 transform rotate-[-45deg]" />
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default AiAssistantChatModal;
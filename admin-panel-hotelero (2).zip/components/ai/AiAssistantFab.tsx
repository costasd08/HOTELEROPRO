import React from 'react';
import Button from '../common/Button';
import Icon from '../common/Icon';

interface AiAssistantFabProps {
  onOpenChat: () => void;
}

const AiAssistantFab: React.FC<AiAssistantFabProps> = ({ onOpenChat }) => {
  return (
    <div className="fixed bottom-6 right-6 z-40">
      <Button
        variant="primary"
        size="lg"
        onClick={onOpenChat}
        className="rounded-full p-4 shadow-xl hover:shadow-2xl transition-shadow duration-300"
        aria-label="Abrir Asistente AI"
        title="Asistente AI"
      >
        <Icon name="sparkles" className="w-7 h-7" />
      </Button>
    </div>
  );
};

export default AiAssistantFab;
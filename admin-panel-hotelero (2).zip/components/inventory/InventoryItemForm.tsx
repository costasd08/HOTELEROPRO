
import React, { useState, useEffect } from 'react';
import { InventoryItem, InventoryCategoryType } from '../../types';
import Button from '../common/Button';
import TextInput from '../common/TextInput';
import TextareaInput from '../common/TextareaInput';
import SelectInput from '../common/SelectInput';
import DateInput from '../common/DateInput';

interface InventoryItemFormProps {
  initialData: InventoryItem | null;
  onSave: (data: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'> & { id?: string; batchPurchaseCost?: number }) => void; // Renamed purchaseCost to batchPurchaseCost for clarity
  onCancel: () => void;
  categoryOptions: { value: string; label: string }[];
  currentCategory?: InventoryCategoryType; // Optional, for pre-selecting category for new items
}

const InventoryItemForm: React.FC<InventoryItemFormProps> = ({ 
    initialData, 
    onSave, 
    onCancel, 
    categoryOptions,
    currentCategory
}) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    category: initialData?.category || currentCategory || categoryOptions[0]?.value as InventoryCategoryType,
    quantity: initialData?.quantity || 0,
    unit: initialData?.unit || 'unidad',
    purchasePrice: initialData?.purchasePrice, // New field for unit purchase price
    lowStockThreshold: initialData?.lowStockThreshold,
    supplierInfo: initialData?.supplierInfo || '',
    lastRestockDate: initialData?.lastRestockDate || '',
    notes: initialData?.notes || '',
  });
  const [batchPurchaseCost, setBatchPurchaseCost] = useState<number | undefined>(undefined); // For new items batch cost for accounting

  useEffect(() => {
    if (!initialData && currentCategory) {
        setFormData(prev => ({ ...prev, category: currentCategory }));
    }
    if (initialData) { // Populate purchasePrice if editing
        setFormData(prev => ({ ...prev, purchasePrice: initialData.purchasePrice}));
    }
  }, [initialData, currentCategory]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: (name === 'quantity' || name === 'lowStockThreshold' || name === 'purchasePrice') ? (value === '' ? undefined : parseFloat(value)) : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || formData.quantity < 0 || !formData.unit) {
      alert("Nombre, cantidad (no negativa) y unidad son obligatorios.");
      return;
    }
    if (formData.lowStockThreshold !== undefined && formData.lowStockThreshold < 0) {
        alert("El umbral de stock bajo no puede ser negativo.");
        return;
    }
    if (formData.purchasePrice !== undefined && formData.purchasePrice < 0) {
        alert("El precio de compra unitario no puede ser negativo.");
        return;
    }

    onSave({ id: initialData?.id, ...formData, batchPurchaseCost: initialData ? undefined : batchPurchaseCost });
  };
  
  const unitOptions = [
    { value: 'unidad', label: 'Unidad (un)' },
    { value: 'pieza', label: 'Pieza (pz)' },
    { value: 'kg', label: 'Kilogramo (kg)' },
    { value: 'g', label: 'Gramo (g)' },
    { value: 'litro', label: 'Litro (L)' },
    { value: 'ml', label: 'Mililitro (mL)' },
    { value: 'caja', label: 'Caja (cja)' },
    { value: 'paquete', label: 'Paquete (pqt)' },
    { value: 'metro', label: 'Metro (m)' },
    { value: 'otro', label: 'Otro' },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <TextInput label="Nombre del Artículo*" name="name" value={formData.name} onChange={handleChange} required />
      <SelectInput label="Categoría del Inventario*" name="category" value={formData.category} onChange={handleChange} options={categoryOptions} required />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TextInput label="Cantidad Actual*" name="quantity" type="number" value={formData.quantity?.toString() || '0'} onChange={handleChange} min="0" step="any" required />
        <SelectInput label="Unidad de Medida*" name="unit" value={formData.unit} onChange={handleChange} options={unitOptions} required />
      </div>
      
      <TextInput 
        label="Precio de Compra Unitario (Opcional)" 
        name="purchasePrice" 
        type="number" 
        value={formData.purchasePrice?.toString() || ''} 
        onChange={handleChange} 
        min="0" 
        step="0.01"
        helperText="Precio de costo por unidad del artículo."
      />

      <TextInput label="Umbral de Stock Bajo (Opcional)" name="lowStockThreshold" type="number" value={formData.lowStockThreshold?.toString() || ''} onChange={handleChange} min="0" step="any" placeholder="Ej: 5 (alerta si cantidad < 5)"/>
      
      {!initialData && ( 
          <TextInput 
            label="Costo Total de Compra de este Lote (Opcional, para contabilidad)" 
            name="batchPurchaseCost" 
            type="number" 
            value={batchPurchaseCost?.toString() || ''} 
            onChange={(e) => setBatchPurchaseCost(e.target.value === '' ? undefined : parseFloat(e.target.value))} 
            min="0" 
            step="0.01"
            helperText="Si se ingresa, se creará un asiento de gasto en contabilidad por el total de este lote."
          />
      )}

      <TextInput label="Información del Proveedor (Opcional)" name="supplierInfo" value={formData.supplierInfo} onChange={handleChange} placeholder="Nombre, contacto, etc."/>
      <DateInput label="Fecha de Último Surtido (Opcional)" name="lastRestockDate" value={formData.lastRestockDate} onChange={handleChange}/>
      <TextareaInput label="Notas Adicionales (Opcional)" name="notes" value={formData.notes} onChange={handleChange} rows={2} />

      <div className="flex justify-end space-x-3 pt-4 border-t border-border-color mt-4">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" variant="primary">{initialData ? 'Actualizar Artículo' : 'Crear Artículo'}</Button>
      </div>
    </form>
  );
};

export default InventoryItemForm;

export enum ReservationStatus {
  PENDING = 'Pendiente',
  ADVANCE_PAID = 'Anticipo Pagado',
  FULLY_PAID = 'Pago Completo',
  CANCELLED = 'Cancelada',
}

export enum AccountingEntryType {
  INCOME = 'Ingreso',
  EXPENSE = 'Gasto',
}

export enum AccountingExpenseCategory {
  FIXED = 'Fijos',
  OPERATIONAL = 'Operativos',
  STAFF = 'Personal', // General staff costs, includes salaries, bonuses
  LOANS_TO_STAFF = 'Préstamos al Personal',
  RESTAURANT_EXPENSE = 'Gasto Restaurante', // Cost of goods for restaurant
  MAINTENANCE = 'Mantenimiento',
  MARKETING = 'Marketing General', 
  MARKETING_CAMPAIGN = 'Campaña de Marketing Específica',
  OTHER_PURCHASES = 'Otras Compras',
  INVENTORY_PURCHASE = 'Compra Inventario', 
}

export enum AccountingIncomeCategory {
  HOSPEDAJE = 'Hospedaje',
  COMANDA = 'Comanda', 
  RESTAURANT_INCOME = 'Ingreso Restaurante', 
  EVENTOS = 'Eventos',
  PRESTAMOS_RECIBIDOS = 'Préstamos Recibidos Hotel', 
  CREDITOS_OTORGADOS = 'Créditos Otorgados Hotel', 
  INVERSION = 'Retorno Inversión',
  LOAN_REPAYMENT_STAFF = 'Reembolso Préstamo Personal', 
  DEDUCTIONS_STAFF = 'Deducciones Personal', 
  CAMPING = 'Camping', 
  PLAYA_ACCESS = 'Acceso Playa', 
  OTROS_INGRESOS = 'Otros Ingresos',
}


export enum PaymentMethod {
  CASH = 'Efectivo',
  CARD = 'Tarjeta',
  TRANSFER = 'Transferencia',
  OTHER = 'Otro',
}

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  email?: string;
  origin?: string;
  notes?: string;
  createdAt: string;
}

export enum RoomCleaningStatus {
  SUCIA = 'Sucia',
  EN_LIMPIEZA = 'En Limpieza',
  LIMPIA = 'Limpia',
  INSPECCIONADA = 'Inspeccionada',
  FUERA_DE_SERVICIO = 'Fuera de Servicio',
}

export interface Property {
  id: string;
  name: string;
  description: string;
  maxCapacity: number;
  bedConfiguration: string;
  pricePerNight: number;
  photoUrls: string[]; 
  calendarColor: string; 
  maintenanceLog: MaintenanceLogEntry[];
  currentCleaningStatus: RoomCleaningStatus; 
  lastCleanedDate?: string; 
  amenities?: string[]; // Added amenities
  createdAt: string;
}

export interface MaintenanceLogEntry {
  id: string;
  date: string;
  description: string;
  cost?: number;
}

export interface ReservationPayment {
  id: string;
  amount: number;
  paymentDate: string;
  method: PaymentMethod;
  notes?: string;
  createdAt: string;
}
export interface Reservation {
  id: string;
  customerId: string;
  customer?: Customer; 
  propertyId: string;
  property?: Property; 
  checkInDate: string;
  checkInTime?: string;
  checkOutDate: string;
  checkOutTime?: string;
  numberOfGuests: number;
  status: ReservationStatus;
  advanceAmount?: number;
  payments?: ReservationPayment[];
  paymentProofDataUrl?: string; 
  notes?: string;
  totalPrice: number;
  balanceDue: number;
  createdAt: string;
}

export interface AccountingEntry {
  id: string;
  date: string;
  type: AccountingEntryType;
  category: AccountingExpenseCategory | AccountingIncomeCategory;
  description: string;
  amount: number;
  createdAt: string;
  reservationId?: string; 
  employeeTransactionId?: string; 
  orderId?: string; 
  inventoryItemId?: string; 
  maintenanceRequestId?: string; 
  marketingCampaignId?: string; 
}

export interface KPIData {
  label: string;
  value: string | number;
  icon?: React.ReactNode;
  bgColor?: string;
}

export interface AlertData {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'error';
  link?: string;
}

export interface PropertyPerformanceData {
  property: Property;
  occupancyRate: number; 
  totalRevenue: number;
}

export interface SmartNoteRequest {
  customerId: string;
  bookingHistory: Pick<Reservation, 'propertyId' | 'checkInDate' | 'checkOutDate' | 'numberOfGuests' | 'totalPrice' | 'notes'>[];
  customerPreferences?: string;
}

export interface AppSettings {
  appName: string;
  logoUrl: string; 
  hotelEmail: string;
  responsiblePerson: string;
  phone?: string; 
  reportCustomHeaderText?: string;
  reportCustomFooterText?: string;
  defaultCheckInTime?: string;
  defaultCheckOutTime?: string;
  reservationPolicies?: string;
  cancellationPolicies?: string;
  generalObservations?: string; 
  otherPolicies?: string;
  weatherWidgetEnabled?: boolean;
  weatherWidgetHref?: string;
  weatherWidgetDataLabel?: string;
  googleCalendarConnected?: boolean; 
  googleCalendarId?: string;
  defaultKitchenOverheadRate?: number; 
  defaultAdminSalesOverheadRate?: number;
  aiAssistantEnabled?: boolean; // Added for AI Assistant toggle
}

export type ReportPeriodType = 
  'current_week' | 
  'current_month' | 
  'current_year' | 
  'custom_range';

export interface ReportSummary { 
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  startDate: string;
  endDate: string;
  periodTypeLabel: string; 
  generatedAt: string;
}

export interface ReservationReportSummary {
    totalReservations: number;
    totalGuests: number;
    totalRevenue: number;
    averagePricePerReservation: number;
    startDate: string;
    endDate: string;
    periodTypeLabel: string;
    generatedAt: string;
}

export interface DashboardReportSummary {
    totalCheckIns: number;
    totalCheckOuts: number;
    averageOccupancyRate: number;
    totalIncome: number;
    totalExpenses: number;
    netBalance: number;
    startDate: string;
    endDate: string;
    periodTypeLabel: string;
    generatedAt: string;
}

export interface Employee {
  id: string;
  fullName: string;
  position: string;
  hireDate: string;
  baseSalary: number;
  contactInfo: string; 
  bankAccount?: string;
  notes?: string;
  isActive: boolean;
  createdAt: string;
}

export enum EmployeeTransactionType {
  SALARY = 'Salario',
  ADVANCE = 'Anticipo', 
  LOAN_GIVEN = 'Préstamo Otorgado', 
  LOAN_REPAYMENT = 'Devolución Préstamo', 
  BONUS = 'Bonificación',
  DEDUCTION = 'Deducción', 
  OTHER = 'Otro',
}

export interface EmployeeTransaction {
  id: string;
  employeeId: string;
  date: string;
  type: EmployeeTransactionType;
  description: string;
  amount: number; 
  accountingEntryId?: string; 
  createdAt: string;
}

export interface CalendarEventDetails {
  summary: string; 
  description?: string; 
  start: {
    dateTime: string; 
    timeZone?: string; 
  };
  end: {
    dateTime: string; 
    timeZone?: string;
  };
  attendees?: { email: string }[]; 
  reminders?: { 
    useDefault: boolean;
    overrides?: { method: 'email' | 'popup'; minutes: number }[];
  };
}

export enum MenuItemCategory {
    DESAYUNO = 'Desayuno',
    COMIDA = 'Comida',
    CENA = 'Cena',
    BEBIDA = 'Bebida',
    SNACK = 'Snack/Entrada',
    POSTRE = 'Postre',
    EVENTO_ESPECIAL = 'Evento Especial', 
    OTRO = 'Otro Platillo',
}

export interface MenuItem {
    id: string;
    name: string;
    description?: string;
    category: MenuItemCategory;
    productionCost: number; 
    sellingPrice: number;
    photoUrl?: string; 
    isAvailable: boolean;
    createdAt: string;
}

export enum OrderStatus {
    PENDIENTE = 'Pendiente',
    EN_PREPARACION = 'En Preparación',
    LISTO_PARA_ENTREGAR = 'Listo para Entregar/Servir',
    ENTREGADO = 'Entregado', 
    PAGADO = 'Pagado',
    CANCELADO = 'Cancelado',
}

export interface OrderItem {
    menuItemId: string;
    menuItemName?: string; 
    quantity: number;
    sellingPriceAtOrderTime: number; 
    notes?: string; 
}

export interface Order {
    id: string;
    tableNumber?: string; 
    customerName?: string; 
    items: OrderItem[];
    totalAmount: number; 
    status: OrderStatus;
    paymentMethod?: PaymentMethod;
    notes?: string; 
    createdAt: string;
    reservationId?: string; 
    isTakeAway: boolean;
    completedAt?: string; 
    createdBy?: string; 
    accountingEntryId?: string; 
}

export interface RestaurantReportSummary {
    totalOrders: number;
    totalRevenue: number;
    totalProductionCost: number; 
    netProfit: number; 
    averageOrderValue: number;
    mostSoldItem?: { name: string, quantity: number };
    startDate: string;
    endDate: string;
    periodTypeLabel: string;
    generatedAt: string;
}

export enum InventoryCategoryType {
    RESTAURANTE = 'Restaurante',
    CABANAS_HABITACIONES = 'Cabañas/Habitaciones',
    MANTENIMIENTO_GENERAL = 'Mantenimiento General',
}

export interface InventoryItem {
    id: string;
    name: string;
    category: InventoryCategoryType;
    quantity: number;
    unit: string; 
    purchasePrice?: number; 
    lowStockThreshold?: number; 
    supplierInfo?: string; 
    lastRestockDate?: string; 
    notes?: string; 
    createdAt: string;
    updatedAt?: string;
}

export interface RecipeIngredient {
  id: string; 
  inventoryItemId?: string; 
  manualIngredientName?: string; 
  quantityInRecipe: number; 
  unitInRecipe: string; 
  costPerRecipeUnit: number; 
  yieldFactor: number; 
  calculatedCost: number; 
}

export interface MenuItemCostAnalysis {
  id: string; 
  menuItemId: string;
  recipeIngredients: RecipeIngredient[];
  
  directLaborTimeMinutes: number; 
  directLaborHourlyRate: number; 

  kitchenOverheadRate: number; 
  adminSalesOverheadRate: number; 
  desiredProfitMarginRate: number; 

  calculatedDirectMaterialCost?: number;
  calculatedDirectLaborCost?: number;
  calculatedKitchenOverheadCost?: number;
  totalProductionCost?: number; 
  calculatedAdminSalesCost?: number;
  totalCostBeforeProfit?: number; 
  calculatedProfitAmount?: number;
  suggestedSellingPrice?: number;
  
  notes?: string;
  lastCalculated?: string; 
}

export enum MaintenanceTaskStatus {
    REPORTADO = 'Reportado',
    EN_PROGRESO = 'En Progreso',
    EN_ESPERA = 'En Espera', 
    COMPLETADO = 'Completado',
    CANCELADO = 'Cancelado',
}

export enum MaintenanceUrgency {
    BAJA = 'Baja',
    MEDIA = 'Media',
    ALTA = 'Alta',
    CRITICA = 'Crítica',
}

export enum MaintenanceLocationType {
    PROPIEDAD_HABITACION = 'Propiedad/Habitación',
    AREA_RESTAURANTE = 'Área de Restaurante',
    AREA_COMUN = 'Área Común',
    EQUIPO_GENERAL = 'Equipo General/Otro',
}

export interface MaintenanceRequest {
    id: string;
    reportedDate: string; 
    reportedBy: string; 
    locationType: MaintenanceLocationType;
    propertyId?: string; 
    locationName?: string; 
    issueDescription: string;
    urgency: MaintenanceUrgency;
    photoUrls?: string[]; 
    status: MaintenanceTaskStatus;
    assignedToEmployeeId?: string;
    estimatedCost?: number;
    actualCost?: number;
    completionDate?: string; 
    resolutionNotes?: string;
    inventoryItemsUsedNotes?: string; 
    createdAt: string; 
    updatedAt?: string; 
    accountingEntryId?: string; 
}

export enum MarketingCampaignStatus {
    PLANIFICADA = 'Planificada',
    ACTIVA = 'Activa',
    COMPLETADA = 'Completada',
    ARCHIVADA = 'Archivada',
    CANCELADA = 'Cancelada',
}

export enum SocialMediaPlatform {
    FACEBOOK = 'Facebook',
    INSTAGRAM = 'Instagram',
    X_TWITTER = 'X (Twitter)',
    TIKTOK = 'TikTok',
    LINKEDIN = 'LinkedIn',
    PINTEREST = 'Pinterest',
    YOUTUBE = 'YouTube',
    OTRA = 'Otra Plataforma',
}

export enum SocialMediaPostStatus {
    BORRADOR = 'Borrador',
    PROGRAMADO = 'Programado',
    PUBLICADO = 'Publicado',
    FALLIDO = 'Fallido al Publicar',
    ARCHIVADO = 'Archivado',
}

export enum EmailCampaignStatus {
    BORRADOR = 'Borrador',
    PROGRAMADA = 'Programada',
    ENVIANDO = 'Enviando',
    ENVIADA = 'Enviada',
    FALLIDA = 'Fallida',
    ARCHIVADA = 'Archivada',
}

export interface MarketingCampaign {
    id: string;
    name: string;
    description?: string;
    startDate: string; 
    endDate: string;   
    budget?: number;
    actualSpend?: number; 
    goals?: string; 
    targetAudience?: string; 
    channels?: string[]; 
    status: MarketingCampaignStatus;
    accountingEntryIds?: string[]; 
    createdAt: string;
    updatedAt?: string;
}

export interface SocialMediaPost {
    id: string;
    campaignId?: string; 
    platform: SocialMediaPlatform;
    content: string; 
    imageUrl?: string; 
    videoUrl?: string; 
    scheduledDateTime: string; 
    status: SocialMediaPostStatus;
    notes?: string;
    likes?: number;
    comments?: number;
    shares?: number;
    reach?: number;
    createdAt: string;
    updatedAt?: string;
}

export interface EmailMarketingCampaign {
    id: string;
    campaignId?: string; 
    name: string; 
    subject: string;
    targetAudienceDescription: string; 
    contentPreview: string; 
    scheduledSendDateTime: string; 
    status: EmailCampaignStatus;
    emailsSent?: number;
    openRate?: number; 
    clickThroughRate?: number; 
    createdAt: string;
    updatedAt?: string;
}

export enum TargetedCampaignChannel {
    EMAIL = 'Email',
    WHATSAPP = 'WhatsApp',
    OTRO = 'Otro Canal',
}

export interface TargetedCampaign {
    id: string;
    name: string;
    targetAudienceDescription: string; 
    channel: TargetedCampaignChannel;
    messageTemplate?: string; 
    status: MarketingCampaignStatus; 
    scheduledDate?: string; 
    notes?: string;
    createdAt: string;
    updatedAt?: string;
}

// Guest Feedback Module Types
export enum FeedbackType {
    COMENTARIO = 'Comentario General',
    QUEJA = 'Queja',
    SUGERENCIA = 'Sugerencia',
    ELOGIO = 'Elogio',
}

export enum FeedbackSource {
    VERBAL_PERSONAL = 'Verbal (Personal)',
    EMAIL_DIRECTO = 'Email Directo',
    TARJETA_COMENTARIO = 'Tarjeta de Comentario',
    LLAMADA_TELEFONICA = 'Llamada Telefónica',
    RESEÑA_ONLINE = 'Reseña Online (Registrada)',
    OTRO = 'Otro Medio',
}

export enum FeedbackStatus {
    NUEVO = 'Nuevo',
    EN_REVISION = 'En Revisión',
    ACCION_REQUERIDA = 'Acción Requerida',
    RESUELTO = 'Resuelto',
    CERRADO = 'Cerrado',
}

export interface GuestFeedback {
    id: string;
    dateReceived: string; // ISO Date string
    customerId?: string; // Link to Customer
    reservationId?: string; // Link to Reservation, for context
    guestNameManual?: string; // If customer/reservation not linked
    type: FeedbackType;
    source: FeedbackSource;
    details: string; // The actual feedback content
    departmentToInform?: string; // e.g., "Recepción", "Restaurante", "Mantenimiento"
    actionTaken?: string; // What was done about it
    status: FeedbackStatus;
    employeeHandlingId?: string; // Employee who handled it
    aiSummary?: string; // Gemini generated summary
    createdAt: string; // ISO DateTime string
    updatedAt?: string; // ISO DateTime string
}

// Enriched GuestFeedback for detailed view
export interface EnrichedGuestFeedback extends GuestFeedback {
  customer?: Customer;
  reservation?: Reservation;
  employeeHandling?: Employee;
}


// Analytics Module Types
export interface ChartDataPoint {
  label: string; 
  value: number;
  color?: string; 
  id?: string; // Optional id for drilling or interaction
}

export interface TrendData {
  period: string; 
  value: number;
  previousValue?: number; // For comparison in display
}

export interface AnalyticsSectionData {
  title: string;
  kpis: KPIData[];
  charts?: { 
    id: string; // Unique ID for the chart/data block
    title: string; 
    type: 'bar' | 'line' | 'pie' | 'list' | 'trend' | 'summary'; // 'summary' for text block
    data: ChartDataPoint[] | TrendData[] | { [key: string]: string | number } | string; 
    notes?: string;
  }[];
  notes?: string;
}

export interface AnalyticsReportSummary {
  reportTitle: string;
  periodLabel: string;
  generatedAt: string;
  sections: AnalyticsSectionData[];
  overallSummary?: string; 
}

// AI Assistant Types
export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai' | 'system'; // 'system' for initial messages or errors
  timestamp: string;
}

export interface ApplicationDataContext {
  reservations: Reservation[];
  customers: Customer[];
  properties: Property[];
  accountingEntries: AccountingEntry[];
  employees: Employee[];
  orders: Order[];
  menuItems: MenuItem[];
  inventoryItems: InventoryItem[];
  guestFeedback: GuestFeedback[];
  appSettings: AppSettings;
}
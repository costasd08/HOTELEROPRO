
import { useState, useEffect, useCallback } from 'react';

const useMockData = <T extends { id: string },>(
  storageKey: string,
  initialData: T[] = []
): [T[], React.Dispatch<React.SetStateAction<T[]>>, () => void] => {
  const [data, setData] = useState<T[]>(() => {
    try {
      const item = window.localStorage.getItem(storageKey);
      return item ? JSON.parse(item) : initialData;
    } catch (error) {
      console.error(`Error reading localStorage key "${storageKey}":`, error);
      return initialData;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(data));
    } catch (error) {
      console.error(`Error setting localStorage key "${storageKey}":`, error);
    }
  }, [storageKey, data]);

  const resetData = useCallback(() => {
    setData(initialData);
    window.localStorage.removeItem(storageKey);
  }, [storageKey, initialData]);


  return [data, setData, resetData];
};

export default useMockData;
    